{{- if eq (include "cloudanix.runtimeThreatEnabled" .) "true" }}
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ .Values.inventoryCollector.name }}
  namespace: cloudanix
  labels:
    {{- with .Values.inventoryCollector.labels }}
    {{ toYaml . }}
    {{- end }}
spec:
  replicas: 1
  selector:
    matchLabels:
      {{- with .Values.inventoryCollector.labels }}
      {{ toYaml . }}
      {{- end }}
  template:
    metadata:
      labels:
        {{- with .Values.inventoryCollector.labels }}
        {{ toYaml . }}
        {{- end }}
    spec:
      {{- if hasKey .Values "dnsPolicy" }}
      dnsPolicy: {{ .Values.dnsPolicy }}
      {{- end }}
      {{- with .Values.dnsConfig }}
      dnsConfig:
        {{- toYaml . }}
      {{- end }}
      serviceAccountName: {{ .Values.inventoryCollector.serviceAccount }}
      automountServiceAccountToken: true
      containers:
      - name: {{ .Values.inventoryCollector.name }}
        image: {{ .Values.inventoryCollector.image }}
        imagePullPolicy: IfNotPresent
        ports:
        - containerPort: 8080
        volumeMounts:
        - name: config-volume
          mountPath: /etc/cdx/config
          readOnly: true
        - name: cloudanix-secrets-volume
          mountPath: /etc/cdx/secrets
          readOnly: true
        resources:
          {{- toYaml (.Values.inventoryCollector.resources | default dict) | nindent 10 }}
      volumes:
        - name: config-volume
          configMap:
            name: {{ .Values.inventoryCollector.configMapName }}
        - name: cloudanix-secrets-volume
          secret:
            secretName: cloudanix-secrets
      terminationGracePeriodSeconds: 60

---

apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ .Values.inventoryCollector.configMapName }}
  namespace: cloudanix
data:
  config.yaml: |
    chartVersion:  {{ .Chart.Version }}
    releaseName: {{ .Release.Name }}
    common:
      listenerUrl: {{ required "A valid URL is required!" .Values.inventoryCollector.listenerUrl }}
      requestTimeout: {{ .Values.requestTimeout | default 30 }}
      httpMaxRetries: {{ .Values.httpMaxRetries | default 3 }}
      bufferSize:  {{ .Values.inventoryCollector.bufferSize }}
      bufferDuration:  {{ .Values.inventoryCollector.bufferDuration }}
      ignoreDuplicates:  {{ .Values.inventoryCollector.ignoreDuplicates }}
      logLevel: {{ .Values.logLevel | default "warn" }}
      accountId: {{ required "Account Id is required!" .Values.accountId }}
      clusterIdentifier: {{ required "Cluster Identifier is required!" .Values.clusterIdentifier }}
      {{- if and (.Values.clusterName) (ne .Values.clusterName "DEFAULT") }}
      clusterName:  {{ .Values.clusterName }}
      {{- else if (.Values.clusterIdentifier) }}
      clusterName: {{ required "Cluster Name is required!" (splitList "/" .Values.clusterIdentifier) | last }}
      {{- end }}
      clusterDomain: {{ required "Cluster Domain is required!" .Values.clusterDomain }}
    inventoryCollector:
      templateType: {{ required "inventoryCollector.templateType is required!" .Values.inventoryCollector.templateType }}
      {{- if and (.Values.authToken) (ne .Values.authToken "DEFAULT" ) }}
      enabled: true
      {{- end }}

---

apiVersion: v1
kind: ServiceAccount
metadata:
  name: {{ .Values.inventoryCollector.serviceAccount }}
  namespace: cloudanix

---

kind: ClusterRole
apiVersion: rbac.authorization.k8s.io/v1
metadata:
  name: {{ .Values.inventoryCollector.clusterRole }}
  namespace: cloudanix
rules:
# Must stay in step with inventory-collector/kube/resources.go: a GVR watched there but
# not granted here fails at informer start, and the collector simply reports less.
- apiGroups: ["","apps","batch","storage.k8s.io"]
  resources: ["pods","replicasets","replicationcontrollers","deployments","statefulsets","daemonsets","jobs","cronjobs","services","endpoints","persistentvolumes","storageclasses","nodes","namespaces","serviceaccounts","resourcequotas"]
  verbs: ["get", "watch", "list"]
# endpointslices is watched by resources.go and was never granted, so that informer had
# been failing since it was added.
- apiGroups: ["discovery.k8s.io"]
  resources: ["endpointslices"]
  verbs: ["get", "watch", "list"]
- apiGroups: ["autoscaling"]
  resources: ["horizontalpodautoscalers"]
  verbs: ["get", "watch", "list"]
# RBAC + policy objects. The bindings back kube-bench CBP checks C2.1 / C2.4, whose
# failed_resources have nothing to enrich against unless the collector watches them.
# Read-only, and Secrets are deliberately excluded (the informer caches whole objects).
- apiGroups: ["rbac.authorization.k8s.io"]
  resources: ["roles","clusterroles","rolebindings","clusterrolebindings"]
  verbs: ["get", "watch", "list"]
- apiGroups: ["networking.k8s.io","policy"]
  resources: ["networkpolicies","poddisruptionbudgets","ingresses"]
  verbs: ["get", "watch", "list"]
# gke-1.9.0 4.1.6 names the CSR carrying O=system:masters. Unlike Secrets the cached
# object holds only public material (the PEM request and the issued certificate).
- apiGroups: ["certificates.k8s.io"]
  resources: ["certificatesigningrequests"]
  verbs: ["get", "watch", "list"]

---

apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: {{ .Values.inventoryCollector.name }}
  namespace: cloudanix
subjects:
- kind: ServiceAccount
  name: {{ .Values.inventoryCollector.serviceAccount }}
  namespace: cloudanix
roleRef:
  kind: ClusterRole
  name: {{ .Values.inventoryCollector.clusterRole }}
  apiGroup: rbac.authorization.k8s.io
{{- end }}
