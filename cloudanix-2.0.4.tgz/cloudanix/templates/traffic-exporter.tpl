{{- if eq (include "cloudanix.trafficExporterEnabled" .) "true" }}
---
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ .Values.trafficExporter.name }}-config
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "cloudanix.labels" . | nindent 4 }}
    component: traffic-exporter
data:
  config.yaml: |
    common:
      listenerUrl: {{ required "trafficExporter.listenerUrl is required!" .Values.trafficExporter.listenerUrl | quote }}
      requestTimeout: {{ .Values.requestTimeout | default 30 }}
      httpMaxRetries: {{ .Values.httpMaxRetries | default 3 }}
      bufferSize: {{ .Values.trafficExporter.bufferSize }}
      bufferDuration: {{ .Values.trafficExporter.bufferDuration }}
      logLevel: {{ .Values.logLevel | default "warn" }}
      accountId: {{ required "Account Id is required!" .Values.accountId }}
      clusterIdentifier: {{ required "Cluster Identifier is required!" .Values.clusterIdentifier }}
      {{- if and (.Values.clusterName) (ne .Values.clusterName "DEFAULT") }}
      clusterName: {{ .Values.clusterName }}
      {{- end }}
      clusterDomain: {{ required "Cluster Domain is required!" .Values.clusterDomain }}
    trafficExporter:
      {{- if .Values.trafficExporter.ignoreNamespaces }}
      ignoreNamespaces:
        {{- range .Values.trafficExporter.ignoreNamespaces }}
        - {{ . | quote }}
        {{- end }}
      {{- else }}
      ignoreNamespaces: []
      {{- end }}
      {{- if .Values.trafficExporter.allowedNamespaces }}
      allowedNamespaces:
        {{- range .Values.trafficExporter.allowedNamespaces }}
        - {{ . | quote }}
        {{- end }}
      {{- else }}
      allowedNamespaces: []
      {{- end }}
      templateType: {{ required "trafficExporter.templateType is required!" .Values.trafficExporter.templateType }}
      {{- if and (.Values.authToken) (ne .Values.authToken "DEFAULT") }}
      enabled: true
      {{- end }}

---
apiVersion: v1
kind: ServiceAccount
metadata:
  name: {{ .Values.trafficExporter.name }}
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "cloudanix.labels" . | nindent 4 }}
    component: traffic-exporter

---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: {{ .Release.Namespace }}-{{ .Values.trafficExporter.name }}
  labels:
    {{- include "cloudanix.labels" . | nindent 4 }}
    component: traffic-exporter
rules:
  - apiGroups: [""]
    resources: ["pods", "namespaces"]
    verbs: ["get", "list"]

---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: {{ .Release.Namespace }}-{{ .Values.trafficExporter.name }}
  labels:
    {{- include "cloudanix.labels" . | nindent 4 }}
    component: traffic-exporter
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: {{ .Release.Namespace }}-{{ .Values.trafficExporter.name }}
subjects:
  - kind: ServiceAccount
    name: {{ .Values.trafficExporter.name }}
    namespace: {{ .Release.Namespace }}

---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ .Values.trafficExporter.name }}
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "cloudanix.labels" . | nindent 4 }}
    component: traffic-exporter
    {{- with .Values.trafficExporter.labels }}
    {{- toYaml . | nindent 4 }}
    {{- end }}
spec:
  replicas: {{ .Values.trafficExporter.replicaCount }}
  selector:
    matchLabels:
      app: {{ .Values.trafficExporter.name }}
  template:
    metadata:
      labels:
        app: {{ .Values.trafficExporter.name }}
        {{- include "cloudanix.selectorLabels" . | nindent 8 }}
        component: traffic-exporter
    spec:
      serviceAccountName: {{ .Values.trafficExporter.name }}
      
      securityContext:
        runAsNonRoot: {{ .Values.trafficExporter.securityContext.runAsNonRoot }}
        runAsUser: {{ .Values.trafficExporter.securityContext.runAsUser }}
        runAsGroup: {{ .Values.trafficExporter.securityContext.runAsGroup }}
        fsGroup: {{ .Values.trafficExporter.securityContext.fsGroup }}
        seccompProfile:
          type: RuntimeDefault
      
      containers:
      - name: exporter
        image: {{ .Values.trafficExporter.image }}
        imagePullPolicy: IfNotPresent
        
        securityContext:
          allowPrivilegeEscalation: false
          readOnlyRootFilesystem: true
          runAsNonRoot: true
          runAsUser: {{ .Values.trafficExporter.securityContext.runAsUser }}
          runAsGroup: {{ .Values.trafficExporter.securityContext.runAsGroup }}
          capabilities:
            drop:
              - ALL
        
        args:
          - -config
          - /app/config/config.yaml
        
        env:
        - name: HUBBLE_RELAY_ADDR
          value: {{ .Values.trafficExporter.hubbleRelayAddress | quote }}
        {{- if .Values.trafficExporter.apiToken }}
        - name: BACKEND_API_TOKEN
          valueFrom:
            secretKeyRef:
              name: {{ .Values.trafficExporter.name }}-secret
              key: api-token
        {{- end }}
        
        volumeMounts:
        - name: config
          mountPath: /app/config
          readOnly: true
        - name: cloudanix-secrets-volume
          mountPath: /etc/cdx/secrets
          readOnly: true
        - name: tmp
          mountPath: /tmp
        
        resources:
          {{- toYaml (.Values.trafficExporter.resources | default dict) | nindent 10 }}
      
      volumes:
      - name: config
        configMap:
          name: {{ .Values.trafficExporter.name }}-config
      - name: cloudanix-secrets-volume
        secret:
          secretName: cloudanix-secrets
      - name: tmp
        emptyDir: {}
      
      terminationGracePeriodSeconds: 30

---
apiVersion: v1
kind: Service
metadata:
  name: {{ .Values.trafficExporter.name }}
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "cloudanix.labels" . | nindent 4 }}
    component: traffic-exporter
spec:
  type: ClusterIP
  ports:
  - name: metrics
    port: 9090
    targetPort: 9090
    protocol: TCP
  selector:
    app: {{ .Values.trafficExporter.name }}

{{- if .Values.trafficExporter.apiToken }}
---
apiVersion: v1
kind: Secret
metadata:
  name: {{ .Values.trafficExporter.name }}-secret
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "cloudanix.labels" . | nindent 4 }}
    component: traffic-exporter
type: Opaque
stringData:
  api-token: {{ .Values.trafficExporter.apiToken | quote }}
{{- end }}
{{- end }}
