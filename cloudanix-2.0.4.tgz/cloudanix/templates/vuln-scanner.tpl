{{- if eq (include "cloudanix.vulnScanningEnabled" .) "true" }}
{{- if .Capabilities.APIVersions.Has "batch/v1" }}
apiVersion: batch/v1
{{- else }}
apiVersion: batch/v1beta1
{{- end }}
kind: CronJob
metadata:
    name: {{ .Values.vulnScanner.name }}
    namespace: cloudanix
spec:
    schedule: {{ .Values.vulnScanner.schedule | quote }}
    concurrencyPolicy: Forbid
    jobTemplate:
        spec:
            activeDeadlineSeconds: {{ .Values.vulnScanner.activeDeadlineSeconds | default 14400 }}
            template:
                spec:
                    serviceAccountName: {{ .Values.vulnScanner.serviceAccount }}
                    securityContext:
                        runAsUser: 1001
                        runAsGroup: 1001
                        runAsNonRoot: true
                        fsGroup: 1001
                        supplementalGroups: [0]        # grants access to root:root 0660 socket
                        seccompProfile:
                            type: RuntimeDefault
                    containers:
                        - name: {{ .Values.vulnScanner.name }}
                          image: {{ .Values.vulnScanner.image }}
                          imagePullPolicy: IfNotPresent
                          securityContext:
                              allowPrivilegeEscalation: false
                              readOnlyRootFilesystem: true
                              capabilities:
                                  drop: ["ALL"]
                          resources:
                              {{- toYaml (.Values.vulnScanner.resources | default dict) | nindent 30 }}
                          volumeMounts:
                              - name: config-volume
                                mountPath: /etc/cdx/config
                              - name: secret-volume
                                mountPath: /etc/cdx/secrets
                                readOnly: true
                              - name: containerd-socket
                                mountPath: {{ .Values.vulnScanner.containerRuntimeSocket }}
                                readOnly: true
                              - name: tmp-dir
                                mountPath: /tmp
                              - name: cache-dir
                                mountPath: /var/cache/vuln-scanner
                    volumes:
                        - name: config-volume
                          configMap:
                            name: {{ .Values.vulnScanner.configMapName }}
                        - name: secret-volume
                          secret:
                              secretName: cloudanix-secrets
                        - name: containerd-socket
                          hostPath:
                              path: {{ .Values.vulnScanner.containerRuntimeSocket }}
                              type: Socket
                        - name: tmp-dir
                          emptyDir: {}
                        - name: cache-dir
                          emptyDir: {}
                    restartPolicy: Never

---
apiVersion: v1
kind: ConfigMap
metadata:
    name: {{ .Values.vulnScanner.configMapName }}
    namespace: cloudanix
data:
    config.yaml: |
        chartVersion:  {{ .Chart.Version }}
        releaseName: {{ .Release.Name }}
        common:
          listenerUrl: {{ required "A valid URL is required!" .Values.vulnScanner.listenerUrl }}
          requestTimeout: {{ .Values.requestTimeout | default 30 }}
          httpMaxRetries: {{ .Values.httpMaxRetries | default 3 }}
          logLevel: {{ .Values.logLevel | default "warn" }}
          accountId: {{ required "Account ID is required!" .Values.accountId }}
          clusterIdentifier: {{ required "Cluster Identifier is required!" .Values.clusterIdentifier }}
          {{- if and (.Values.clusterName) (ne .Values.clusterName "DEFAULT") }}
          clusterName:  {{ .Values.clusterName }}
          {{- else if (.Values.clusterIdentifier) }}
          clusterName: {{ required "Cluster Name is required!" (splitList "/" .Values.clusterIdentifier) | last }}
          {{- end }}
          clusterDomain: {{ required "Cluster Domain is required!" .Values.clusterDomain }}
        vulnScanner:
          templateType: {{ required "vulnScanner.templateType is required!" .Values.vulnScanner.templateType }}
          {{- if and (.Values.authToken) (ne .Values.authToken "DEFAULT" ) }}
          enabled: true
          {{- end }}
          scanTimeout: {{ required "Scan Timeout is required!" .Values.vulnScanner.scanTimeout }}
          concurrency: {{ required "Concurrency is required!" .Values.vulnScanner.concurrency }}
          ignoreUnfixed: {{ required "Ignore Unfixed is required!" .Values.vulnScanner.ignoreUnfixed }}
          cacheDir: /var/cache/vuln-scanner
          cacheTTLInHours: 24

---
apiVersion: v1
kind: ServiceAccount
metadata:
    name: {{ .Values.vulnScanner.serviceAccount }}
    namespace: cloudanix

---
kind: ClusterRole
apiVersion: rbac.authorization.k8s.io/v1
metadata:
    name: {{ .Values.vulnScanner.clusterRole }}
rules:
    - apiGroups: [""]
      resources: ["pods"]
      verbs: ["get", "list"]

---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
    name: {{ .Values.vulnScanner.serviceAccount }}
subjects:
    - kind: ServiceAccount
      name: {{ .Values.vulnScanner.serviceAccount }}
      namespace: cloudanix
roleRef:
    kind: ClusterRole
    name: {{ .Values.vulnScanner.clusterRole }}
    apiGroup: rbac.authorization.k8s.io

{{- end }}
