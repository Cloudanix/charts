apiVersion: v1
kind: Secret
metadata:
  name: cloudanix-secrets
  namespace: {{ .Release.Namespace }}
type: Opaque
data:
  auth-token: {{ .Values.authToken | default "DEFAULT" | b64enc }}
