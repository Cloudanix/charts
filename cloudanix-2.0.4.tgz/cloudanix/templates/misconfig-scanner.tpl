{{- if eq (include "cloudanix.runtimeThreatEnabled" .) "true" }}
{{- if .Capabilities.APIVersions.Has "batch/v1" }}
apiVersion: batch/v1
{{- else }}
apiVersion: batch/v1beta1
{{- end }}
kind: CronJob
metadata:
  name: {{ .Values.misconfigScanner.name }}
  namespace: cloudanix
  labels:
    {{- with .Values.misconfigScanner.labels }}
    {{ toYaml . }}
    {{- end }}
spec:
  schedule: {{ .Values.misconfigScanner.schedule | quote }}
  concurrencyPolicy: Forbid
  jobTemplate:
    spec:
      activeDeadlineSeconds: {{ .Values.misconfigScanner.activeDeadlineSeconds | default 14400 }}
      template:
        metadata:
          labels:
            app: kube-bench
        spec:
          hostPID: true
          restartPolicy: Never
          serviceAccountName: {{ .Values.misconfigScanner.serviceAccount }}
          containers:
          - name: misconfig-scanner
            image: {{ .Values.misconfigScanner.image }}
            imagePullPolicy: IfNotPresent
            {{- if .Values.misconfigScanner.cbpEnabled }}
            {{- /* cbp needs explicit benchmarks; auto-detect can't append cloudanix-1.0. Bump these on kube-bench upgrades. */}}
            {{- $bench := "cis-1.12" }}
            {{- if eq .Values.clusterDomain "AWS" }}{{- $bench = "eks-1.8.0" }}
            {{- else if eq .Values.clusterDomain "GCP" }}{{- $bench = "gke-1.9.0" }}
            {{- else if eq .Values.clusterDomain "AZURE" }}{{- $bench = "aks-1.8" }}
            {{- else if eq .Values.clusterDomain "OCI" }}{{- $bench = "oke-1.7.0" }}
            {{- end }}
            command: ["kube-bench", "--httpoutput=true", {{ printf "--benchmark=%s,cloudanix-1.0" $bench | quote }}]
            {{- else }}
            {{- /* no --benchmark: kube-bench auto-detects the correct benchmark for the running k8s version */}}
            command: ["kube-bench", "--httpoutput=true"]
            {{- end }}
            # command: ["kube-bench", "--include-test-output", "--noremediations", "--noresults", "--nototals", "--httpoutput=true"]
            env:
            - name: NODE_NAME
              valueFrom:
                fieldRef:
                  fieldPath: spec.nodeName
            # Job runs on a schedule and is allowed to be slow; it must not burst CPU/mem.
            # GOMAXPROCS caps the Go scheduler's thread count; GOMEMLIMIT sets a soft heap
            # target so GC works harder to stay under the memory limit — not a hard guarantee.
            {{- if .Values.misconfigScanner.goMaxProcs }}
            - name: GOMAXPROCS
              value: {{ .Values.misconfigScanner.goMaxProcs | quote }}
            {{- end }}
            {{- if .Values.misconfigScanner.goMemLimit }}
            - name: GOMEMLIMIT
              value: {{ .Values.misconfigScanner.goMemLimit | quote }}
            {{- end }}
            volumeMounts:
            - name: var-lib-etcd
              mountPath: /var/lib/etcd
              readOnly: true
            - name: var-lib-kubelet
              mountPath: /var/lib/kubelet
              readOnly: true
            - name: var-lib-kube-scheduler
              mountPath: /var/lib/kube-scheduler
              readOnly: true
            - name: var-lib-kube-controller-manager
              mountPath: /var/lib/kube-controller-manager
              readOnly: true
            - name: etc-systemd
              mountPath: /etc/systemd
              readOnly: true
            - name: lib-systemd
              mountPath: /lib/systemd/
              readOnly: true
            - name: srv-kubernetes
              mountPath: /srv/kubernetes/
              readOnly: true
            - name: etc-kubernetes
              mountPath: /etc/kubernetes
              readOnly: true
              # /usr/local/mount-from-host/bin is mounted to access kubectl / kubelet, for auto-detecting the Kubernetes version.
              # You can omit this mount if you specify --version as part of the command.
            - name: usr-bin
              mountPath: /usr/local/mount-from-host/bin
              readOnly: true
            - name: etc-cni-netd
              mountPath: /etc/cni/net.d/
              readOnly: true
            - name: opt-cni-bin
              mountPath: /opt/cni/bin/
              readOnly: true
            - name: var-tmp-dump
              mountPath: /var/tmp/dump
            - name: misconfig-volume
              mountPath: /etc/cdx/config
              readOnly: true
            - name: cloudanix-secrets-volume
              mountPath: /etc/cdx/secrets
              readOnly: true
            resources:
              {{- toYaml (.Values.misconfigScanner.resources | default dict) | nindent 14 }}
          volumes:
          - name: var-lib-etcd
            hostPath:
              path: "/var/lib/etcd"
          - name: var-lib-kubelet
            hostPath:
              path: "/var/lib/kubelet"
          - name: var-lib-kube-scheduler
            hostPath:
              path: "/var/lib/kube-scheduler"
          - name: var-lib-kube-controller-manager
            hostPath:
              path: "/var/lib/kube-controller-manager"
          - name: etc-systemd
            hostPath:
              path: "/etc/systemd"
          - name: lib-systemd
            hostPath:
              path: "/lib/systemd"
          - name: srv-kubernetes
            {{- if eq .Values.clusterDomain "GCP" }}
            emptyDir: {}
            {{- else }}
            hostPath:
              path: "/srv/kubernetes"
            {{- end }}
          - name: etc-kubernetes
            hostPath:
              path: "/etc/kubernetes"
          - name: usr-bin
            hostPath:
              path: "/usr/bin"
          - name: etc-cni-netd
            hostPath:
              path: "/etc/cni/net.d/"
          - name: opt-cni-bin
            {{- if eq .Values.clusterDomain "GCP" }}
            emptyDir: {}
            {{- else }}
            hostPath:
              path: "/opt/cni/bin/"
            {{- end }}
          - name: var-tmp-dump
            hostPath:
              path: "/var/tmp/dump"
          - name: misconfig-volume
            configMap:
              name: {{ .Values.misconfigScanner.configMapName }}
          - name: cloudanix-secrets-volume
            secret:
              secretName: cloudanix-secrets

---

apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ .Values.misconfigScanner.configMapName }}
  namespace: cloudanix
data:
  config.yaml: |
    chartVersion:  {{ .Chart.Version }}
    releaseName: {{ .Release.Name }}
    common:
      listenerUrl: {{ required "A valid URL is required!" .Values.misconfigScanner.listenerUrl }}
      requestTimeout: {{ .Values.requestTimeout | default 30 }}
      httpMaxRetries: {{ .Values.httpMaxRetries | default 3 }}
      logLevel: {{ .Values.logLevel | default "warn" }}
      accountId: {{ required "Account Id is required!" .Values.accountId }}
      clusterIdentifier: {{ required "Cluster Identifier is required!" .Values.clusterIdentifier }}
      {{- if and (.Values.clusterName) (ne .Values.clusterName "DEFAULT") }}
      clusterName:  {{ .Values.clusterName }}
      {{- else if (.Values.clusterIdentifier) }}
      clusterName: {{ required "Cluster Name is required!" (splitList "/" .Values.clusterIdentifier) | last }}
      {{- end }}
      clusterDomain: {{ required "Cluster Domain is required!" .Values.clusterDomain }}
    misconfigScanner:
      templateType: {{ required "misconfigScanner.templateType is required!" .Values.misconfigScanner.templateType }}
      {{- if and (.Values.authToken) (ne .Values.authToken "DEFAULT" ) }}
      enabled: true
      {{- end }}
---

apiVersion: v1
kind: ServiceAccount
metadata:
  name: {{ .Values.misconfigScanner.serviceAccount }}
  namespace: cloudanix

---

kind: ClusterRole
apiVersion: rbac.authorization.k8s.io/v1
metadata:
  name: {{ .Values.misconfigScanner.clusterRole }}
rules:
# Split per apiGroup so each kind is granted where it actually lives. The policy checks read
# these to name the specific object that failed (failed_resources); a kind that is missing
# here makes kubectl exit non-zero and the check reports WARN with the API server's message
# rather than a finding.
- apiGroups: [""]
  # services + replicationcontrollers are part of what `kubectl get all` expands to
  resources: ["pods", "namespaces", "serviceaccounts", "services", "replicationcontrollers", "resourcequotas"]
  verbs: ["get", "list", "watch"]
- apiGroups: ["apps"]
  resources: ["deployments", "daemonsets", "statefulsets", "replicasets"]
  verbs: ["get", "list", "watch"]
- apiGroups: ["batch"]
  resources: ["jobs", "cronjobs"]
  verbs: ["get", "list", "watch"]
- apiGroups: ["autoscaling"]
  resources: ["horizontalpodautoscalers"]
  verbs: ["get", "list", "watch"]
- apiGroups: ["networking.k8s.io"]
  resources: ["networkpolicies", "ingresses"]
  verbs: ["get", "list", "watch"]
# GKE-only CRD, read by gke-1.9.0 5.6.7. Harmless where the CRD is absent.
- apiGroups: ["networking.gke.io"]
  resources: ["managedcertificates"]
  verbs: ["get", "list", "watch"]
- apiGroups: ["rbac.authorization.k8s.io"]
  resources: ["roles", "rolebindings", "clusterroles", "clusterrolebindings"]
  verbs: ["get", "list", "watch"]
- apiGroups: ["policy"]
  resources: ["poddisruptionbudgets"]
  verbs: ["get", "list", "watch"]
- apiGroups: ["certificates.k8s.io"]
  resources: ["certificatesigningrequests"]
  verbs: ["get", "list", "watch"]
# Deliberately no `secrets`: RBAC has no metadata-only read, so listing Secrets would expose
# their data. The one check that wanted it (cloudanix-1.0 C4.2) stays manual instead.

---

apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: {{ .Values.misconfigScanner.name }}
subjects:
- kind: ServiceAccount
  name: {{ .Values.misconfigScanner.serviceAccount }}
  namespace: cloudanix
roleRef:
  kind: ClusterRole
  name: {{ .Values.misconfigScanner.clusterRole }}
  apiGroup: rbac.authorization.k8s.io
{{- end }}
