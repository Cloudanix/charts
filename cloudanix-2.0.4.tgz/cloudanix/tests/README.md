# chart/tests

| Script | Needs | What it protects |
|---|---|---|
| `misconfig_render_test.sh` | helm | the misconfig-scanner template renders the right benchmark per `clusterDomain`, and its ClusterRole grants the kinds the audits need but never `secrets` |
| `rbac_coverage.py` | helm, PyYAML, sibling repos | three cross-repo contracts that otherwise fail **silently** |

```sh
chart/tests/misconfig_render_test.sh
chart/tests/rbac_coverage.py
```

## Why `rbac_coverage.py` exists

Each of these breaks with no error anywhere — you just get less data, and notice weeks later
from a gap in the console:

1. **misconfig ClusterRole ⊇ what the audits read.** A missing grant makes `kubectl` exit
   non-zero, so the check reports `WARN` carrying the API server's message instead of a
   finding. A whole benchmark can go quiet this way.
2. **inventory ClusterRole ⊇ what inventory-collector watches.** A watched-but-ungranted GVR
   fails at informer start and that kind is simply absent from inventory. This had actually
   happened with `endpointslices`.
3. **inventory-collector ⊇ the kinds kube-bench names.** The console joins `failed_resources`
   to inventory on `(cluster_identifier, uid)`; an unwatched kind renders half-populated.

Everything is derived from the sources — the benchmark YAML under `kube-bench/cfg`, the
rendered ClusterRoles, and `inventory-collector/kube/resources.go` — so it stays true as
checks are added rather than needing a list kept in step by hand.

## Sibling repos

Found via env vars, defaulting to the usual checkout paths. Missing repos are **skipped, not
failed**, so this still runs in a chart-only checkout:

```sh
KUBE_BENCH_DIR=~/src/kube-bench CSS_DIR=~/src/container-security-services \
    chart/tests/rbac_coverage.py
```

## When a check fires

- *misconfig ClusterRole is missing X* — an audit started reading a new resource. Add it to
  the rule for its apiGroup in `misconfig-scanner.tpl`. **Never add `secrets`**: RBAC has no
  metadata-only read, and `cloudanix-1.0` C4.2 stays manual precisely to avoid it.
- *inventory watches but ClusterRole does not grant X* — add it to
  `inventory-collector.tpl`.
- *kube-bench names X but inventory does not watch it* — add the GVR to `resources.go`, and
  its grant to `inventory-collector.tpl`. Weigh the informer cache first: it holds whole
  objects, which is why Secrets are excluded.
- *no catalog entry for X* — a new Kind appeared. Add it to `CATALOG` in the script so the
  join can be checked at all.
