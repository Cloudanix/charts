#!/usr/bin/env python3
"""Cross-repo consistency check for the misconfig scanner and inventory collector.

Three contracts, all of which fail *silently* in production if broken — nothing errors, you
just get less data — so they are checked here rather than discovered from a gap in the
console:

  1. misconfig ClusterRole  >=  every resource the shipped benchmarks' audits read.
     A missing grant makes kubectl exit non-zero; the check reports WARN with the API
     server's message instead of a finding.

  2. inventory ClusterRole  >=  every GVR inventory-collector watches.
     A watched-but-not-granted GVR fails at informer start and that kind is simply absent.

  3. inventory-collector    >=  every kind kube-bench names in failed_resources.
     The console joins those rows to inventory on (cluster_identifier, uid); an unwatched
     kind renders as a half-populated resource.

Everything is derived from the sources, not hardcoded, so it stays true as checks change.

Usage:
    chart/tests/rbac_coverage.py

Repos are found via env vars, falling back to the usual checkout paths. A repo that is not
present is skipped with a notice rather than failing, so this is usable in a chart-only
checkout:

    KUBE_BENCH_DIR=~/src/kube-bench CSS_DIR=~/src/container-security-services \\
        chart/tests/rbac_coverage.py
"""
import glob
import os
import re
import subprocess
import sys

try:
    import yaml
except ImportError:
    sys.exit("PyYAML required: pip install pyyaml")

CHART = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
REPO = os.path.dirname(CHART)
KUBE_BENCH = os.environ.get(
    "KUBE_BENCH_DIR",
    os.path.expanduser("~/go/src/github.com/Cloudanix/kube-bench"))
CSS = os.environ.get(
    "CSS_DIR",
    os.path.expanduser("~/go/src/github.com/Cloudanix/container-security-services"))

# The benchmark set misconfig-scanner.tpl ships. Keep in step with the $bench chain there.
SHIPPED = ["cloudanix-1.0", "eks-1.8.0", "gke-1.9.0", "aks-1.8", "cis-1.12", "oke-1.7.0"]

# kubectl shorthands the audits use.
ALIAS = {
    "svc": "services", "ns": "namespaces", "namespace": "namespaces",
    "networkpolicy": "networkpolicies", "csr": "certificatesigningrequests",
    "clusterrole": "clusterroles", "role": "roles", "ingress": "ingresses",
    "serviceaccount": "serviceaccounts", "poddisruptionbudget": "poddisruptionbudgets",
    "deployment": "deployments", "rolebinding": "rolebindings",
    "clusterrolebinding": "clusterrolebindings",
}

# `kubectl get all` expands to these. Used both for the RBAC set and for working out which
# Kinds an audit with a dynamic `kind=\(...)` can emit.
ALL_EXPANDS = ["pods", "services", "replicationcontrollers", "deployments", "daemonsets",
               "statefulsets", "replicasets", "jobs", "cronjobs",
               "horizontalpodautoscalers"]

# plural resource -> (apiGroup, Kind). Only the ones the audits touch.
CATALOG = {
    "pods": ("", "Pod"),
    "services": ("", "Service"),
    "namespaces": ("", "Namespace"),
    "serviceaccounts": ("", "ServiceAccount"),
    "replicationcontrollers": ("", "ReplicationController"),
    "resourcequotas": ("", "ResourceQuota"),
    "nodes": ("", "Node"),
    "endpoints": ("", "Endpoints"),
    "persistentvolumes": ("", "PersistentVolume"),
    "secrets": ("", "Secret"),
    "deployments": ("apps", "Deployment"),
    "daemonsets": ("apps", "DaemonSet"),
    "statefulsets": ("apps", "StatefulSet"),
    "replicasets": ("apps", "ReplicaSet"),
    "jobs": ("batch", "Job"),
    "horizontalpodautoscalers": ("autoscaling", "HorizontalPodAutoscaler"),
    "cronjobs": ("batch", "CronJob"),
    "roles": ("rbac.authorization.k8s.io", "Role"),
    "clusterroles": ("rbac.authorization.k8s.io", "ClusterRole"),
    "rolebindings": ("rbac.authorization.k8s.io", "RoleBinding"),
    "clusterrolebindings": ("rbac.authorization.k8s.io", "ClusterRoleBinding"),
    "networkpolicies": ("networking.k8s.io", "NetworkPolicy"),
    "ingresses": ("networking.k8s.io", "Ingress"),
    "poddisruptionbudgets": ("policy", "PodDisruptionBudget"),
    "certificatesigningrequests": ("certificates.k8s.io", "CertificateSigningRequest"),
    "managedcertificates": ("networking.gke.io", "ManagedCertificate"),
    "endpointslices": ("discovery.k8s.io", "EndpointSlice"),
    "storageclasses": ("storage.k8s.io", "StorageClass"),
}

GET = re.compile(r"kubectl\s+get\s+([a-zA-Z0-9.,/-]+)")
KIND_LITERAL = re.compile(r"kind=([A-Za-z][A-Za-z0-9]*)")
KIND_DYNAMIC = re.compile(r"kind=\\\(")

# Kinds kube-bench synthesises rather than reading from the API. scope="node" rows are
# linked against the cloud compute inventory by name, so the k8s inventory need not watch
# them for the join to work.
SYNTHESISED = {"Node"}

fail = 0
notes = []


def ok(msg):
    print("ok   - %s" % msg)


def bad(msg):
    global fail
    fail = 1
    print("FAIL - %s" % msg)


def skip(msg):
    notes.append(msg)
    print("skip - %s" % msg)


def render(template):
    r = subprocess.run(
        ["helm", "template", "cdx", "chart", "-f", "chart/local-values.yaml",
         "--set", "accountId=a", "--set", "clusterIdentifier=c", "--set", "authToken=t",
         "--set", "clusterDomain=AWS", "-s", "templates/" + template],
        cwd=REPO, capture_output=True, text=True)
    if r.returncode:
        sys.exit("helm template %s failed:\n%s" % (template, r.stderr))
    return r.stdout


def cluster_role_grants(rendered):
    """-> {(apiGroup, resource)} and {resource}."""
    pairs, names = set(), set()
    for doc in yaml.safe_load_all(rendered):
        if doc and doc.get("kind") == "ClusterRole":
            for rule in doc["rules"]:
                for g in rule["apiGroups"]:
                    for res in rule["resources"]:
                        pairs.add((g, res))
                        names.add(res)
    return pairs, names


def scan_benchmarks():
    """-> (resources the audits read, Kinds they emit as failed_resources)."""
    reads, kinds = set(), set()
    for bench in SHIPPED:
        paths = sorted(glob.glob("%s/cfg/%s/*.yaml" % (KUBE_BENCH, bench)))
        if not paths:
            sys.exit("ERROR: no cfg files found for shipped benchmark '%s'" % bench)
        for path in paths:
            if os.path.basename(path) == "config.yaml":
                continue
            with open(path) as fh:
                doc = yaml.safe_load(fh)
            if not doc or "groups" not in doc:
                continue
            for group in doc["groups"] or []:
                for check in group.get("checks") or []:
                    if check.get("type") in ("manual", "skip"):
                        continue
                    audit = check.get("audit") or ""
                    got = set()
                    for match in GET.findall(audit):
                        for res in match.split(","):
                            res = ALIAS.get(res.strip(), res.strip())
                            if not res or res.startswith("-"):
                                continue
                            got.update(ALL_EXPANDS if res == "all" else [res])
                    reads |= got
                    kinds |= set(KIND_LITERAL.findall(audit)) - {"kind"}
                    # `kind=\($kind)` emits whichever kind each listed resource is
                    if KIND_DYNAMIC.search(audit):
                        kinds |= {CATALOG[r][1] for r in got if r in CATALOG}
    return reads, kinds


def watched_gvrs():
    """Parse inventory-collector/kube/resources.go -> {(apiGroup, resource)}."""
    src = open(CSS + "/inventory-collector/kube/resources.go").read()
    start = src.index("resources := []string{")
    body = src[start:src.index("\n\t}", start)]
    out = set()
    for line in body.split("\n"):
        line = line.strip()
        if not line.startswith('"'):
            continue
        parts = line.strip('",').split("/")
        out.add(("", parts[1]) if len(parts) == 2 else (parts[0], parts[2]))
    return out


print("rbac coverage")
print("  chart      %s" % REPO)
print("  kube-bench %s" % (KUBE_BENCH if os.path.isdir(KUBE_BENCH) else "(not found)"))
print("  services   %s" % (CSS if os.path.isdir(CSS) else "(not found)"))
print()

have_kb = os.path.isdir(os.path.join(KUBE_BENCH, "cfg"))
have_css = os.path.isfile(CSS + "/inventory-collector/kube/resources.go")

bench_reads, bench_kinds = (scan_benchmarks() if have_kb else (set(), set()))

# --- 1. misconfig ClusterRole covers what the audits read ---------------------------------
if not have_kb:
    skip("kube-bench not found; cannot check misconfig RBAC (set KUBE_BENCH_DIR)")
else:
    _, granted = cluster_role_grants(render("misconfig-scanner.tpl"))
    missing = sorted(bench_reads - granted)
    if missing:
        bad("misconfig ClusterRole is missing: %s" % ", ".join(missing))
    else:
        ok("misconfig ClusterRole covers all %d resources the audits read" % len(bench_reads))
    unused = sorted(granted - bench_reads)
    if unused:
        skip("misconfig ClusterRole grants unused: %s" % ", ".join(unused))

# --- 2. inventory ClusterRole covers what the collector watches ----------------------------
if not have_css:
    skip("container-security-services not found; cannot check inventory (set CSS_DIR)")
else:
    watched = watched_gvrs()
    inv_pairs, _ = cluster_role_grants(render("inventory-collector.tpl"))
    ungranted = sorted(w for w in watched if w not in inv_pairs)
    if ungranted:
        bad("inventory watches but ClusterRole does not grant (informer fails at start): %s"
            % ", ".join("%s/%s" % (g or "core", r) for g, r in ungranted))
    else:
        ok("inventory ClusterRole covers all %d watched GVRs" % len(watched))

# --- 3. inventory watches every kind kube-bench names --------------------------------------
if not (have_kb and have_css):
    skip("need both repos to check the failed_resources join")
else:
    watched = watched_gvrs()
    kind_to_gvr = {k: (g, r) for r, (g, k) in CATALOG.items()}
    unknown = sorted(k for k in bench_kinds if k not in kind_to_gvr and k not in SYNTHESISED)
    if unknown:
        bad("kinds emitted by kube-bench that this script has no catalog entry for "
            "(add them to CATALOG): %s" % ", ".join(unknown))
    gaps = sorted(k for k in bench_kinds
                  if k in kind_to_gvr and k not in SYNTHESISED
                  and kind_to_gvr[k] not in watched)
    if gaps:
        bad("kube-bench names these but inventory does not watch them, so the console "
            "cannot join them: %s" % ", ".join(gaps))
    elif not unknown:
        ok("inventory watches all %d joinable kinds kube-bench names"
           % len([k for k in bench_kinds if k not in SYNTHESISED]))

print()
sys.exit(fail)
