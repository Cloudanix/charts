#!/usr/bin/env bash
# Render assertions for the misconfig-scanner template (RBAC + CBP benchmark
# wiring). Requires helm. Run: chart/tests/misconfig_render_test.sh
set -euo pipefail

cd "$(dirname "$0")/../.."
CHART=chart
COMMON=(-f chart/local-values.yaml --set accountId=a --set clusterIdentifier=c --set authToken=t -s templates/misconfig-scanner.tpl)
fail=0

render() { helm template cdx "$CHART" "${COMMON[@]}" "$@" 2>&1; }

# Benchmark assertions are about the kube-bench invocation, so match the command line
# itself. Grepping the whole manifest also hits comments that merely name a benchmark.
cmdline() { render "$@" | grep -m1 'command: \["kube-bench"'; }

assert_has() { # <haystack> <needle> <label>
  if grep -qF -- "$2" <<<"$1"; then echo "ok   - $3"; else echo "FAIL - $3"; fail=1; fi
}
assert_missing() {
  if grep -qF -- "$2" <<<"$1"; then echo "FAIL - $3"; fail=1; else echo "ok   - $3"; fi
}

aws_on=$(render --set clusterDomain=AWS)
assert_has "$aws_on" "kind: ServiceAccount" "ServiceAccount rendered"
assert_has "$aws_on" "kind: ClusterRole" "ClusterRole rendered"
assert_has "$aws_on" "kind: ClusterRoleBinding" "ClusterRoleBinding rendered"
assert_has "$aws_on" "serviceAccountName: misconfig-scanner-sa" "pod uses the ServiceAccount"

# The policy checks name the object that failed (failed_resources), which needs read on
# every kind their audits list. A missing kind makes kubectl exit non-zero and the check
# degrades to WARN, so pin the ones that are easy to drop by accident.
rbac=$(grep -E '^\s*resources:' <<<"$aws_on")
assert_has "$rbac" "resourcequotas" "resourcequotas granted (CBP C3.4)"
assert_has "$rbac" "poddisruptionbudgets" "poddisruptionbudgets granted (CBP C5.1)"
assert_has "$rbac" "certificatesigningrequests" "certificatesigningrequests granted (gke 4.1.6)"
assert_has "$rbac" "replicationcontrollers" "kubectl-get-all kinds granted"
# RBAC has no metadata-only read: listing Secrets exposes their data. CBP C4.2 stays
# manual precisely so this stays out. Do not add it.
assert_missing "$rbac" "secrets" "ClusterRole never grants secrets"

assert_has "$(cmdline --set clusterDomain=AWS)" '"--benchmark=eks-1.8.0,cloudanix-1.0"' "CBP appended by default (AWS)"
assert_has "$(cmdline --set clusterDomain=GCP)" '"--benchmark=gke-1.9.0,cloudanix-1.0"' "CBP appended by default (GCP)"
assert_has "$(cmdline --set clusterDomain=AZURE)" '"--benchmark=aks-1.8,cloudanix-1.0"' "CBP appended by default (AZURE)"
assert_has "$(cmdline --set clusterDomain=OCI)" '"--benchmark=oke-1.7.0,cloudanix-1.0"' "CBP appended by default (OCI)"
assert_has "$(cmdline --set clusterDomain=KUBERNETES)" '"--benchmark=cis-1.12,cloudanix-1.0"' "CBP appended by default (KUBERNETES)"

# An unrecognised domain is not an error: it falls back to the plain-Kubernetes benchmark.
# CBP needs an explicit --benchmark, so auto-detect is not an option while it is enabled.
assert_has "$(cmdline --set clusterDomain=OTHER)" '"--benchmark=cis-1.12,cloudanix-1.0"' "unknown domain falls back to cis"

# With CBP off there is nothing to append, so kube-bench auto-detects the benchmark.
aws_off=$(cmdline --set clusterDomain=AWS --set misconfigScanner.cbpEnabled=false)
assert_missing "$aws_off" "--benchmark=" "no --benchmark when CBP disabled (auto-detect)"
assert_missing "$aws_off" "cloudanix-1.0" "no CBP when disabled"

exit $fail
