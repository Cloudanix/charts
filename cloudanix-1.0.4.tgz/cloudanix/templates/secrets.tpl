apiVersion: v1
kind: Secret
metadata:
  name: cloudanix-secrets
  namespace: {{ .Release.Namespace }}
type: Opaque
data:
  {{- if and (.Values.partnerIdentifier) (.Values.userEmail) (ne .Values.partnerIdentifier "DEFAULT" ) (ne .Values.userEmail "DEFAULT" ) }}
  partner-identifier: {{ .Values.partnerIdentifier | b64enc }}
  user-email: {{ .Values.userEmail | b64enc }}
  {{- end }}
  auth-token: {{ .Values.authToken | default "DEFAULT" | b64enc }}
