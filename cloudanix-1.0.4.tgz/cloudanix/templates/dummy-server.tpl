{{- if ((.Values.dummyServer).enabled) }}
apiVersion: v1
kind: ConfigMap
metadata:
  name: dummy-server-script
  namespace: {{ .Release.Namespace }}
data:
  server.py: |
    #!/usr/bin/env python3
    import http.server
    import json
    import os
    import datetime

    DATA_DIR = "/data"
    os.makedirs(DATA_DIR, exist_ok=True)

    class Handler(http.server.BaseHTTPRequestHandler):
        def _handle(self):
            length = int(self.headers.get("Content-Length", 0))
            body_bytes = self.rfile.read(length) if length > 0 else b""

            try:
                body = json.loads(body_bytes)
            except Exception:
                body = body_bytes.decode("utf-8", errors="replace")

            # Derive filename from URL path: /csthreatsreceiver -> csthreatsreceiver.jsonl
            slug = self.path.strip("/").replace("/", "_") or "root"
            filepath = os.path.join(DATA_DIR, f"{slug}.jsonl")

            entry = {
                "timestamp": datetime.datetime.utcnow().isoformat() + "Z",
                "method": self.command,
                "path": self.path,
                "headers": dict(self.headers),
                "body": body,
            }

            with open(filepath, "a") as f:
                f.write(json.dumps(entry) + "\n")

            print(f"[{entry['timestamp']}] {self.command} {self.path} -> {filepath}", flush=True)

            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(b'{"status":"ok"}')

        def do_POST(self):
            self._handle()

        def do_PUT(self):
            self._handle()

        def do_GET(self):
            # List available files and their sizes for quick inspection
            files = []
            for name in sorted(os.listdir(DATA_DIR)):
                if name.endswith(".jsonl"):
                    path = os.path.join(DATA_DIR, name)
                    size = os.path.getsize(path)
                    with open(path) as f:
                        lines = sum(1 for _ in f)
                    files.append({"file": name, "events": lines, "bytes": size})
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({"files": files}, indent=2).encode())

        def log_message(self, format, *args):
            pass  # suppress default access log noise

    if __name__ == "__main__":
        server = http.server.HTTPServer(("", 8080), Handler)
        print(f"dummy-server listening on :8080  |  writing events to {DATA_DIR}/", flush=True)
        server.serve_forever()

---

apiVersion: apps/v1
kind: Deployment
metadata:
  name: dummy-server
  namespace: {{ .Release.Namespace }}
  labels:
    app: dummy-server
spec:
  replicas: 1
  selector:
    matchLabels:
      app: dummy-server
  template:
    metadata:
      labels:
        app: dummy-server
    spec:
      containers:
      - name: dummy-server
        image: python:3.12-alpine
        command: ["python", "/app/server.py"]
        ports:
        - containerPort: 8080
          name: http
        volumeMounts:
        - name: script
          mountPath: /app
        - name: data
          mountPath: /data
        resources:
          requests:
            memory: "64Mi"
            cpu: "50m"
          limits:
            memory: "128Mi"
            cpu: "100m"
      volumes:
      - name: script
        configMap:
          name: dummy-server-script
      - name: data
        emptyDir: {}

---

apiVersion: v1
kind: Service
metadata:
  name: dummy-server
  namespace: {{ .Release.Namespace }}
  labels:
    app: dummy-server
spec:
  ports:
  - port: 8080
    targetPort: 8080
    protocol: TCP
    name: http
  selector:
    app: dummy-server

{{- end }}
