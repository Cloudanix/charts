{{- if .Values.cilium.enabled }}
---
apiVersion: v1
kind: ServiceAccount
metadata:
  name: cilium-cni-cleanup
  namespace: {{ .Release.Namespace }}
  annotations:
    "helm.sh/hook": pre-delete
    "helm.sh/hook-weight": "-10"
    "helm.sh/hook-delete-policy": hook-succeeded,hook-failed

---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: cilium-cni-cleanup
  annotations:
    "helm.sh/hook": pre-delete
    "helm.sh/hook-weight": "-10"
    "helm.sh/hook-delete-policy": hook-succeeded,hook-failed
rules:
  - apiGroups: ["apps"]
    resources: ["daemonsets"]
    verbs: ["create", "delete", "get"]
  - apiGroups: [""]
    resources: ["pods"]
    verbs: ["list", "get"]

---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: cilium-cni-cleanup
  annotations:
    "helm.sh/hook": pre-delete
    "helm.sh/hook-weight": "-10"
    "helm.sh/hook-delete-policy": hook-succeeded,hook-failed
subjects:
  - kind: ServiceAccount
    name: cilium-cni-cleanup
    namespace: {{ .Release.Namespace }}
roleRef:
  kind: ClusterRole
  name: cilium-cni-cleanup
  apiGroup: rbac.authorization.k8s.io

---
apiVersion: batch/v1
kind: Job
metadata:
  name: cilium-cni-cleanup
  namespace: {{ .Release.Namespace }}
  annotations:
    "helm.sh/hook": pre-delete
    "helm.sh/hook-weight": "0"
    "helm.sh/hook-delete-policy": hook-succeeded,hook-failed
spec:
  ttlSecondsAfterFinished: 60
  template:
    spec:
      hostNetwork: true
      serviceAccountName: cilium-cni-cleanup
      restartPolicy: Never
      tolerations:
        - operator: Exists
      containers:
        - name: cleanup
          image: docker.io/bitnami/kubectl:latest
          command:
            - sh
            - -c
            - |
              echo "Removing Cilium CNI conflist from all nodes..."
              # Create a DaemonSet that removes the conflist on every node
              cat <<'DS' | kubectl apply -f -
              apiVersion: apps/v1
              kind: DaemonSet
              metadata:
                name: cilium-cni-cleanup-ds
                namespace: {{ .Release.Namespace }}
              spec:
                selector:
                  matchLabels:
                    app: cilium-cni-cleanup
                template:
                  metadata:
                    labels:
                      app: cilium-cni-cleanup
                  spec:
                    hostNetwork: true
                    tolerations:
                      - operator: Exists
                    containers:
                      - name: cleanup
                        image: docker.io/library/busybox:latest
                        command: ["sh", "-c", "rm -f /host/etc/cni/net.d/05-cilium.conflist && echo done"]
                        volumeMounts:
                          - name: cni-conf
                            mountPath: /host/etc/cni/net.d
                    volumes:
                      - name: cni-conf
                        hostPath:
                          path: /etc/cni/net.d
                    terminationGracePeriodSeconds: 1
              DS
              # Wait for cleanup to run on all nodes
              echo "Waiting for cleanup DaemonSet to complete..."
              sleep 15
              # Delete the cleanup DaemonSet
              kubectl delete ds cilium-cni-cleanup-ds -n {{ .Release.Namespace }} --ignore-not-found
              echo "Cilium CNI conflist removed from all nodes."
{{- end }}
