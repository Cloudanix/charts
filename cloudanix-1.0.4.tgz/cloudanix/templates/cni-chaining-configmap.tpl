{{- if and .Values.cilium.enabled (eq (default "" .Values.cilium.cni.chainingMode) "generic-veth") }}
---
apiVersion: v1
kind: ConfigMap
metadata:
  name: cni-configuration
  namespace: {{ .Release.Namespace }}
data:
  {{- if eq .Values.clusterDomain "OCI" }}
  cni-config: |-
    {
      "name": "generic-veth",
      "cniVersion": "0.3.1",
      "plugins": [
        {
          "type": "flannel",
          "delegate": {
            "hairpinMode": true,
            "isDefaultGateway": true
          }
        },
        {
          "type": "portmap",
          "capabilities": {
            "portMappings": true
          }
        },
        {
          "type": "cilium-cni"
        }
      ]
    }
  {{- else if eq .Values.clusterDomain "GCP" }}
  cni-config: |-
    {
      "name": "generic-veth",
      "cniVersion": "0.3.1",
      "plugins": [
        {
          "type": "ptp",
          "mtu": 1460,
          "ipam": {
            "type": "host-local",
            "ranges": [[{"subnet": "usePodCIDR"}]],
            "routes": [{"dst": "0.0.0.0/0"}]
          }
        },
        {
          "type": "portmap",
          "capabilities": {
            "portMappings": true
          }
        },
        {
          "type": "cilium-cni"
        }
      ]
    }
  {{- end }}
{{- end }}
