{{- if eq (include "cloudanix.vulnScanningEnabled" .) "true" }}
{{- if .Capabilities.APIVersions.Has "batch/v1" }}
apiVersion: batch/v1
{{- else }}
apiVersion: batch/v1beta1
{{- end }}
kind: CronJob
metadata:
    name: {{ .Values.vulnScannerCron.name }}
    namespace: cloudanix
spec:
    schedule: {{ .Values.vulnScannerCron.schedule | quote }}
    concurrencyPolicy: Forbid
    jobTemplate:
        spec:
            activeDeadlineSeconds: {{ add ((default 3600 .Values.vulnScannerCron.scanTimeout) | int) 60 }}
            template:
                spec:
                    serviceAccountName: {{ .Values.vulnScannerCron.serviceAccount }}
                    securityContext:
                        runAsUser: 1001
                        runAsGroup: 1001
                        runAsNonRoot: true
                        fsGroup: 1001
                        supplementalGroups: [0]        # grants access to root:root 0660 socket
                        seccompProfile:
                            type: RuntimeDefault
                    containers:
                        - name: {{ .Values.vulnScannerCron.name }}
                          image: {{ .Values.vulnScannerCron.image }}
                          imagePullPolicy: IfNotPresent
                          securityContext:
                              allowPrivilegeEscalation: false
                              readOnlyRootFilesystem: true
                              capabilities:
                                  drop: ["ALL"]
                          resources:
                              limits:
                                  memory: 2Gi
                                  cpu: "2"
                              requests:
                                  memory: 512Mi
                                  cpu: 250m
                          volumeMounts:
                              - name: config-volume
                                mountPath: /etc/cdx/config
                              - name: secret-volume
                                mountPath: /etc/cdx/secrets
                                readOnly: true
                              - name: containerd-socket
                                mountPath: {{ .Values.vulnScannerCron.containerRuntimeSocket }}
                                readOnly: true
                              - name: tmp-dir
                                mountPath: /tmp
                              - name: cache-dir
                                mountPath: /var/cache/vuln-scanner-cron
                    volumes:
                        - name: config-volume
                          configMap:
                            name: {{ .Values.vulnScannerCron.configMapName }}
                        - name: secret-volume
                          secret:
                              secretName: cloudanix-secrets
                        - name: containerd-socket
                          hostPath:
                              path: {{ .Values.vulnScannerCron.containerRuntimeSocket }}
                              type: Socket
                        - name: tmp-dir
                          emptyDir: {}
                        - name: cache-dir
                          emptyDir: {}
                    restartPolicy: Never

---
apiVersion: v1
kind: ConfigMap
metadata:
    name: {{ .Values.vulnScannerCron.configMapName }}
    namespace: cloudanix
data:
    config.yaml: |
        chartVersion:  {{ .Chart.Version }}
        releaseName: {{ .Release.Name }}
        version: {{ required "Version is required!" .Values.vulnScannerCron.version }}
        common:
          listenerUrl: {{ required "A valid URL is required!" .Values.vulnScannerCron.listenerUrl }}
          requestTimeout: {{ .Values.requestTimeout | default 30 }}
          httpMaxRetries: {{ .Values.httpMaxRetries | default 3 }}
          logLevel: {{ .Values.logLevel | default "info" }}
          accountId: {{ required "Account ID is required!" .Values.accountId }}
          clusterIdentifier: {{ required "Cluster Identifier is required!" .Values.clusterIdentifier }}
          {{- if and (.Values.clusterName) (ne .Values.clusterName "DEFAULT") }}
          clusterName:  {{ .Values.clusterName }}
          {{- else if (.Values.clusterIdentifier) }}
          clusterName: {{ required "Cluster Name is required!" (splitList "/" .Values.clusterIdentifier) | last }}
          {{- end }}
          clusterDomain: {{ required "Cluster Domain is required!" .Values.clusterDomain }}
        vulnScannerCron:
          templateType: KUBERNETESRUNTIMEIMAGESCAN
          {{- if and (.Values.partnerIdentifier) (.Values.userEmail) (ne .Values.partnerIdentifier "DEFAULT" ) (ne .Values.userEmail "DEFAULT" ) }}
          userName: {{ required "User Name is required!" .Values.userName }}
          accountName: {{ required "Account Name is required!" .Values.accountName }}
          accountType: {{ required "Account Type is required!" .Values.accountType }}
          enabled: false
          {{- else if and (.Values.authToken) (ne .Values.authToken "DEFAULT" ) }}
          enabled: true
          {{- end }}
          scanTimeout: {{ required "Scan Timeout is required!" .Values.vulnScannerCron.scanTimeout }}
          concurrency: {{ required "Concurrency is required!" .Values.vulnScannerCron.concurrency }}
          ignoreUnfixed: {{ required "Ignore Unfixed is required!" .Values.vulnScannerCron.ignoreUnfixed }}
          cacheDir: /var/cache/vuln-scanner-cron
          cacheTTLInHours: 24

---
apiVersion: v1
kind: ServiceAccount
metadata:
    name: {{ .Values.vulnScannerCron.serviceAccount }}
    namespace: cloudanix

---
kind: ClusterRole
apiVersion: rbac.authorization.k8s.io/v1
metadata:
    name: {{ .Values.vulnScannerCron.clusterRole }}
rules:
    - apiGroups: [""]
      resources: ["pods"]
      verbs: ["get", "list"]

---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
    name: {{ .Values.vulnScannerCron.serviceAccount }}
subjects:
    - kind: ServiceAccount
      name: {{ .Values.vulnScannerCron.serviceAccount }}
      namespace: cloudanix
roleRef:
    kind: ClusterRole
    name: {{ .Values.vulnScannerCron.clusterRole }}
    apiGroup: rbac.authorization.k8s.io

{{- end }}
