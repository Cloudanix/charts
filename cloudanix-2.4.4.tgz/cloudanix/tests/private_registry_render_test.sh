#!/usr/bin/env bash
# Render assertions for trustedImageRepositories (chart/README.md, "Keep the sensors on your
# registry"): config-manager gets CDX_TRUSTED_IMAGE_REPOSITORIES on every pod it runs as
# (CronJob and the post-upgrade Job), only when the value is set, and the Falco registry
# overrides reach the Falco and falcoctl images.
# Requires helm. Run: chart/tests/private_registry_render_test.sh
set -euo pipefail

cd "$(dirname "$0")/../.."
CHART=chart
COMMON=(-f chart/local-values.yaml --set accountId=a --set clusterIdentifier=c --set clusterDomain=AWS --set authToken=t)
REG=123456789012.dkr.ecr.us-east-1.amazonaws.com/docker-hub
fail=0

render() { helm template cdx "$CHART" "${COMMON[@]}" "$@" 2>&1; }

assert_count() { # <haystack> <needle> <want> <label>
  local got
  got=$(grep -cF -- "$2" <<<"$1" || true)
  if [[ "$got" == "$3" ]]; then echo "ok   - $4"; else echo "FAIL - $4 (got $got, want $3)"; fail=1; fi
}

# Unset: no env var, so config-manager trusts only its built-in repositories.
plain=$(render -s templates/config-manager.tpl)
assert_count "$plain" "CDX_TRUSTED_IMAGE_REPOSITORIES" 0 "no trusted-repository env by default"

# Upgrade renders the CronJob plus the one-off post-upgrade Job; both run config-manager.
trusted=$(render --is-upgrade -s templates/config-manager.tpl \
  --set-json "trustedImageRepositories=[\"$REG/cloudanix/\",\"registry.example.com/team/\"]")
assert_count "$trusted" "name: CDX_TRUSTED_IMAGE_REPOSITORIES" 2 "env on the CronJob and the post-upgrade Job"
assert_count "$trusted" "value: \"$REG/cloudanix/,registry.example.com/team/\"" 2 "entries joined with commas"

# The README recipe moves Falco and falcoctl to the same registry.
falco=$(render --set "falco.image.registry=$REG" --set "falco.falcoctl.image.registry=$REG")
assert_count "$falco" "image: $REG/falcosecurity/falco:" 1 "Falco image from the private registry"
assert_count "$falco" "image: $REG/falcosecurity/falcoctl:" 1 "falcoctl image from the private registry"
assert_count "$falco" "image: docker.io/falcosecurity/" 0 "no Falco image left on Docker Hub"

exit $fail
