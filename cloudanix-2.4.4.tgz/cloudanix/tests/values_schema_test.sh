#!/usr/bin/env bash
# chart/values.schema.json: what Helm accepts before rendering.
#   - the chart's defaults, values-oke.yaml and every flag the console's install command sends
#   - chart/cloudanix-values.yaml, the customer starter file, as shipped (all commented: a
#     no-op) and with every example uncommented (each example is a valid key)
#   - typos and wrong types a customer is likely to make are refused, not silently ignored
# Requires helm and the subcharts in chart/charts (helm dependency build chart).
# Run: chart/tests/values_schema_test.sh
set -euo pipefail

cd "$(dirname "$0")/../.."
fail=0
work=$(mktemp -d "${TMPDIR:-/tmp}/cdx-schema.XXXXXX")
trap 'rm -rf "$work"' EXIT

ok() { echo "ok   - $1"; }
bad() { echo "FAIL - $1"; fail=1; }
render() { helm template cloudanix chart --namespace cloudanix "$@" >/dev/null 2>&1; }
accepts() { # <label> <helm args...>
  local label=$1; shift
  if render "$@"; then ok "accepts $label"; else bad "accepts $label"; fi
}
refuses() { # <label> <helm args...>: refused by the schema, not by a template
  local label=$1; shift
  local out
  if out=$(helm template cloudanix chart --namespace cloudanix "$@" 2>&1); then
    bad "refuses $label (rendered)"
  elif grep -q "don't meet the specifications of the schema" <<<"$out"; then
    ok "refuses $label"
  else
    bad "refuses $label (failed, but not on the schema: $(head -1 <<<"$out"))"
  fi
}

# What the console's install command sends (core.js buildCwppHelmInstallCommand).
console=(--set authToken=tok --set accountId=5f2a9c --set clusterIdentifier=c-1
  --set clusterName=prod --set clusterDomain=AWS)

accepts "the chart defaults with the console's flags" "${console[@]}"
accepts "the OKE overlay" "${console[@]}" --set clusterDomain=OCI -f chart/values-oke.yaml
accepts "an empty clusterName" "${console[@]}" --set clusterName=
accepts "all-digit account and cluster ids (--set makes them numbers)" \
  "${console[@]}" --set accountId=12345 --set clusterIdentifier=987
# --set makes an all-digit token or cluster name an int64; the templates compare and split
# their string form, so a cluster named 2024 installs and keeps its name.
digits=$(helm template cloudanix chart --namespace cloudanix --set authToken=123456 --set accountId=42 \
  --set clusterIdentifier=987 --set clusterName=2024 --set clusterDomain=AWS 2>&1) && rc=0 || rc=$?
if [ "$rc" = 0 ]; then ok "renders all-digit authToken, ids and clusterName"; else bad "renders all-digit authToken, ids and clusterName: $(head -1 <<<"$digits")"; fi
if grep -q "clusterName: *2024" <<<"$digits"; then ok "all-digit clusterName is kept"; else bad "all-digit clusterName is kept"; fi
if grep -q ": $(printf 123456 | base64)" <<<"$digits"; then ok "all-digit authToken lands in the Secret"; else bad "all-digit authToken lands in the Secret"; fi
fallback=$(helm template cloudanix chart --namespace cloudanix --set authToken=t --set accountId=a \
  --set clusterIdentifier=987 --set clusterDomain=AWS 2>&1) && rc=0 || rc=$?
if [ "$rc" = 0 ] && grep -q "clusterName: *987" <<<"$fallback"; then ok "unset clusterName falls back to an all-digit clusterIdentifier"; else bad "unset clusterName falls back to an all-digit clusterIdentifier: $(head -1 <<<"$fallback")"; fi
if grep -q "<nil>" <<<"$fallback"; then bad "an unset clusterName never renders as <nil>"; else ok "an unset clusterName never renders as <nil>"; fi
accepts "the capability picker" "${console[@]}" --set falco.enabled=false \
  --set 'capabilities=vulnerabilities\,compliance'
accepts "capabilities=all with traffic" "${console[@]}" --set capabilities=all --set cilium.enabled=true
accepts "sensor sizing flags" "${console[@]}" \
  --set inventoryCollector.resources.requests.cpu=250m,inventoryCollector.resources.requests.memory=512Mi,inventoryCollector.resources.limits.cpu=1,inventoryCollector.resources.limits.memory=1Gi

# Keys a past chart had and this one ignores stay accepted, so a values file kept from an
# older release still upgrades (v2.0.x set <component>.version and traffic-exporter tuning;
# v1.x networkMonitoring and the *Cron blocks).
accepts "retired keys from older charts" "${console[@]}" --set threatMonitor.version=v2.0.0 \
  --set trafficExporter.dedupeTtlSeconds=60 --set trafficExporter.apiToken=x \
  --set networkMonitoring.enabled=true --set configCron.schedule=x
for tag in v2.0.2 v2.1.4; do
  if git show "$tag:chart/values.yaml" > "$work/$tag-values.yaml" 2>/dev/null; then
    accepts "the full values.yaml of $tag" "${console[@]}" -f "$work/$tag-values.yaml"
  fi
done

starter=chart/cloudanix-values.yaml
accepts "$starter as shipped" "${console[@]}" -f "$starter"
# Example lines are "# <yaml>"; prose lines are "## ...". Uncommenting every example must
# give a valid file, so no example in the starter can drift from the chart.
sed -n 's/^# //p' "$starter" > "$work/starter-uncommented.yaml"
check_keys=$(grep -cE '^[a-zA-Z]' "$work/starter-uncommented.yaml" || true)
if [ "$check_keys" -ge 5 ]; then ok "starter has examples to uncomment ($check_keys top-level keys)"; else bad "starter has examples to uncomment (got $check_keys)"; fi
accepts "$starter with every example uncommented" "${console[@]}" -f "$work/starter-uncommented.yaml"
rendered=$(helm template cloudanix chart --namespace cloudanix "${console[@]}" -f "$work/starter-uncommented.yaml")
if grep -q "priorityClassName: cloudanix-agents" <<<"$rendered"; then ok "starter examples reach the pods"; else bad "starter examples reach the pods"; fi
# The starter is copied to Cloudanix/artifacts with the chart (scripts/publish-chart.sh) and
# must stay a no-op until edited.
if [ -z "$(grep -vE '^(#|$)' "$starter" || true)" ]; then ok "$starter sets nothing until edited"; else bad "$starter sets nothing until edited"; fi

refuses "a top-level tolerations (belongs under scheduling)" "${console[@]}" \
  --set-json 'tolerations=[{"key":"a","operator":"Exists"}]'
refuses "scheduling.toleration (misspelled)" "${console[@]}" \
  --set-json 'scheduling.toleration=[{"key":"a","operator":"Exists"}]'
refuses "a misspelled component key" "${console[@]}" --set-string 'threatMonitor.podAnotations.a=b'
# Labels and annotations are stringified by the chart (custom_labels_render_test.py); a
# nodeSelector is rendered as given, and Kubernetes refuses a non-string value there.
accepts "an unquoted boolean annotation (the chart stringifies it)" "${console[@]}" \
  --set 'scheduling.podAnnotations.a=true'
refuses "an unquoted boolean nodeSelector value" "${console[@]}" --set 'scheduling.nodeSelector.a=true'
refuses "a list as an annotation value" "${console[@]}" --set-json 'scheduling.podAnnotations={"a":[1]}'
refuses "an unknown capability" "${console[@]}" --set capabilities=threat
refuses "a toleration operator Kubernetes rejects" "${console[@]}" \
  --set-json 'scheduling.tolerations=[{"key":"a","operator":"In"}]'
refuses "a dnsPolicy Kubernetes rejects" "${console[@]}" --set dnsPolicy=clusterfirst
refuses "an imagePullSecret without a name" "${console[@]}" --set-json 'imagePullSecrets=[{}]'

# A customer on their own registry: the flags the console's install command adds
# (core.js cwppImageRegistryFlags). config-manager checks the same shape at run time.
reg=123456789012.dkr.ecr.us-east-1.amazonaws.com/docker-hub
sensor_images=()
for sensor in configManager:config-manager threatMonitor:threat-monitor inventoryCollector:inventory-collector \
  trafficExporter:traffic-exporter vulnScanner:vuln-scanner misconfigScanner:misconfig-scanner; do
  sensor_images+=(--set "${sensor%%:*}.image=$reg/cloudanix/${sensor#*:}:v2.3.7")
done
accepts "the console's private-registry flags" "${console[@]}" \
  --set-json "trustedImageRepositories=[\"$reg/cloudanix/\"]" \
  --set "falco.image.registry=$reg" --set "falco.falcoctl.image.registry=$reg" "${sensor_images[@]}"
accepts "a registry with a port and no trailing slash" "${console[@]}" \
  --set-json 'trustedImageRepositories=["registry.example.com:5000/cloudanix"]'
refuses "a trusted repository with a scheme" "${console[@]}" \
  --set-json 'trustedImageRepositories=["https://registry.example.com/cloudanix/"]'
refuses "a trusted repository with a tag" "${console[@]}" \
  --set-json 'trustedImageRepositories=["registry.example.com/cloudanix:v1"]'
refuses "a bare host as a trusted repository" "${console[@]}" \
  --set-json 'trustedImageRepositories=["registry.example.com"]'
refuses "a short Docker Hub form as a trusted repository" "${console[@]}" \
  --set-json 'trustedImageRepositories=["cloudanix/"]'
refuses "trustedImageRepositories as a string" "${console[@]}" \
  --set "trustedImageRepositories=$reg/cloudanix/"

exit "$fail"
