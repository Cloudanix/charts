{{- if eq (include "cloudanix.runtimeThreatEnabled" .) "true" }}
{{- if .Capabilities.APIVersions.Has "batch/v1" }}
apiVersion: batch/v1
{{- else }}
apiVersion: batch/v1beta1
{{- end }}
kind: CronJob
metadata:
  name: {{ .Values.misconfigCron.name }}
  namespace: cloudanix
  labels:
    {{- with .Values.misconfigCron.labels }}
    {{ toYaml . }}
    {{- end }}
spec:
  schedule: {{ .Values.misconfigCron.schedule | quote }}
  concurrencyPolicy: Forbid
  jobTemplate:
    spec:
      template:
        metadata:
          labels:
            app: kube-bench
        spec:
          hostPID: true
          restartPolicy: Never
          containers:
          - name: misconfig-cron
            image: {{ .Values.misconfigCron.image }}
            imagePullPolicy: IfNotPresent
            {{- if eq .Values.clusterDomain "AWS" }}
            command: ["kube-bench", "--httpoutput=true", "--benchmark=eks-1.1.0"]
            {{- else if eq .Values.clusterDomain "GCP" }}
            command: ["kube-bench", "--httpoutput=true", "--benchmark=gke-1.2.0"]
            {{- else if eq .Values.clusterDomain "AZURE" }}
            command: ["kube-bench", "--httpoutput=true", "--benchmark=aks-1.0"]
            {{- else if eq .Values.clusterDomain "KUBERNETES" }}
            command: ["kube-bench", "--httpoutput=true", "--benchmark=cis-1.24"]
            {{- else }}
            command: ["kube-bench", "--httpoutput=true"]
            {{- end }}
            # command: ["kube-bench", "--include-test-output", "--noremediations", "--noresults", "--nototals", "--httpoutput=true"]
            env:
            - name: NODE_NAME
              valueFrom:
                fieldRef:
                  fieldPath: spec.nodeName
            volumeMounts:
            - name: var-lib-etcd
              mountPath: /var/lib/etcd
              readOnly: true
            - name: var-lib-kubelet
              mountPath: /var/lib/kubelet
              readOnly: true
            - name: var-lib-kube-scheduler
              mountPath: /var/lib/kube-scheduler
              readOnly: true
            - name: var-lib-kube-controller-manager
              mountPath: /var/lib/kube-controller-manager
              readOnly: true
            - name: etc-systemd
              mountPath: /etc/systemd
              readOnly: true
            - name: lib-systemd
              mountPath: /lib/systemd/
              readOnly: true
            - name: srv-kubernetes
              mountPath: /srv/kubernetes/
              readOnly: true
            - name: etc-kubernetes
              mountPath: /etc/kubernetes
              readOnly: true
              # /usr/local/mount-from-host/bin is mounted to access kubectl / kubelet, for auto-detecting the Kubernetes version.
              # You can omit this mount if you specify --version as part of the command.
            - name: usr-bin
              mountPath: /usr/local/mount-from-host/bin
              readOnly: true
            - name: etc-cni-netd
              mountPath: /etc/cni/net.d/
              readOnly: true
            - name: opt-cni-bin
              mountPath: /opt/cni/bin/
              readOnly: true
            - name: var-tmp-dump
              mountPath: /var/tmp/dump
            - name: misconfig-volume
              mountPath: /etc/cdx/config
              readOnly: true
            - name: cloudanix-secrets-volume
              mountPath: /etc/cdx/secrets
              readOnly: true
            resources:
              requests:
                memory: "256Mi"
                cpu: "250m"
              limits:
                memory: "512Mi"
                cpu: "500m"
          volumes:
          - name: var-lib-etcd
            hostPath:
              path: "/var/lib/etcd"
          - name: var-lib-kubelet
            hostPath:
              path: "/var/lib/kubelet"
          - name: var-lib-kube-scheduler
            hostPath:
              path: "/var/lib/kube-scheduler"
          - name: var-lib-kube-controller-manager
            hostPath:
              path: "/var/lib/kube-controller-manager"
          - name: etc-systemd
            hostPath:
              path: "/etc/systemd"
          - name: lib-systemd
            hostPath:
              path: "/lib/systemd"
          - name: srv-kubernetes
            {{- if eq .Values.clusterDomain "GCP" }}
            emptyDir: {}
            {{- else }}
            hostPath:
              path: "/srv/kubernetes"
            {{- end }}
          - name: etc-kubernetes
            hostPath:
              path: "/etc/kubernetes"
          - name: usr-bin
            hostPath:
              path: "/usr/bin"
          - name: etc-cni-netd
            hostPath:
              path: "/etc/cni/net.d/"
          - name: opt-cni-bin
            {{- if eq .Values.clusterDomain "GCP" }}
            emptyDir: {}
            {{- else }}
            hostPath:
              path: "/opt/cni/bin/"
            {{- end }}
          - name: var-tmp-dump
            hostPath:
              path: "/var/tmp/dump"
          - name: misconfig-volume
            configMap:
              name: {{ .Values.misconfigCron.configMapName }}
          - name: cloudanix-secrets-volume
            secret:
              secretName: cloudanix-secrets

---

apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ .Values.misconfigCron.configMapName }}
  namespace: cloudanix
data:
  config.yaml: |
    chartVersion:  {{ .Chart.Version }}
    releaseName: {{ .Release.Name }}
    version: {{ required "Version is required!" .Values.misconfigCron.version }}
    common:
      listenerUrl: {{ required "A valid URL is required!" .Values.misconfigCron.listenerUrl }}
      requestTimeout: {{ .Values.requestTimeout | default 30 }}
      httpMaxRetries: {{ .Values.httpMaxRetries | default 3 }}
      logLevel: {{ .Values.logLevel | default "info" }}
      accountId: {{ required "Account Id is required!" .Values.accountId }}
      clusterIdentifier: {{ required "Cluster Identifier is required!" .Values.clusterIdentifier }}
      {{- if and (.Values.clusterName) (ne .Values.clusterName "DEFAULT") }}
      clusterName:  {{ .Values.clusterName }}
      {{- else if (.Values.clusterIdentifier) }}
      clusterName: {{ required "Cluster Name is required!" (splitList "/" .Values.clusterIdentifier) | last }}
      {{- end }}
      clusterDomain: {{ required "Cluster Domain is required!" .Values.clusterDomain }}
    misconfigCron:
      templateType: {{ required "misconfigCron.templateType is required!" .Values.misconfigCron.templateType }}
      {{- if and (.Values.partnerIdentifier) (.Values.userEmail) (ne .Values.partnerIdentifier "DEFAULT" ) (ne .Values.userEmail "DEFAULT" ) }}
      userName: {{ required "User Name is required!" .Values.userName }}
      accountName: {{ required "Account Name is required!" .Values.accountName }}
      accountType: {{ required "Account Type is required!" .Values.accountType }}
      enabled: false
      {{- else if and (.Values.authToken) (ne .Values.authToken "DEFAULT" ) }}
      enabled: true
      {{- end }}
---
{{- end }}
