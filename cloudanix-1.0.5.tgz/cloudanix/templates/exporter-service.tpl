{{- if eq (include "cloudanix.exporterServiceEnabled" .) "true" }}
---
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ .Values.networkMonitoring.exporterService.name }}-config
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "cloudanix.labels" . | nindent 4 }}
    component: exporter-service
data:
  config.yaml: |
    common:
      listenerUrl: {{ .Values.networkMonitoring.exporterService.backend.url | quote }}
      requestTimeout: {{ .Values.requestTimeout | default 30 }}
      httpMaxRetries: {{ .Values.httpMaxRetries | default 3 }}
      bufferSize: {{ .Values.networkMonitoring.exporterService.config.sender.bufferSize }}
      bufferDuration: {{ .Values.networkMonitoring.exporterService.config.sender.bufferDuration }}
      logLevel: {{ .Values.networkMonitoring.exporterService.config.logging.level | default "info" }}
      accountId: {{ required "Account Id is required!" .Values.accountId }}
      clusterIdentifier: {{ required "Cluster Identifier is required!" .Values.clusterIdentifier }}
      {{- if and (.Values.clusterName) (ne .Values.clusterName "DEFAULT") }}
      clusterName: {{ .Values.clusterName }}
      {{- end }}
      clusterDomain: {{ required "Cluster Domain is required!" .Values.clusterDomain }}
    exporterService:
      dedupeTtlSeconds: {{ .Values.networkMonitoring.exporterService.config.dedupe.ttlSeconds }}
      dedupeShardCount: {{ .Values.networkMonitoring.exporterService.config.dedupe.shardCount }}
      dedupeMaxEntriesPerShard: {{ .Values.networkMonitoring.exporterService.config.dedupe.maxEntriesPerShard }}
      flusherTickIntervalMs: {{ .Values.networkMonitoring.exporterService.config.flusher.tickIntervalMs }}
      flusherMaxPopsPerTick: {{ .Values.networkMonitoring.exporterService.config.flusher.maxPopsPerTick }}
      numReceiverGoroutines: {{ .Values.networkMonitoring.exporterService.config.ingest.numReceiverGoroutines }}
      inputBuffer: {{ .Values.networkMonitoring.exporterService.config.ingest.inputBuffer }}
      {{- if .Values.networkMonitoring.exporterService.config.ingest.ignoreNamespaces }}
      ignoreNamespaces:
        {{- range .Values.networkMonitoring.exporterService.config.ingest.ignoreNamespaces }}
        - {{ . | quote }}
        {{- end }}
      {{- else }}
      ignoreNamespaces: []
      {{- end }}
      {{- if .Values.networkMonitoring.exporterService.config.ingest.allowedNamespaces }}
      allowedNamespaces:
        {{- range .Values.networkMonitoring.exporterService.config.ingest.allowedNamespaces }}
        - {{ . | quote }}
        {{- end }}
      {{- else }}
      allowedNamespaces: []
      {{- end }}
      templateType: {{ required "networkMonitoring.exporterService.templateType is required!" .Values.networkMonitoring.exporterService.templateType }}
      {{- if and (.Values.authToken) (ne .Values.authToken "DEFAULT") }}
      enabled: true
      {{- end }}

---
apiVersion: v1
kind: ServiceAccount
metadata:
  name: {{ .Values.networkMonitoring.exporterService.name }}
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "cloudanix.labels" . | nindent 4 }}
    component: exporter-service

---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: {{ .Release.Namespace }}-{{ .Values.networkMonitoring.exporterService.name }}
  labels:
    {{- include "cloudanix.labels" . | nindent 4 }}
    component: exporter-service
rules:
  - apiGroups: [""]
    resources: ["pods", "namespaces"]
    verbs: ["get", "list"]

---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: {{ .Release.Namespace }}-{{ .Values.networkMonitoring.exporterService.name }}
  labels:
    {{- include "cloudanix.labels" . | nindent 4 }}
    component: exporter-service
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: {{ .Release.Namespace }}-{{ .Values.networkMonitoring.exporterService.name }}
subjects:
  - kind: ServiceAccount
    name: {{ .Values.networkMonitoring.exporterService.name }}
    namespace: {{ .Release.Namespace }}

---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ .Values.networkMonitoring.exporterService.name }}
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "cloudanix.labels" . | nindent 4 }}
    component: exporter-service
    {{- with .Values.networkMonitoring.exporterService.labels }}
    {{- toYaml . | nindent 4 }}
    {{- end }}
spec:
  replicas: {{ .Values.networkMonitoring.exporterService.replicaCount }}
  selector:
    matchLabels:
      app: {{ .Values.networkMonitoring.exporterService.name }}
  template:
    metadata:
      labels:
        app: {{ .Values.networkMonitoring.exporterService.name }}
        {{- include "cloudanix.selectorLabels" . | nindent 8 }}
        component: exporter-service
    spec:
      serviceAccountName: {{ .Values.networkMonitoring.exporterService.name }}
      
      securityContext:
        runAsNonRoot: {{ .Values.networkMonitoring.exporterService.securityContext.runAsNonRoot }}
        runAsUser: {{ .Values.networkMonitoring.exporterService.securityContext.runAsUser }}
        fsGroup: {{ .Values.networkMonitoring.exporterService.securityContext.fsGroup }}
        seccompProfile:
          type: RuntimeDefault
      
      containers:
      - name: exporter
        image: {{ .Values.networkMonitoring.exporterService.image }}
        imagePullPolicy: IfNotPresent
        
        securityContext:
          allowPrivilegeEscalation: false
          readOnlyRootFilesystem: true
          runAsNonRoot: true
          runAsUser: {{ .Values.networkMonitoring.exporterService.securityContext.runAsUser }}
          capabilities:
            drop:
              - ALL
        
        args:
          - -config
          - /app/config/config.yaml
        
        env:
        - name: HUBBLE_RELAY_ADDR
          value: {{ .Values.networkMonitoring.exporterService.hubbleRelay.address | quote }}
        {{- if .Values.networkMonitoring.exporterService.backend.apiToken }}
        - name: BACKEND_API_TOKEN
          valueFrom:
            secretKeyRef:
              name: {{ .Values.networkMonitoring.exporterService.name }}-secret
              key: api-token
        {{- end }}
        
        volumeMounts:
        - name: config
          mountPath: /app/config
          readOnly: true
        - name: cloudanix-secrets-volume
          mountPath: /etc/cdx/secrets
          readOnly: true
        - name: tmp
          mountPath: /tmp
        
        resources:
          {{- toYaml .Values.networkMonitoring.exporterService.resources | nindent 10 }}
      
      volumes:
      - name: config
        configMap:
          name: {{ .Values.networkMonitoring.exporterService.name }}-config
      - name: cloudanix-secrets-volume
        secret:
          secretName: cloudanix-secrets
      - name: tmp
        emptyDir: {}
      
      terminationGracePeriodSeconds: 30

---
apiVersion: v1
kind: Service
metadata:
  name: {{ .Values.networkMonitoring.exporterService.name }}
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "cloudanix.labels" . | nindent 4 }}
    component: exporter-service
spec:
  type: ClusterIP
  ports:
  - name: metrics
    port: 9090
    targetPort: 9090
    protocol: TCP
  selector:
    app: {{ .Values.networkMonitoring.exporterService.name }}

{{- if .Values.networkMonitoring.exporterService.backend.apiToken }}
---
apiVersion: v1
kind: Secret
metadata:
  name: {{ .Values.networkMonitoring.exporterService.name }}-secret
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "cloudanix.labels" . | nindent 4 }}
    component: exporter-service
type: Opaque
stringData:
  api-token: {{ .Values.networkMonitoring.exporterService.backend.apiToken | quote }}
{{- end }}
{{- end }}
