{{- if eq (include "cloudanix.runtimeThreatEnabled" .) "true" }}
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ .Values.inventoryService.name }}
  namespace: cloudanix
  labels:
    {{- with .Values.inventoryService.labels }}
    {{ toYaml . }}
    {{- end }}
spec:
  replicas: 1
  selector:
    matchLabels:
      {{- with .Values.inventoryService.labels }}
      {{ toYaml . }}
      {{- end }}
  template:
    metadata:
      labels:
        {{- with .Values.inventoryService.labels }}
        {{ toYaml . }}
        {{- end }}
    spec:
      {{- if hasKey .Values "dnsPolicy" }}
      dnsPolicy: {{ .Values.dnsPolicy }}
      {{- end }}
      {{- with .Values.dnsConfig }}
      dnsConfig:
        {{- toYaml . }}
      {{- end }}
      serviceAccountName: {{ .Values.inventoryService.serviceAccount }}
      automountServiceAccountToken: true
      containers:
      - name: {{ .Values.inventoryService.name }}
        image: {{ .Values.inventoryService.image }}
        imagePullPolicy: IfNotPresent
        ports:
        - containerPort: 8080
        volumeMounts:
        - name: config-volume
          mountPath: /etc/cdx/config
          readOnly: true
        - name: cloudanix-secrets-volume
          mountPath: /etc/cdx/secrets
          readOnly: true
        resources:
          requests:
            memory: "256Mi"
            cpu: "250m"
          limits:
            memory: "512Mi"
            cpu: "500m"
      volumes:
        - name: config-volume
          configMap:
            name: {{ .Values.inventoryService.configMapName }}
        - name: cloudanix-secrets-volume
          secret:
            secretName: cloudanix-secrets
      terminationGracePeriodSeconds: 60

---

apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ .Values.inventoryService.configMapName }}
  namespace: cloudanix
data:
  config.yaml: |
    chartVersion:  {{ .Chart.Version }}
    releaseName: {{ .Release.Name }}
    listenerUrl: {{ required "A valid URL is required!" .Values.inventoryService.listenerUrl }}
    version:  {{ .Values.inventoryService.version }}
    accountId: {{ required "Account Id is required!" .Values.accountId }}
    clusterIdentifier: {{ required "Cluster Identifier is required!" .Values.clusterIdentifier }}
    {{- if and (.Values.clusterName) (ne .Values.clusterName "DEFAULT") }}
    clusterName:  {{ .Values.clusterName }}
    {{- else if (.Values.clusterIdentifier) }}
    clusterName: {{ required "Cluster Name is required!" (splitList "/" .Values.clusterIdentifier) | last }}
    {{- end }}
    clusterDomain: {{ required "Cluster Domain is required!" .Values.clusterDomain }}
    bufferSize:  {{ .Values.inventoryService.bufferSize }}
    bufferDuration:  {{ .Values.inventoryService.bufferDuration }}
    ignoreDuplicates:  {{ .Values.inventoryService.ignoreDuplicates }}
    {{- if and (.Values.partnerIdentifier) (.Values.userEmail) (ne .Values.partnerIdentifier "DEFAULT" ) (ne .Values.userEmail "DEFAULT" ) }}
    userName: {{ required "User Name is required!" .Values.userName }}
    accountName: {{ required "Account Name is required!" .Values.accountName }}
    accountType: {{ required "Account Type is required!" .Values.accountType }}
    enabled: false
    {{- else if and (.Values.authToken) (ne .Values.authToken "DEFAULT" ) }}
    enabled: true
    {{- end }}

---

apiVersion: v1
kind: ServiceAccount
metadata:
  name: {{ .Values.inventoryService.serviceAccount }}
  namespace: cloudanix

---

kind: ClusterRole
apiVersion: rbac.authorization.k8s.io/v1
metadata:
  name: {{ .Values.inventoryService.clusterRole }}
  namespace: cloudanix
rules:
- apiGroups: ["","apps","batch","storage.k8s.io"]
  resources: ["pods","replicasets","deployments","statefulsets","daemonsets","jobs","cronjobs","services","endpoints","persistentvolumes","storageclasses","nodes","namespaces"]
  verbs: ["get", "watch", "list"]

---

apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: {{ .Values.inventoryService.name }}
  namespace: cloudanix
subjects:
- kind: ServiceAccount
  name: {{ .Values.inventoryService.serviceAccount }}
  namespace: cloudanix
roleRef:
  kind: ClusterRole
  name: {{ .Values.inventoryService.clusterRole }}
  apiGroup: rbac.authorization.k8s.io
{{- end }}