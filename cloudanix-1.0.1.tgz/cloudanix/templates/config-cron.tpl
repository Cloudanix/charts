{{- if eq (include "cloudanix.runtimeThreatEnabled" .) "true" }}
{{- if .Capabilities.APIVersions.Has "batch/v1" }}
apiVersion: batch/v1
{{- else }}
apiVersion: batch/v1beta1
{{- end }}
kind: CronJob
metadata:
  name: {{ .Values.configCron.name }}
  namespace: cloudanix
  labels:
    {{- with .Values.configCron.labels }}
    {{ toYaml . }}
    {{- end }}
spec:
  {{- if and (.Values.partnerIdentifier) (.Values.userEmail) (ne .Values.partnerIdentifier "DEFAULT") (ne .Values.userEmail "DEFAULT") }}
  schedule: "*/5 * * * *"
  {{- else if and (.Values.authToken) (ne .Values.authToken "DEFAULT") }}
  schedule: {{ .Values.configCron.schedule | quote }}
  {{- else }}
  schedule: "*/5 * * * *"
  {{- end }}
  jobTemplate:
    spec:
      template:
        spec:
          serviceAccountName: config-cron-sa
          containers:
          - name: config-cron
            image: {{ .Values.configCron.image }}
            imagePullPolicy: IfNotPresent
            volumeMounts:
            - name: config-volume
              mountPath: /etc/cdx/config
              readOnly: true
            - name: cloudanix-secrets-volume
              mountPath: /etc/cdx/secrets
              readOnly: true
            resources:
              requests:
                memory: "256Mi"
                cpu: "250m"
              limits:
                memory: "512Mi"
                cpu: "500m"
          volumes:
            - name: config-volume
              configMap:
                name: config-cron-cm
            - name: cloudanix-secrets-volume
              secret:
                secretName: cloudanix-secrets
          restartPolicy: Never

---

apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ .Values.configCron.configMapName }}
  namespace: cloudanix
data:
  config.yaml: |
    dateValue:  {{ add (now | date "4") 5 }}
    chartVersion:  {{ .Chart.Version }}
    releaseName: {{ .Release.Name }}
    version: {{ required "Version is required!" .Values.configCron.version }}
    configUrl: {{ required "A valid URL is required!" .Values.configCron.configURL }}
    {{- if and (.Values.partnerIdentifier) (.Values.userEmail) (ne .Values.partnerIdentifier "DEFAULT") (ne .Values.userEmail "DEFAULT") }}
    organizationId: {{ .Values.organizationId }}
    userName: {{ .Values.userName }}
    accountName: {{ .Values.accountName }}
    accountType: {{ .Values.accountType }}
    {{- end }}
    accountId: {{ required "Account Id is required!" .Values.accountId }}
    clusterIdentifier: {{ required "Cluster Identifier is required!" .Values.clusterIdentifier }}
    {{- if and (.Values.clusterName) (ne .Values.clusterName "DEFAULT") }}
    clusterName:  {{ .Values.clusterName }}
    {{- else if (.Values.clusterIdentifier) }}
    clusterName: {{ required "Cluster Name is required!" (splitList "/" .Values.clusterIdentifier) | last }}
    {{- end }}
    clusterDomain: {{ required "Cluster Domain is required!" .Values.clusterDomain }}
    {{- if and (.Values.partnerIdentifier) (.Values.userEmail) (ne .Values.partnerIdentifier "DEFAULT") (ne .Values.userEmail "DEFAULT") }}
    installSource: MARKETPLACE
    {{- else if and (.Values.authToken) (ne .Values.authToken "DEFAULT") }}
    installSource: DIRECT
    {{- end }}
    falcoService:
      daemonName: {{ .Release.Name }}-falco
      configMapName: {{ .Release.Name }}-falco-rules
      namespace: cloudanix
    configCron:
      cronJobName: {{ .Values.configCron.name }}
      configMapName: {{ .Values.configCron.configMapName }}
      namespace: cloudanix
    threatService:
      deployName: {{ .Values.threatService.name }}
      configMapName: {{ .Values.threatService.configMapName }}
      namespace: cloudanix
    inventoryService:
      deployName: {{ .Values.inventoryService.name }}
      configMapName: {{ .Values.inventoryService.configMapName }}
      namespace: cloudanix
    misconfigCron:
      cronJobName: {{ .Values.misconfigCron.name }}
      configMapName: {{ .Values.misconfigCron.configMapName }}
      namespace: cloudanix

---

apiVersion: v1
kind: ServiceAccount
metadata:
  name: config-cron-sa
  namespace: cloudanix

---

kind: ClusterRole
apiVersion: rbac.authorization.k8s.io/v1
metadata:
  name: config-cron-role
  namespace: cloudanix
rules:
- apiGroups: ["","apps","batch"]
  resources: ["deployments","daemonsets","configmaps","cronjobs"]
  verbs: ["get", "watch", "list", "update", "patch"]

---

apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: config-cron
  namespace: cloudanix
subjects:
- kind: ServiceAccount
  name: config-cron-sa
  namespace: cloudanix
roleRef:
  kind: ClusterRole
  name: config-cron-role
  apiGroup: rbac.authorization.k8s.io

---

kind: ClusterRole
apiVersion: rbac.authorization.k8s.io/v1
metadata:
  name: config-cron-role-secrets
  namespace: cloudanix
rules:
- apiGroups: ["","apps","batch"]
  resources: ["secrets"]
  verbs: ["get", "watch", "list", "update", "patch"]

---

apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: config-cron
  namespace: cloudanix
subjects:
- kind: ServiceAccount
  name: config-cron-sa
  namespace: cloudanix
roleRef:
  kind: ClusterRole
  name: config-cron-role-secrets
  apiGroup: rbac.authorization.k8s.io
---
{{- end }}
