{{- if eq (include "cloudanix.exporterServiceEnabled" .) "true" }}
---
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ .Values.networkMonitoring.exporterService.name }}-config
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "cloudanix.labels" . | nindent 4 }}
    component: exporter-service
data:
  config.yaml: |
    common:
      listenerUrl: {{ required "A valid URL is required!" .Values.networkMonitoring.exporterService.backend.url | quote }}
      requestTimeout: {{ .Values.requestTimeout | default 30 }}
      httpMaxRetries: {{ .Values.httpMaxRetries | default 3 }}
      bufferSize: {{ .Values.networkMonitoring.exporterService.config.sender.bufferSize }}
      bufferDuration: {{ .Values.networkMonitoring.exporterService.config.sender.bufferDuration }}
      logLevel: {{ .Values.logLevel | default "info" }}
      accountId: {{ required "Account Id is required!" .Values.accountId }}
      clusterIdentifier: {{ required "Cluster Identifier is required!" .Values.clusterIdentifier }}
      {{- if and (.Values.clusterName) (ne .Values.clusterName "DEFAULT") }}
      clusterName:  {{ .Values.clusterName }}
      {{- else if (.Values.clusterIdentifier) }}
      clusterName: {{ required "Cluster Name is required!" (splitList "/" .Values.clusterIdentifier) | last }}
      {{- end }}
      clusterDomain: {{ required "Cluster Domain is required!" .Values.clusterDomain }}
    exporterService:
      enabled: true
      templateType: KUBERNETESTRAFFIC
      numReceiverGoroutines: {{ .Values.networkMonitoring.exporterService.config.ingest.numReceiverGoroutines }}
      inputBuffer: {{ .Values.networkMonitoring.exporterService.config.ingest.inputBuffer }}
      {{- if .Values.networkMonitoring.exporterService.config.ingest.ignoreNamespaces }}
      ignoreNamespaces:
        {{- range .Values.networkMonitoring.exporterService.config.ingest.ignoreNamespaces }}
        - {{ . | quote }}
        {{- end }}
      {{- end }}
      {{- if .Values.networkMonitoring.exporterService.config.ingest.allowedNamespaces }}
      allowedNamespaces:
        {{- range .Values.networkMonitoring.exporterService.config.ingest.allowedNamespaces }}
        - {{ . | quote }}
        {{- end }}
      {{- end }}
      dedupeTtlSeconds: {{ .Values.networkMonitoring.exporterService.config.dedupe.ttlSeconds }}
      dedupeShardCount: {{ .Values.networkMonitoring.exporterService.config.dedupe.shardCount }}
      dedupeMaxEntriesPerShard: {{ .Values.networkMonitoring.exporterService.config.dedupe.maxEntriesPerShard }}
      flusherTickIntervalMs: {{ .Values.networkMonitoring.exporterService.config.flusher.tickIntervalMs }}
      flusherMaxPopsPerTick: {{ .Values.networkMonitoring.exporterService.config.flusher.maxPopsPerTick }}

---
apiVersion: v1
kind: ServiceAccount
metadata:
  name: {{ .Values.networkMonitoring.exporterService.name }}
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "cloudanix.labels" . | nindent 4 }}
    component: exporter-service

---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: {{ .Release.Namespace }}-{{ .Values.networkMonitoring.exporterService.name }}
  labels:
    {{- include "cloudanix.labels" . | nindent 4 }}
    component: exporter-service
rules:
  - apiGroups: [""]
    resources: ["pods", "namespaces"]
    verbs: ["get", "list"]

---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: {{ .Release.Namespace }}-{{ .Values.networkMonitoring.exporterService.name }}
  labels:
    {{- include "cloudanix.labels" . | nindent 4 }}
    component: exporter-service
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: {{ .Release.Namespace }}-{{ .Values.networkMonitoring.exporterService.name }}
subjects:
  - kind: ServiceAccount
    name: {{ .Values.networkMonitoring.exporterService.name }}
    namespace: {{ .Release.Namespace }}

---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ .Values.networkMonitoring.exporterService.name }}
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "cloudanix.labels" . | nindent 4 }}
    component: exporter-service
    {{- with .Values.networkMonitoring.exporterService.labels }}
    {{- toYaml . | nindent 4 }}
    {{- end }}
spec:
  replicas: {{ .Values.networkMonitoring.exporterService.replicaCount }}
  selector:
    matchLabels:
      app: {{ .Values.networkMonitoring.exporterService.name }}
  template:
    metadata:
      labels:
        app: {{ .Values.networkMonitoring.exporterService.name }}
        {{- include "cloudanix.selectorLabels" . | nindent 8 }}
        component: exporter-service
    spec:
      serviceAccountName: {{ .Values.networkMonitoring.exporterService.name }}
      
      securityContext:
        runAsNonRoot: {{ .Values.networkMonitoring.exporterService.securityContext.runAsNonRoot }}
        runAsUser: {{ .Values.networkMonitoring.exporterService.securityContext.runAsUser }}
        fsGroup: {{ .Values.networkMonitoring.exporterService.securityContext.fsGroup }}
        seccompProfile:
          type: RuntimeDefault
      
      containers:
      - name: exporter
        image: "{{ .Values.networkMonitoring.exporterService.image.repository }}:{{ .Values.networkMonitoring.exporterService.image.tag }}"
        imagePullPolicy: {{ .Values.networkMonitoring.exporterService.image.pullPolicy }}
        
        securityContext:
          allowPrivilegeEscalation: false
          readOnlyRootFilesystem: true
          runAsNonRoot: true
          runAsUser: {{ .Values.networkMonitoring.exporterService.securityContext.runAsUser }}
          capabilities:
            drop:
              - ALL

        env:
        - name: HUBBLE_RELAY_ADDR
          # hubble-relay runs in the release namespace; swap the baked-in
          # `cloudanix` ns segment for the actual one. No-op for custom addresses.
          value: {{ .Values.networkMonitoring.exporterService.hubbleRelay.address | replace "hubble-relay.cloudanix.svc" (printf "hubble-relay.%s.svc" .Release.Namespace) | quote }}

        volumeMounts:
        - name: config
          mountPath: /etc/cdx/config
          readOnly: true
        - name: cloudanix-secrets-volume
          mountPath: /etc/cdx/secrets
          readOnly: true
        - name: tmp
          mountPath: /tmp

        resources:
          {{- toYaml .Values.networkMonitoring.exporterService.resources | nindent 10 }}

      volumes:
      - name: config
        configMap:
          name: {{ .Values.networkMonitoring.exporterService.name }}-config
      - name: cloudanix-secrets-volume
        secret:
          secretName: cloudanix-secrets
      - name: tmp
        emptyDir: {}
      
      terminationGracePeriodSeconds: 30

---
apiVersion: v1
kind: Service
metadata:
  name: {{ .Values.networkMonitoring.exporterService.name }}
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "cloudanix.labels" . | nindent 4 }}
    component: exporter-service
spec:
  type: ClusterIP
  ports:
  - name: metrics
    port: 9090
    targetPort: 9090
    protocol: TCP
  selector:
    app: {{ .Values.networkMonitoring.exporterService.name }}

{{- end }}
