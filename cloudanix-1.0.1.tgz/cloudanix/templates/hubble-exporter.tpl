{{- if eq (include "cloudanix.exporterServiceEnabled" .) "true" }}
---
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ .Values.networkMonitoring.hubbleExporter.name }}-config
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "cloudanix.labels" . | nindent 4 }}
    component: hubble-exporter
data:
  config.yaml: |
    ingest:
      num_receiver_goroutines: {{ .Values.networkMonitoring.hubbleExporter.config.ingest.numReceiverGoroutines }}
      input_buffer: {{ .Values.networkMonitoring.hubbleExporter.config.ingest.inputBuffer }}
      {{- if .Values.networkMonitoring.hubbleExporter.config.ingest.ignoreNamespaces }}
      ignore_namespaces:
        {{- range .Values.networkMonitoring.hubbleExporter.config.ingest.ignoreNamespaces }}
        - {{ . | quote }}
        {{- end }}
      {{- end }}
      {{- if .Values.networkMonitoring.hubbleExporter.config.ingest.allowedNamespaces }}
      allowed_namespaces:
        {{- range .Values.networkMonitoring.hubbleExporter.config.ingest.allowedNamespaces }}
        - {{ . | quote }}
        {{- end }}
      {{- end }}

    dedupe:
      ttl_seconds: {{ .Values.networkMonitoring.hubbleExporter.config.dedupe.ttlSeconds }}
      shard_count: {{ .Values.networkMonitoring.hubbleExporter.config.dedupe.shardCount }}
      max_entries_per_shard: {{ .Values.networkMonitoring.hubbleExporter.config.dedupe.maxEntriesPerShard }}

    flusher:
      tick_interval_ms: {{ .Values.networkMonitoring.hubbleExporter.config.flusher.tickIntervalMs }}
      max_pops_per_tick: {{ .Values.networkMonitoring.hubbleExporter.config.flusher.maxPopsPerTick }}

    sender:
      send_buffer_size: {{ .Values.networkMonitoring.hubbleExporter.config.sender.sendBufferSize }}
      send_buffer_timeout_ms: {{ .Values.networkMonitoring.hubbleExporter.config.sender.sendBufferTimeoutMs }}
      backend_url: {{ .Values.networkMonitoring.hubbleExporter.backend.url | quote }}
      http_timeout_seconds: {{ .Values.networkMonitoring.hubbleExporter.backend.httpTimeout }}

    logging:
      level: {{ .Values.networkMonitoring.hubbleExporter.config.logging.level | quote }}
      encoding: {{ .Values.networkMonitoring.hubbleExporter.config.logging.encoding | quote }}

---
apiVersion: v1
kind: ServiceAccount
metadata:
  name: {{ .Values.networkMonitoring.hubbleExporter.name }}
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "cloudanix.labels" . | nindent 4 }}
    component: hubble-exporter

---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: {{ .Release.Namespace }}-{{ .Values.networkMonitoring.hubbleExporter.name }}
  labels:
    {{- include "cloudanix.labels" . | nindent 4 }}
    component: hubble-exporter
rules:
  - apiGroups: [""]
    resources: ["pods", "namespaces"]
    verbs: ["get", "list"]

---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: {{ .Release.Namespace }}-{{ .Values.networkMonitoring.hubbleExporter.name }}
  labels:
    {{- include "cloudanix.labels" . | nindent 4 }}
    component: hubble-exporter
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: {{ .Release.Namespace }}-{{ .Values.networkMonitoring.hubbleExporter.name }}
subjects:
  - kind: ServiceAccount
    name: {{ .Values.networkMonitoring.hubbleExporter.name }}
    namespace: {{ .Release.Namespace }}

---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ .Values.networkMonitoring.hubbleExporter.name }}
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "cloudanix.labels" . | nindent 4 }}
    component: hubble-exporter
    {{- with .Values.networkMonitoring.hubbleExporter.labels }}
    {{- toYaml . | nindent 4 }}
    {{- end }}
spec:
  replicas: {{ .Values.networkMonitoring.hubbleExporter.replicaCount }}
  selector:
    matchLabels:
      app: {{ .Values.networkMonitoring.hubbleExporter.name }}
  template:
    metadata:
      labels:
        app: {{ .Values.networkMonitoring.hubbleExporter.name }}
        {{- include "cloudanix.selectorLabels" . | nindent 8 }}
        component: hubble-exporter
    spec:
      serviceAccountName: {{ .Values.networkMonitoring.hubbleExporter.name }}
      
      securityContext:
        runAsNonRoot: {{ .Values.networkMonitoring.hubbleExporter.securityContext.runAsNonRoot }}
        runAsUser: {{ .Values.networkMonitoring.hubbleExporter.securityContext.runAsUser }}
        fsGroup: {{ .Values.networkMonitoring.hubbleExporter.securityContext.fsGroup }}
        seccompProfile:
          type: RuntimeDefault
      
      containers:
      - name: exporter
        image: "{{ .Values.networkMonitoring.hubbleExporter.image.repository }}:{{ .Values.networkMonitoring.hubbleExporter.image.tag }}"
        imagePullPolicy: {{ .Values.networkMonitoring.hubbleExporter.image.pullPolicy }}
        
        securityContext:
          allowPrivilegeEscalation: false
          readOnlyRootFilesystem: true
          runAsNonRoot: true
          runAsUser: {{ .Values.networkMonitoring.hubbleExporter.securityContext.runAsUser }}
          capabilities:
            drop:
              - ALL
        
        args:
          - -config
          - /app/config/config.yaml
        
        env:
        - name: HUBBLE_RELAY_ADDR
          value: {{ .Values.networkMonitoring.hubbleExporter.hubbleRelay.address | quote }}
        {{- if .Values.networkMonitoring.hubbleExporter.backend.apiToken }}
        - name: BACKEND_API_TOKEN
          valueFrom:
            secretKeyRef:
              name: {{ .Values.networkMonitoring.hubbleExporter.name }}-secret
              key: api-token
        {{- end }}
        
        volumeMounts:
        - name: config
          mountPath: /app/config
          readOnly: true
        - name: tmp
          mountPath: /tmp
        
        resources:
          {{- toYaml .Values.networkMonitoring.hubbleExporter.resources | nindent 10 }}
      
      volumes:
      - name: config
        configMap:
          name: {{ .Values.networkMonitoring.hubbleExporter.name }}-config
      - name: tmp
        emptyDir: {}
      
      terminationGracePeriodSeconds: 30

---
apiVersion: v1
kind: Service
metadata:
  name: {{ .Values.networkMonitoring.hubbleExporter.name }}
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "cloudanix.labels" . | nindent 4 }}
    component: hubble-exporter
spec:
  type: ClusterIP
  ports:
  - name: metrics
    port: 9090
    targetPort: 9090
    protocol: TCP
  selector:
    app: {{ .Values.networkMonitoring.hubbleExporter.name }}

{{- if .Values.networkMonitoring.hubbleExporter.backend.apiToken }}
---
apiVersion: v1
kind: Secret
metadata:
  name: {{ .Values.networkMonitoring.hubbleExporter.name }}-secret
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "cloudanix.labels" . | nindent 4 }}
    component: hubble-exporter
type: Opaque
stringData:
  api-token: {{ .Values.networkMonitoring.hubbleExporter.backend.apiToken | quote }}
{{- end }}
{{- end }}
