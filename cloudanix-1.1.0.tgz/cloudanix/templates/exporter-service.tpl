{{- if eq (include "cloudanix.exporterServiceEnabled" .) "true" }}
---
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ .Values.exporterService.name }}-config
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "cloudanix.labels" . | nindent 4 }}
    component: exporter-service
data:
  config.yaml: |
    common:
      listenerUrl: {{ required "exporterService.listenerUrl is required!" .Values.exporterService.listenerUrl | quote }}
      requestTimeout: {{ .Values.requestTimeout | default 30 }}
      httpMaxRetries: {{ .Values.httpMaxRetries | default 3 }}
      bufferSize: {{ .Values.exporterService.bufferSize }}
      bufferDuration: {{ .Values.exporterService.bufferDuration }}
      logLevel: {{ .Values.logLevel | default "warn" }}
      accountId: {{ required "Account Id is required!" .Values.accountId }}
      clusterIdentifier: {{ required "Cluster Identifier is required!" .Values.clusterIdentifier }}
      {{- if and (.Values.clusterName) (ne .Values.clusterName "DEFAULT") }}
      clusterName: {{ .Values.clusterName }}
      {{- end }}
      clusterDomain: {{ required "Cluster Domain is required!" .Values.clusterDomain }}
    exporterService:
      dedupeTtlSeconds: {{ .Values.exporterService.dedupeTtlSeconds }}
      dedupeShardCount: {{ .Values.exporterService.dedupeShardCount }}
      dedupeMaxEntriesPerShard: {{ .Values.exporterService.dedupeMaxEntriesPerShard }}
      flusherTickIntervalMs: {{ .Values.exporterService.flusherTickIntervalMs }}
      flusherMaxPopsPerTick: {{ .Values.exporterService.flusherMaxPopsPerTick }}
      numReceiverGoroutines: {{ .Values.exporterService.numReceiverGoroutines }}
      inputBuffer: {{ .Values.exporterService.inputBuffer }}
      {{- if .Values.exporterService.ignoreNamespaces }}
      ignoreNamespaces:
        {{- range .Values.exporterService.ignoreNamespaces }}
        - {{ . | quote }}
        {{- end }}
      {{- else }}
      ignoreNamespaces: []
      {{- end }}
      {{- if .Values.exporterService.allowedNamespaces }}
      allowedNamespaces:
        {{- range .Values.exporterService.allowedNamespaces }}
        - {{ . | quote }}
        {{- end }}
      {{- else }}
      allowedNamespaces: []
      {{- end }}
      templateType: {{ required "exporterService.templateType is required!" .Values.exporterService.templateType }}
      {{- if and (.Values.authToken) (ne .Values.authToken "DEFAULT") }}
      enabled: true
      {{- end }}

---
apiVersion: v1
kind: ServiceAccount
metadata:
  name: {{ .Values.exporterService.name }}
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "cloudanix.labels" . | nindent 4 }}
    component: exporter-service

---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: {{ .Release.Namespace }}-{{ .Values.exporterService.name }}
  labels:
    {{- include "cloudanix.labels" . | nindent 4 }}
    component: exporter-service
rules:
  - apiGroups: [""]
    resources: ["pods", "namespaces"]
    verbs: ["get", "list"]

---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: {{ .Release.Namespace }}-{{ .Values.exporterService.name }}
  labels:
    {{- include "cloudanix.labels" . | nindent 4 }}
    component: exporter-service
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: {{ .Release.Namespace }}-{{ .Values.exporterService.name }}
subjects:
  - kind: ServiceAccount
    name: {{ .Values.exporterService.name }}
    namespace: {{ .Release.Namespace }}

---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ .Values.exporterService.name }}
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "cloudanix.labels" . | nindent 4 }}
    component: exporter-service
    {{- with .Values.exporterService.labels }}
    {{- toYaml . | nindent 4 }}
    {{- end }}
spec:
  replicas: {{ .Values.exporterService.replicaCount }}
  selector:
    matchLabels:
      app: {{ .Values.exporterService.name }}
  template:
    metadata:
      labels:
        app: {{ .Values.exporterService.name }}
        {{- include "cloudanix.selectorLabels" . | nindent 8 }}
        component: exporter-service
    spec:
      serviceAccountName: {{ .Values.exporterService.name }}
      
      securityContext:
        runAsNonRoot: {{ .Values.exporterService.securityContext.runAsNonRoot }}
        runAsUser: {{ .Values.exporterService.securityContext.runAsUser }}
        runAsGroup: {{ .Values.exporterService.securityContext.runAsGroup }}
        fsGroup: {{ .Values.exporterService.securityContext.fsGroup }}
        seccompProfile:
          type: RuntimeDefault
      
      containers:
      - name: exporter
        image: {{ .Values.exporterService.image }}
        imagePullPolicy: IfNotPresent
        
        securityContext:
          allowPrivilegeEscalation: false
          readOnlyRootFilesystem: true
          runAsNonRoot: true
          runAsUser: {{ .Values.exporterService.securityContext.runAsUser }}
          runAsGroup: {{ .Values.exporterService.securityContext.runAsGroup }}
          capabilities:
            drop:
              - ALL
        
        args:
          - -config
          - /app/config/config.yaml
        
        env:
        - name: HUBBLE_RELAY_ADDR
          value: {{ .Values.exporterService.hubbleRelayAddress | quote }}
        {{- if .Values.exporterService.apiToken }}
        - name: BACKEND_API_TOKEN
          valueFrom:
            secretKeyRef:
              name: {{ .Values.exporterService.name }}-secret
              key: api-token
        {{- end }}
        
        volumeMounts:
        - name: config
          mountPath: /app/config
          readOnly: true
        - name: cloudanix-secrets-volume
          mountPath: /etc/cdx/secrets
          readOnly: true
        - name: tmp
          mountPath: /tmp
        
        resources:
          {{- toYaml .Values.exporterService.resources | nindent 10 }}
      
      volumes:
      - name: config
        configMap:
          name: {{ .Values.exporterService.name }}-config
      - name: cloudanix-secrets-volume
        secret:
          secretName: cloudanix-secrets
      - name: tmp
        emptyDir: {}
      
      terminationGracePeriodSeconds: 30

---
apiVersion: v1
kind: Service
metadata:
  name: {{ .Values.exporterService.name }}
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "cloudanix.labels" . | nindent 4 }}
    component: exporter-service
spec:
  type: ClusterIP
  ports:
  - name: metrics
    port: 9090
    targetPort: 9090
    protocol: TCP
  selector:
    app: {{ .Values.exporterService.name }}

{{- if .Values.exporterService.apiToken }}
---
apiVersion: v1
kind: Secret
metadata:
  name: {{ .Values.exporterService.name }}-secret
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "cloudanix.labels" . | nindent 4 }}
    component: exporter-service
type: Opaque
stringData:
  api-token: {{ .Values.exporterService.apiToken | quote }}
{{- end }}
{{- end }}
