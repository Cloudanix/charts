{{/*
Expand the name of the chart.
*/}}
{{- define "cloudanix.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "cloudanix.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "cloudanix.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "cloudanix.labels" -}}
helm.sh/chart: {{ include "cloudanix.chart" . }}
{{ include "cloudanix.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "cloudanix.selectorLabels" -}}
app.kubernetes.io/name: {{ include "cloudanix.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Merge label maps into a YAML map body; on a shared key the later map wins.
Callers pass customer maps first and the chart's own labels last:
  object metadata: (list .Values.commonLabels <chart labels>)
  pod template:    (list .Values.commonLabels .Values.<component>.podLabels <chart labels>)
so podLabels beat commonLabels, and no customer key can change a label that a
selector or Service depends on. Values are stringified: the API rejects a
non-string label value, and `--set team=1234` or `enabled: true` arrive as a
number or bool. Renders nothing when every map is empty, so callers wrap it in
`with` and an install without custom labels renders exactly as before.
Never use it for spec.selector: selectors are immutable after install.
Usage:
  {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels .Values.threatMonitor.labels) }}
  labels:
    {{- . | nindent 4 }}
  {{- end }}
*/}}
{{- define "cloudanix.mergeLabels" -}}
{{- $merged := dict -}}
{{- range $labels := . -}}
{{- range $key, $value := $labels -}}
{{- $_ := set $merged $key (toString $value) -}}
{{- end -}}
{{- end -}}
{{- with $merged }}{{ toYaml . }}{{ end -}}
{{- end }}

{{/*
Pod placement from the shared `scheduling` value: nodeSelector, affinity,
tolerations, priorityClassName. Empty values render nothing, so a default install
is unchanged. podAnnotations are rendered by cloudanix.podAnnotations, not here.
Most pods take it through cloudanix.podSpec; the cilium cleanup Job calls it directly
to keep its own tolerations.
Usage: {{- include "cloudanix.scheduling" (.Values.scheduling | default dict) | nindent 6 }}
*/}}
{{- define "cloudanix.scheduling" -}}
{{- with .nodeSelector }}
nodeSelector:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with .affinity }}
affinity:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with .tolerations }}
tolerations:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with .priorityClassName }}
priorityClassName: {{ . | quote }}
{{- end }}
{{- end }}

{{/*
Merge annotation maps. Later maps win on a shared key, so a customer's
podAnnotations override a chart annotation and leave the chart's other keys in place.
Empty input renders nothing.
Usage:
  {{- include "cloudanix.mergeAnnotations" (list (dict "cloudanix.com/container-runtime-socket" $socket) .Values.vulnScanner.podAnnotations) | nindent 8 }}
*/}}
{{- define "cloudanix.mergeAnnotations" -}}
{{- $merged := dict -}}
{{- range $ann := . -}}
{{- range $key, $value := $ann -}}
{{- $_ := set $merged $key (toString $value) -}}
{{- end -}}
{{- end -}}
{{- $lines := list -}}
{{- range $key := keys $merged | sortAlpha -}}
{{- $lines = append $lines (printf "%s: %s" $key (index $merged $key | quote)) -}}
{{- end -}}
{{- join "\n" $lines -}}
{{- end }}

{{/*
Pod-spec fields every Cloudanix pod shares: placement from `scheduling`, imagePullSecrets,
dnsPolicy and dnsConfig. Empty values render nothing.
Usage:
  {{- with include "cloudanix.podSpec" . }}
  {{- . | nindent 6 }}
  {{- end }}
*/}}
{{- define "cloudanix.podSpec" -}}
{{- include "cloudanix.scheduling" (.Values.scheduling | default dict) }}
{{- with .Values.imagePullSecrets }}
imagePullSecrets:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with .Values.dnsPolicy }}
dnsPolicy: {{ . }}
{{- end }}
{{- with .Values.dnsConfig }}
dnsConfig:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- end }}

{{/*
A pod's annotations, last wins: the chart's own (`own`), then scheduling.podAnnotations,
then the component's podAnnotations (`component`). Hooks pass no component.
Usage: include "cloudanix.podAnnotations" (dict "root" . "own" (dict ...) "component" .Values.threatMonitor.podAnnotations)
*/}}
{{- define "cloudanix.podAnnotations" -}}
{{- $shared := (.root.Values.scheduling | default dict).podAnnotations | default dict -}}
{{- include "cloudanix.mergeAnnotations" (list (.own | default dict) $shared (.component | default dict)) -}}
{{- end }}

{{/*
A pod template's metadata block from rendered labels and annotations; nothing when both
are empty, so a pod without custom labels renders as before.
Usage: {{- with include "cloudanix.podMetadata" (dict "labels" $labels "annotations" $annotations) }}{{ . | nindent 4 }}{{ end }}
*/}}
{{- define "cloudanix.podMetadata" -}}
{{- if or .labels .annotations -}}
metadata:
  {{- with .labels }}
  labels:
    {{- . | nindent 4 }}
  {{- end }}
  {{- with .annotations }}
  annotations:
    {{- . | nindent 4 }}
  {{- end }}
{{- end -}}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "cloudanix.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "cloudanix.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
========================================
CAPABILITIES LOGIC
========================================
Capabilities: comma-separated list of "threats", "vulnerabilities", "compliance", "traffic", or "all"
*/}}

{{/*
Check if a specific capability is enabled.
Usage: include "cloudanix.hasCapability" (dict "root" . "cap" "threats")
*/}}
{{- define "cloudanix.hasCapability" -}}
{{- $caps := .root.Values.capabilities | default "all" -}}
{{- if or (eq $caps "all") (has .cap (splitList "," ($caps | replace " " ""))) -}}
true
{{- else -}}
false
{{- end -}}
{{- end }}

{{/*
Check if runtime threat detection should be enabled
*/}}
{{- define "cloudanix.runtimeThreatEnabled" -}}
{{- include "cloudanix.hasCapability" (dict "root" . "cap" "threats") -}}
{{- end }}

{{/*
Check if network monitoring should be enabled
*/}}
{{- define "cloudanix.networkMonitoringEnabled" -}}
{{- include "cloudanix.hasCapability" (dict "root" . "cap" "traffic") -}}
{{- end }}

{{/*
Check if vulnerability scanning should be enabled
*/}}
{{- define "cloudanix.vulnScanningEnabled" -}}
{{- include "cloudanix.hasCapability" (dict "root" . "cap" "vulnerabilities") -}}
{{- end }}

{{/*
Resolve the vuln-scanner socket once for every resource. An explicit value
covers k3s, microk8s, and OpenShift. Otherwise OCI mounts CRI-O and every
other cloud mounts containerd.
*/}}
{{- define "cloudanix.vulnScannerRuntimeSocket" -}}
{{- $configured := .Values.vulnScanner.containerRuntimeSocket | default "" -}}
{{- if $configured -}}
{{- $configured -}}
{{- else if eq (upper (.Values.clusterDomain | default "")) "OCI" -}}
/run/crio/crio.sock
{{- else -}}
/run/containerd/containerd.sock
{{- end -}}
{{- end }}

{{/*
Check if compliance assessment (misconfig-scanner) should be enabled
*/}}
{{- define "cloudanix.complianceEnabled" -}}
{{- include "cloudanix.hasCapability" (dict "root" . "cap" "compliance") -}}
{{- end }}

{{/*
Check if Falco should be deployed (falco.enabled is a Helm dependency condition)
*/}}
{{- define "cloudanix.falcoEnabled" -}}
{{- if and .Values.falco.enabled (eq (include "cloudanix.runtimeThreatEnabled" .) "true") -}}
true
{{- else -}}
false
{{- end -}}
{{- end }}

{{/*
True when either Cilium profile is on: `cilium` (EKS, AWS VPC CNI chaining) or `ciliumOke`
(OKE, Flannel chaining). Both are aliases of one Cilium chart, so they render the same
cluster-scoped objects: exactly one may be on. ciliumOke needs clusterDomain OCI, since the
chained CNI config it mounts (cni-configuration) is Flannel's.
*/}}
{{- define "cloudanix.ciliumDeployed" -}}
{{- $eks := .Values.cilium.enabled -}}
{{- $oke := (.Values.ciliumOke | default dict).enabled -}}
{{- if and $eks $oke -}}
{{- fail "enable one Cilium profile: cilium.enabled (EKS) or ciliumOke.enabled (OKE), not both" -}}
{{- end -}}
{{- if and $oke (ne (upper (.Values.clusterDomain | default "")) "OCI") -}}
{{- fail "ciliumOke is the OKE (Flannel) profile and needs clusterDomain: OCI; use cilium.enabled elsewhere" -}}
{{- end -}}
{{- /* The cilium defaults chain to AWS VPC CNI, which cannot chain on Flannel. The retired
v2.4.4 OKE overlay sets generic-veth, so a customer still passing it installs. */ -}}
{{- if and $eks (eq (upper (.Values.clusterDomain | default "")) "OCI") (ne (default "" .Values.cilium.cni.chainingMode) "generic-veth") -}}
{{- fail "cilium is the EKS (AWS VPC CNI) profile; on clusterDomain: OCI use ciliumOke.enabled" -}}
{{- end -}}
{{- if or $eks $oke -}}
true
{{- else -}}
false
{{- end -}}
{{- end }}

{{/*
True when the enabled Cilium profile chains through the chart's cni-configuration ConfigMap.
*/}}
{{- define "cloudanix.ciliumGenericVeth" -}}
{{- if (.Values.ciliumOke | default dict).enabled -}}
true
{{- else if and .Values.cilium.enabled (eq (default "" .Values.cilium.cni.chainingMode) "generic-veth") -}}
true
{{- else -}}
false
{{- end -}}
{{- end }}

{{/*
Check if Traffic Exporter should be deployed
*/}}
{{- define "cloudanix.trafficExporterEnabled" -}}
{{- include "cloudanix.hasCapability" (dict "root" . "cap" "traffic") -}}
{{- end }}

{{/*
True when authTokenSecret.create is the bool false. A string "false" does not count,
so a default install stays on the chart-owned Secret.
*/}}
{{- define "cloudanix.authFromExternal" -}}
{{- $secret := .Values.authTokenSecret | default dict -}}
{{- if and (kindIs "bool" $secret.create) (not $secret.create) -}}
true
{{- else -}}
false
{{- end -}}
{{- end }}

{{/*
True when authTokenSecret.csi.enabled is the bool true.
*/}}
{{- define "cloudanix.authFromCSI" -}}
{{- $csi := ((.Values.authTokenSecret | default dict).csi) | default dict -}}
{{- if and (kindIs "bool" $csi.enabled) $csi.enabled -}}
true
{{- else -}}
false
{{- end -}}
{{- end }}

{{/*
True when a bearer token will be mounted. An external Secret or CSI counts, so
authToken is not required in values in those modes.
*/}}
{{- define "cloudanix.hasAuthToken" -}}
{{- if or (eq (include "cloudanix.authFromExternal" .) "true") (eq (include "cloudanix.authFromCSI" .) "true") -}}
true
{{- else -}}
{{- $token := .Values.authToken | default "" | toString -}}
{{- if and $token (ne $token "DEFAULT") -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}
{{- end }}

{{- define "cloudanix.authSecretName" -}}
{{- $secret := .Values.authTokenSecret | default dict -}}
{{- $secret.name | default "cloudanix-secrets" -}}
{{- end }}

{{- define "cloudanix.authSecretKey" -}}
{{- $secret := .Values.authTokenSecret | default dict -}}
{{- $secret.key | default "auth-token" -}}
{{- end }}

{{/*
Mount the auth Secret so the key is the file /etc/cdx/secrets/auth-token.
*/}}
{{- define "cloudanix.authSecretVolume" -}}
{{- if eq (include "cloudanix.authFromCSI" .) "true" -}}
{{- if ne (include "cloudanix.authFromExternal" .) "true" -}}
{{- fail "set authTokenSecret.create=false when authTokenSecret.csi.enabled is true" -}}
{{- end -}}
{{- $csi := .Values.authTokenSecret.csi -}}
csi:
  driver: {{ $csi.driver | default "secrets-store.csi.k8s.io" }}
  readOnly: true
  volumeAttributes:
    secretProviderClass: {{ required "authTokenSecret.csi.secretProviderClass is required when csi.enabled is true" $csi.secretProviderClass }}
{{- else -}}
secret:
  secretName: {{ include "cloudanix.authSecretName" . }}
  items:
    - key: {{ include "cloudanix.authSecretKey" . }}
      path: auth-token
{{- end -}}
{{- end }}

{{/*
Workload identity annotations for service accounts that mount the CSI auth volume:
roleArn as the EKS IRSA annotation, then csi.serviceAccountAnnotations (GKE, AKS, or
anything else), which wins on a shared key. Empty unless CSI is on.
*/}}
{{- define "cloudanix.authTokenSAAnnotations" -}}
{{- if eq (include "cloudanix.authFromCSI" .) "true" -}}
{{- $csi := .Values.authTokenSecret.csi -}}
{{- $irsa := dict -}}
{{- with $csi.roleArn }}{{ $_ := set $irsa "eks.amazonaws.com/role-arn" . }}{{ end -}}
{{- include "cloudanix.mergeAnnotations" (list $irsa ($csi.serviceAccountAnnotations | default dict)) -}}
{{- end -}}
{{- end }}

{{/*
Should a scanner's one-off initial-run Job be rendered? True only when
<scanner>.initialRun.enabled, an auth token is set (the scanner exits at once without
one) and the scanner's CronJob does not exist yet - i.e. a fresh install, or the
capability being switched on in an upgrade. Ordinary upgrades skip it.
lookup is empty under `helm template` / ArgoCD, so there the Job renders on every
sync: set <scanner>.initialRun.enabled=false for GitOps installs.
Usage: include "cloudanix.initialRunNeeded" (dict "root" . "scanner" .Values.vulnScanner)
*/}}
{{- define "cloudanix.initialRunNeeded" -}}
{{- $run := .scanner.initialRun | default dict -}}
{{- if and $run.enabled (eq (include "cloudanix.hasAuthToken" .root) "true") (not (lookup "batch/v1" "CronJob" "cloudanix" .scanner.name)) -}}
true
{{- else -}}
false
{{- end -}}
{{- end }}