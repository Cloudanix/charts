{{- /* Pod template shared by the CronJob and the one-off initial-run Job below. */}}
{{- define "cloudanix.misconfigScanner.podTemplate" -}}
metadata:
  labels:
    {{- include "cloudanix.mergeLabels" (list .Values.commonLabels .Values.misconfigScanner.podLabels (dict "app" "kube-bench")) | nindent 4 }}
  {{- with include "cloudanix.podAnnotations" (dict "root" . "component" .Values.misconfigScanner.podAnnotations) }}
  annotations:
    {{- . | nindent 4 }}
  {{- end }}
spec:
  {{- with include "cloudanix.podSpec" . }}
  {{- . | nindent 2 }}
  {{- end }}
  hostPID: true
  restartPolicy: Never
  serviceAccountName: {{ .Values.misconfigScanner.serviceAccount }}
  containers:
  - name: misconfig-scanner
    image: {{ .Values.misconfigScanner.image }}
    imagePullPolicy: IfNotPresent
    {{- if .Values.misconfigScanner.cbpEnabled }}
    {{- /* cbp needs explicit benchmarks; auto-detect can't append cloudanix-1.0. Bump these on kube-bench upgrades. */}}
    {{- $bench := "cis-1.12" }}
    {{- if eq .Values.clusterDomain "AWS" }}{{- $bench = "eks-1.8.0" }}
    {{- else if eq .Values.clusterDomain "GCP" }}{{- $bench = "gke-1.9.0" }}
    {{- else if eq .Values.clusterDomain "AZURE" }}{{- $bench = "aks-1.8" }}
    {{- else if eq .Values.clusterDomain "OCI" }}{{- $bench = "oke-1.7.0" }}
    {{- end }}
    command: ["kube-bench", "--httpoutput=true", {{ printf "--benchmark=%s,cloudanix-1.0" $bench | quote }}]
    {{- else }}
    {{- /* no --benchmark: kube-bench auto-detects the correct benchmark for the running k8s version */}}
    command: ["kube-bench", "--httpoutput=true"]
    {{- end }}
    # command: ["kube-bench", "--include-test-output", "--noremediations", "--noresults", "--nototals", "--httpoutput=true"]
    env:
    - name: NODE_NAME
      valueFrom:
        fieldRef:
          fieldPath: spec.nodeName
    # Job runs on a schedule and is allowed to be slow; it must not burst CPU/mem.
    # GOMAXPROCS caps the Go scheduler's thread count; GOMEMLIMIT sets a soft heap
    # target so GC works harder to stay under the memory limit — not a hard guarantee.
    {{- if .Values.misconfigScanner.goMaxProcs }}
    - name: GOMAXPROCS
      value: {{ .Values.misconfigScanner.goMaxProcs | quote }}
    {{- end }}
    {{- if .Values.misconfigScanner.goMemLimit }}
    - name: GOMEMLIMIT
      value: {{ .Values.misconfigScanner.goMemLimit | quote }}
    {{- end }}
    volumeMounts:
    - name: var-lib-etcd
      mountPath: /var/lib/etcd
      readOnly: true
    - name: var-lib-kubelet
      mountPath: /var/lib/kubelet
      readOnly: true
    - name: var-lib-kube-scheduler
      mountPath: /var/lib/kube-scheduler
      readOnly: true
    - name: var-lib-kube-controller-manager
      mountPath: /var/lib/kube-controller-manager
      readOnly: true
    - name: etc-systemd
      mountPath: /etc/systemd
      readOnly: true
    - name: lib-systemd
      mountPath: /lib/systemd/
      readOnly: true
    - name: srv-kubernetes
      mountPath: /srv/kubernetes/
      readOnly: true
    - name: etc-kubernetes
      mountPath: /etc/kubernetes
      readOnly: true
      # /usr/local/mount-from-host/bin is mounted to access kubectl / kubelet, for auto-detecting the Kubernetes version.
      # You can omit this mount if you specify --version as part of the command.
    - name: usr-bin
      mountPath: /usr/local/mount-from-host/bin
      readOnly: true
    - name: etc-cni-netd
      mountPath: /etc/cni/net.d/
      readOnly: true
    - name: opt-cni-bin
      mountPath: /opt/cni/bin/
      readOnly: true
    - name: var-tmp-dump
      mountPath: /var/tmp/dump
    - name: misconfig-volume
      mountPath: /etc/cdx/config
      readOnly: true
    - name: cloudanix-secrets-volume
      mountPath: /etc/cdx/secrets
      readOnly: true
    resources:
      {{- toYaml (.Values.misconfigScanner.resources | default dict) | nindent 6 }}
  volumes:
  - name: var-lib-etcd
    hostPath:
      path: "/var/lib/etcd"
  - name: var-lib-kubelet
    hostPath:
      path: "/var/lib/kubelet"
  - name: var-lib-kube-scheduler
    hostPath:
      path: "/var/lib/kube-scheduler"
  - name: var-lib-kube-controller-manager
    hostPath:
      path: "/var/lib/kube-controller-manager"
  - name: etc-systemd
    hostPath:
      path: "/etc/systemd"
  - name: lib-systemd
    hostPath:
      path: "/lib/systemd"
  - name: srv-kubernetes
    {{- if eq .Values.clusterDomain "GCP" }}
    emptyDir: {}
    {{- else }}
    hostPath:
      path: "/srv/kubernetes"
    {{- end }}
  - name: etc-kubernetes
    hostPath:
      path: "/etc/kubernetes"
  - name: usr-bin
    hostPath:
      path: "/usr/bin"
  - name: etc-cni-netd
    hostPath:
      path: "/etc/cni/net.d/"
  - name: opt-cni-bin
    {{- if eq .Values.clusterDomain "GCP" }}
    emptyDir: {}
    {{- else }}
    hostPath:
      path: "/opt/cni/bin/"
    {{- end }}
  - name: var-tmp-dump
    hostPath:
      path: "/var/tmp/dump"
  - name: misconfig-volume
    configMap:
      name: {{ .Values.misconfigScanner.configMapName }}
  - name: cloudanix-secrets-volume
    {{- include "cloudanix.authSecretVolume" . | nindent 4 }}
{{- end }}

{{- if eq (include "cloudanix.complianceEnabled" .) "true" }}
{{- if .Capabilities.APIVersions.Has "batch/v1" }}
apiVersion: batch/v1
{{- else }}
apiVersion: batch/v1beta1
{{- end }}
kind: CronJob
metadata:
  name: {{ .Values.misconfigScanner.name }}
  namespace: cloudanix
  {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels .Values.misconfigScanner.labels) }}
  labels:
    {{- . | nindent 4 }}
  {{- end }}
spec:
  schedule: {{ .Values.misconfigScanner.schedule | quote }}
  concurrencyPolicy: Forbid
  jobTemplate:
    {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
    metadata:
      labels:
        {{- . | nindent 8 }}
    {{- end }}
    spec:
      activeDeadlineSeconds: {{ .Values.misconfigScanner.activeDeadlineSeconds | default 14400 }}
      # No pod-level retry: a failed publish exits non-zero, and a retry would redo the whole
      # scan (the POST already retries in-process). The next schedule tick is the retry.
      backoffLimit: 0
      template:
        {{- include "cloudanix.misconfigScanner.podTemplate" . | nindent 8 }}

{{- if eq (include "cloudanix.initialRunNeeded" (dict "root" . "scanner" .Values.misconfigScanner)) "true" }}
---
# One scan right after install so the first findings don't wait for the schedule
# (config-manager usually stretches it to daily). A plain Job, not a post-install hook:
# helm waits for hook Jobs to finish. keep: the next upgrade drops this Job from the
# manifest (the CronJob now exists) and must not delete it mid-scan.
apiVersion: batch/v1
kind: Job
metadata:
  name: {{ .Values.misconfigScanner.name }}-initial-r{{ .Release.Revision }}
  namespace: cloudanix
  {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
  labels:
    {{- . | nindent 4 }}
  {{- end }}
  annotations:
    "helm.sh/resource-policy": keep
spec:
  activeDeadlineSeconds: {{ .Values.misconfigScanner.activeDeadlineSeconds | default 14400 }}
  backoffLimit: 0
  ttlSecondsAfterFinished: {{ .Values.misconfigScanner.initialRun.ttlSecondsAfterFinished | default 3600 }}
  template:
    {{- include "cloudanix.misconfigScanner.podTemplate" . | nindent 4 }}
{{- end }}

---

apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ .Values.misconfigScanner.configMapName }}
  namespace: cloudanix
  {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
  labels:
    {{- . | nindent 4 }}
  {{- end }}
data:
  config.yaml: |
    chartVersion:  {{ .Chart.Version }}
    releaseName: {{ .Release.Name }}
    common:
      listenerUrl: {{ required "A valid URL is required!" .Values.misconfigScanner.listenerUrl }}
      requestTimeout: {{ .Values.requestTimeout | default 30 }}
      httpMaxRetries: {{ .Values.httpMaxRetries | default 3 }}
      logLevel: {{ .Values.logLevel | default "warn" }}
      accountId: {{ required "Account Id is required!" .Values.accountId }}
      clusterIdentifier: {{ required "Cluster Identifier is required!" .Values.clusterIdentifier }}
      {{- if and (.Values.clusterName) (ne (toString .Values.clusterName) "DEFAULT") }}
      clusterName:  {{ .Values.clusterName }}
      {{- else if (.Values.clusterIdentifier) }}
      clusterName: {{ required "Cluster Name is required!" (splitList "/" (toString .Values.clusterIdentifier)) | last }}
      {{- end }}
      clusterDomain: {{ required "Cluster Domain is required!" .Values.clusterDomain }}
    misconfigScanner:
      templateType: {{ required "misconfigScanner.templateType is required!" .Values.misconfigScanner.templateType }}
      {{- if eq (include "cloudanix.hasAuthToken" .) "true" }}
      enabled: true
      {{- end }}
---

apiVersion: v1
kind: ServiceAccount
metadata:
  name: {{ .Values.misconfigScanner.serviceAccount }}
  namespace: cloudanix
  {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
  labels:
    {{- . | nindent 4 }}
  {{- end }}
  {{- with include "cloudanix.authTokenSAAnnotations" . }}
  annotations:
    {{- . | nindent 4 }}
  {{- end }}

---

kind: ClusterRole
apiVersion: rbac.authorization.k8s.io/v1
metadata:
  name: {{ .Values.misconfigScanner.clusterRole }}
  {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
  labels:
    {{- . | nindent 4 }}
  {{- end }}
rules:
# Split per apiGroup so each kind is granted where it actually lives. The policy checks read
# these to name the specific object that failed (failed_resources); a kind that is missing
# here makes kubectl exit non-zero and the check reports WARN with the API server's message
# rather than a finding.
- apiGroups: [""]
  # services + replicationcontrollers are part of what `kubectl get all` expands to.
  # nodes is required for the failed_resources inventory snapshot (check/owners.go) —
  # without it that combined kubectl get exits non-zero and the whole snapshot is dropped.
  resources: ["pods", "namespaces", "serviceaccounts", "services", "replicationcontrollers", "resourcequotas", "nodes"]
  verbs: ["get", "list", "watch"]
- apiGroups: ["apps"]
  resources: ["deployments", "daemonsets", "statefulsets", "replicasets"]
  verbs: ["get", "list", "watch"]
- apiGroups: ["batch"]
  resources: ["jobs", "cronjobs"]
  verbs: ["get", "list", "watch"]
- apiGroups: ["autoscaling"]
  resources: ["horizontalpodautoscalers"]
  verbs: ["get", "list", "watch"]
- apiGroups: ["networking.k8s.io"]
  resources: ["networkpolicies", "ingresses"]
  verbs: ["get", "list", "watch"]
# GKE-only CRD, read by gke-1.9.0 5.6.7. Harmless where the CRD is absent.
- apiGroups: ["networking.gke.io"]
  resources: ["managedcertificates"]
  verbs: ["get", "list", "watch"]
- apiGroups: ["rbac.authorization.k8s.io"]
  resources: ["roles", "rolebindings", "clusterroles", "clusterrolebindings"]
  verbs: ["get", "list", "watch"]
- apiGroups: ["policy"]
  resources: ["poddisruptionbudgets"]
  verbs: ["get", "list", "watch"]
- apiGroups: ["certificates.k8s.io"]
  resources: ["certificatesigningrequests"]
  verbs: ["get", "list", "watch"]
# Deliberately no `secrets`: RBAC has no metadata-only read, so listing Secrets would expose
# their data. The one check that wanted it (cloudanix-1.0 C4.2) stays manual instead.

---

apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: {{ .Values.misconfigScanner.name }}
  {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
  labels:
    {{- . | nindent 4 }}
  {{- end }}
subjects:
- kind: ServiceAccount
  name: {{ .Values.misconfigScanner.serviceAccount }}
  namespace: cloudanix
roleRef:
  kind: ClusterRole
  name: {{ .Values.misconfigScanner.clusterRole }}
  apiGroup: rbac.authorization.k8s.io
{{- end }}
