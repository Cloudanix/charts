{{/* One config-manager run: the CronJob's pod, also used by the post-upgrade Job below. */}}
{{- define "cloudanix.configManager.podTemplate" -}}
{{- $podLabels := include "cloudanix.mergeLabels" (list .Values.commonLabels .Values.configManager.podLabels) }}
{{- $podAnnotations := include "cloudanix.podAnnotations" (dict "root" . "component" .Values.configManager.podAnnotations) }}
{{- with include "cloudanix.podMetadata" (dict "labels" $podLabels "annotations" $podAnnotations) }}
{{ . }}
{{- end }}
spec:
  {{- with include "cloudanix.podSpec" . }}
  {{- . | nindent 2 }}
  {{- end }}
  serviceAccountName: config-manager-sa
  # uid/gid 1001 = the image's `cdx` user.
  securityContext:
    runAsUser: 1001
    runAsGroup: 1001
    runAsNonRoot: true
    seccompProfile:
      type: RuntimeDefault
  containers:
  - name: config-manager
    image: {{ .Values.configManager.image }}
    imagePullPolicy: IfNotPresent
    securityContext:
      allowPrivilegeEscalation: false
      readOnlyRootFilesystem: true
      capabilities:
        drop: ["ALL"]
    {{- /* Env, not the ConfigMap: the platform config never decides which registries are trusted. */}}
    {{- with .Values.trustedImageRepositories }}
    env:
    - name: CDX_TRUSTED_IMAGE_REPOSITORIES
      value: {{ join "," . | quote }}
    {{- end }}
    volumeMounts:
    - name: config-volume
      mountPath: /etc/cdx/config
      readOnly: true
    - name: cloudanix-secrets-volume
      mountPath: /etc/cdx/secrets
      readOnly: true
    resources:
      {{- toYaml (.Values.configManager.resources | default dict) | nindent 6 }}
  volumes:
    - name: config-volume
      configMap:
        name: config-manager-cm
    - name: cloudanix-secrets-volume
      {{- include "cloudanix.authSecretVolume" . | nindent 6 }}
  restartPolicy: Never
{{- end }}

{{- if .Capabilities.APIVersions.Has "batch/v1" }}
apiVersion: batch/v1
{{- else }}
apiVersion: batch/v1beta1
{{- end }}
kind: CronJob
metadata:
  name: {{ .Values.configManager.name }}
  namespace: cloudanix
  {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels .Values.configManager.labels) }}
  labels:
    {{- . | nindent 4 }}
  {{- end }}
spec:
  schedule: {{ .Values.configManager.schedule | quote }}
  concurrencyPolicy: Forbid
  jobTemplate:
    {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
    metadata:
      labels:
        {{- . | nindent 8 }}
    {{- end }}
    spec:
      activeDeadlineSeconds: {{ .Values.configManager.activeDeadlineSeconds | default 14400 }}
      template:
        {{- include "cloudanix.configManager.podTemplate" . | nindent 8 }}

{{- if and .Release.IsUpgrade (eq (include "cloudanix.hasAuthToken" .) "true") }}
---
# One config-manager run right after an upgrade (or rollback). `helm upgrade` resets the
# cloudanix-falco-rules ConfigMap to the chart's seed, which drops the workspace's threat
# exclusions until config-manager next writes them back; waiting for the hourly schedule means
# up to an hour of alerts on excluded assets. A plain Job, not a post-upgrade hook: helm would
# wait for it, and a run that cannot reach Cloudanix must not fail the upgrade. The revision in
# the name makes each upgrade's Job new (Jobs are immutable); the TTL removes it. Needs an auth
# token, as config-manager exits at once without one. Never renders under `helm template` or
# ArgoCD (IsUpgrade is false there): run `kubectl create job --from=cronjob/config-manager`
# after a GitOps upgrade instead.
apiVersion: batch/v1
kind: Job
metadata:
  name: {{ .Values.configManager.name }}-upgrade-r{{ .Release.Revision }}
  namespace: cloudanix
  {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
  labels:
    {{- . | nindent 4 }}
  {{- end }}
spec:
  activeDeadlineSeconds: {{ .Values.configManager.activeDeadlineSeconds | default 14400 }}
  backoffLimit: 0
  ttlSecondsAfterFinished: 3600
  template:
    {{- include "cloudanix.configManager.podTemplate" . | nindent 4 }}
{{- end }}

---

apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ .Values.configManager.configMapName }}
  namespace: cloudanix
  {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
  labels:
    {{- . | nindent 4 }}
  {{- end }}
data:
  config.yaml: |
    chartVersion:  {{ .Chart.Version }}
    releaseName: {{ .Release.Name }}
    common:
      logLevel: {{ .Values.logLevel | default "warn" }}
      requestTimeout: {{ .Values.requestTimeout | default 30 }}
      httpMaxRetries: {{ .Values.httpMaxRetries | default 3 }}
      accountId: {{ required "Account Id is required!" .Values.accountId }}
      clusterIdentifier: {{ required "Cluster Identifier is required!" .Values.clusterIdentifier }}
      {{- if and (.Values.clusterName) (ne (toString .Values.clusterName) "DEFAULT") }}
      clusterName:  {{ .Values.clusterName }}
      {{- else if (.Values.clusterIdentifier) }}
      clusterName: {{ required "Cluster Name is required!" (splitList "/" (toString .Values.clusterIdentifier)) | last }}
      {{- end }}
      clusterDomain: {{ required "Cluster Domain is required!" .Values.clusterDomain }}
    configManager:
      configUrl: {{ required "A valid URL is required!" .Values.configManager.configURL }}
      templateType: {{ required "configManager.templateType is required!" .Values.configManager.templateType }}
      {{- if eq (include "cloudanix.hasAuthToken" .) "true" }}
      installSource: DIRECT
      {{- end }}
      {{- with .Values.configManager.statusReporting }}
      statusReporting:
        enabled: {{ .enabled }}
        timeoutSeconds: {{ .timeoutSeconds }}
        maxRetries: {{ .maxRetries }}
      {{- end }}
    resources:
      falcoService:
        daemonName: {{ .Release.Name }}-falco
        # Fixed name, see templates/falco-rules.tpl.
        configMapName: cloudanix-falco-rules
        namespace: cloudanix
      configManager:
        cronJobName: {{ .Values.configManager.name }}
        configMapName: {{ .Values.configManager.configMapName }}
        namespace: cloudanix
      threatMonitor:
        deployName: {{ .Values.threatMonitor.name }}
        configMapName: {{ .Values.threatMonitor.configMapName }}
        namespace: cloudanix
      inventoryCollector:
        deployName: {{ .Values.inventoryCollector.name }}
        configMapName: {{ .Values.inventoryCollector.configMapName }}
        namespace: cloudanix
      misconfigScanner:
        cronJobName: {{ .Values.misconfigScanner.name }}
        configMapName: {{ .Values.misconfigScanner.configMapName }}
        namespace: {{ .Release.Namespace }}
      {{- if eq (include "cloudanix.trafficExporterEnabled" .) "true" }}
      trafficExporter:
        deployName: {{ .Values.trafficExporter.name }}
        configMapName: {{ .Values.trafficExporter.name }}-config
        namespace: {{ .Release.Namespace }}
      {{- end }}
      {{- if eq (include "cloudanix.vulnScanningEnabled" .) "true" }}
      vulnScanner:
        cronJobName: {{ .Values.vulnScanner.name }}
        configMapName: {{ .Values.vulnScanner.configMapName }}
        namespace: {{ .Release.Namespace }}
      {{- end }}

---

apiVersion: v1
kind: ServiceAccount
metadata:
  name: config-manager-sa
  namespace: cloudanix
  {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
  labels:
    {{- . | nindent 4 }}
  {{- end }}
  {{- with include "cloudanix.authTokenSAAnnotations" . }}
  annotations:
    {{- . | nindent 4 }}
  {{- end }}

---

kind: ClusterRole
apiVersion: rbac.authorization.k8s.io/v1
metadata:
  name: config-manager-role
  namespace: cloudanix
  {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
  labels:
    {{- . | nindent 4 }}
  {{- end }}
rules:
- apiGroups: ["","apps","batch"]
  resources: ["deployments","daemonsets","configmaps","cronjobs"]
  verbs: ["get", "watch", "list", "update", "patch"]

---

apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: config-manager
  namespace: cloudanix
  {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
  labels:
    {{- . | nindent 4 }}
  {{- end }}
subjects:
- kind: ServiceAccount
  name: config-manager-sa
  namespace: cloudanix
roleRef:
  kind: ClusterRole
  name: config-manager-role
  apiGroup: rbac.authorization.k8s.io

---

kind: ClusterRole
apiVersion: rbac.authorization.k8s.io/v1
metadata:
  name: config-manager-role-secrets
  namespace: cloudanix
  {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
  labels:
    {{- . | nindent 4 }}
  {{- end }}
rules:
- apiGroups: ["","apps","batch"]
  resources: ["secrets"]
  verbs: ["get", "watch", "list", "update", "patch"]

---

apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: config-manager
  namespace: cloudanix
  {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
  labels:
    {{- . | nindent 4 }}
  {{- end }}
subjects:
- kind: ServiceAccount
  name: config-manager-sa
  namespace: cloudanix
roleRef:
  kind: ClusterRole
  name: config-manager-role-secrets
  apiGroup: rbac.authorization.k8s.io

---

# Read-only pod/log access for the on-demand diagnostic-bundle collector
# (docs/config-sync-status/standard.md §3.1 in container-security-services).
# Staff-triggered, capped at 5MiB per run (see config-manager/diagnostics) -
# unlike the (not yet built) always-on scheduled log shipping in plan.md §5,
# this is small and rare enough to ship always-on rather than opt-in, but it
# is still namespace-scoped via RoleBinding (same binding pattern as
# config-manager-role-secrets) and read-only. The pods/jobs/metrics reads
# also feed the hourly per-service health in the sync report (no logs; see
# docs/cluster-health/plan.md in container-security-services).
kind: ClusterRole
apiVersion: rbac.authorization.k8s.io/v1
metadata:
  name: config-manager-role-diagnostics
  namespace: cloudanix
  {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
  labels:
    {{- . | nindent 4 }}
  {{- end }}
rules:
- apiGroups: [""]
  resources: ["pods"]
  verbs: ["get", "list"]
- apiGroups: [""]
  resources: ["pods/log"]
  verbs: ["get"]
# Warning events surface PodSecurity FailedCreate / scheduling / OOM causes;
# Jobs carry DeadlineExceeded / BackoffLimitExceeded for scanner CronJob runs.
- apiGroups: [""]
  resources: ["events"]
  verbs: ["list"]
- apiGroups: ["batch"]
  resources: ["jobs"]
  verbs: ["list"]
# Through the RoleBinding this only reaches the cloudanix namespace object
# itself - read for its pod-security.kubernetes.io/* labels.
- apiGroups: [""]
  resources: ["namespaces"]
  verbs: ["get"]
# Current container usage from metrics-server, against the pod spec limits:
# a memory near its limit is an OOM kill about to happen. Without
# metrics-server installed the read 404s and health reports limits only.
- apiGroups: ["metrics.k8s.io"]
  resources: ["pods"]
  verbs: ["list"]

---

apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: config-manager-diagnostics
  namespace: cloudanix
  {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
  labels:
    {{- . | nindent 4 }}
  {{- end }}
subjects:
- kind: ServiceAccount
  name: config-manager-sa
  namespace: cloudanix
roleRef:
  kind: ClusterRole
  name: config-manager-role-diagnostics
  apiGroup: rbac.authorization.k8s.io
---

# Node list for the cluster context in config-manager's hourly sync report:
# node count (against the Falco DaemonSet's desired count = runtime-protection
# coverage), Ready/pressure/cordoned counts, and distinct kernel/container
# runtime/kubelet versions (what decides Falco driver support and the
# scanner's runtime socket). Nodes are cluster-scoped, so this is the one
# cluster-wide grant here; read-only, list only, and config-manager keeps
# only aggregates (docs/cluster-health/plan.md in container-security-services).
kind: ClusterRole
apiVersion: rbac.authorization.k8s.io/v1
metadata:
  name: config-manager-role-nodes
  {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
  labels:
    {{- . | nindent 4 }}
  {{- end }}
rules:
- apiGroups: [""]
  resources: ["nodes"]
  verbs: ["list"]

---

apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: config-manager-nodes
  {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
  labels:
    {{- . | nindent 4 }}
  {{- end }}
subjects:
- kind: ServiceAccount
  name: config-manager-sa
  namespace: cloudanix
roleRef:
  kind: ClusterRole
  name: config-manager-role-nodes
  apiGroup: rbac.authorization.k8s.io
---
