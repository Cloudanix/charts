{{- if eq (include "cloudanix.trafficExporterEnabled" .) "true" }}
{{- /* Chart-owned labels, merged after the custom ones so they always win.
The pod set must keep `app` to match the selector and the metrics Service. */}}
{{- $ownLabels := merge (include "cloudanix.labels" . | fromYaml) (dict "component" "traffic-exporter") }}
{{- $podOwnLabels := merge (include "cloudanix.selectorLabels" . | fromYaml) (dict "app" .Values.trafficExporter.name "component" "traffic-exporter") }}
---
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ .Values.trafficExporter.name }}-config
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "cloudanix.mergeLabels" (list .Values.commonLabels $ownLabels) | nindent 4 }}
data:
  config.yaml: |
    common:
      listenerUrl: {{ required "trafficExporter.listenerUrl is required!" .Values.trafficExporter.listenerUrl | quote }}
      requestTimeout: {{ .Values.requestTimeout | default 30 }}
      httpMaxRetries: {{ .Values.httpMaxRetries | default 3 }}
      bufferSize: {{ .Values.trafficExporter.bufferSize }}
      bufferDuration: {{ .Values.trafficExporter.bufferDuration }}
      logLevel: {{ .Values.logLevel | default "warn" }}
      accountId: {{ required "Account Id is required!" .Values.accountId }}
      clusterIdentifier: {{ required "Cluster Identifier is required!" .Values.clusterIdentifier }}
      {{- if and (.Values.clusterName) (ne (toString .Values.clusterName) "DEFAULT") }}
      clusterName: {{ .Values.clusterName }}
      {{- end }}
      clusterDomain: {{ required "Cluster Domain is required!" .Values.clusterDomain }}
    trafficExporter:
      {{- if .Values.trafficExporter.ignoreNamespaces }}
      ignoreNamespaces:
        {{- range .Values.trafficExporter.ignoreNamespaces }}
        - {{ . | quote }}
        {{- end }}
      {{- else }}
      ignoreNamespaces: []
      {{- end }}
      {{- if .Values.trafficExporter.allowedNamespaces }}
      allowedNamespaces:
        {{- range .Values.trafficExporter.allowedNamespaces }}
        - {{ . | quote }}
        {{- end }}
      {{- else }}
      allowedNamespaces: []
      {{- end }}
      templateType: {{ required "trafficExporter.templateType is required!" .Values.trafficExporter.templateType }}
      {{- if eq (include "cloudanix.hasAuthToken" .) "true" }}
      enabled: true
      {{- end }}

---
apiVersion: v1
kind: ServiceAccount
metadata:
  name: {{ .Values.trafficExporter.name }}
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "cloudanix.mergeLabels" (list .Values.commonLabels $ownLabels) | nindent 4 }}
  {{- with include "cloudanix.authTokenSAAnnotations" . }}
  annotations:
    {{- . | nindent 4 }}
  {{- end }}

---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: {{ .Release.Namespace }}-{{ .Values.trafficExporter.name }}
  labels:
    {{- include "cloudanix.mergeLabels" (list .Values.commonLabels $ownLabels) | nindent 4 }}
rules:
  - apiGroups: [""]
    resources: ["pods", "namespaces"]
    verbs: ["get", "list"]

---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: {{ .Release.Namespace }}-{{ .Values.trafficExporter.name }}
  labels:
    {{- include "cloudanix.mergeLabels" (list .Values.commonLabels $ownLabels) | nindent 4 }}
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: {{ .Release.Namespace }}-{{ .Values.trafficExporter.name }}
subjects:
  - kind: ServiceAccount
    name: {{ .Values.trafficExporter.name }}
    namespace: {{ .Release.Namespace }}

---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ .Values.trafficExporter.name }}
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "cloudanix.mergeLabels" (list .Values.commonLabels $ownLabels .Values.trafficExporter.labels) | nindent 4 }}
spec:
  replicas: {{ .Values.trafficExporter.replicaCount }}
  selector:
    matchLabels:
      app: {{ .Values.trafficExporter.name }}
  template:
    metadata:
      labels:
        {{- include "cloudanix.mergeLabels" (list .Values.commonLabels .Values.trafficExporter.podLabels $podOwnLabels) | nindent 8 }}
      {{- with include "cloudanix.podAnnotations" (dict "root" . "component" .Values.trafficExporter.podAnnotations) }}
      annotations:
        {{- . | nindent 8 }}
      {{- end }}
    spec:
      serviceAccountName: {{ .Values.trafficExporter.name }}
      {{- with include "cloudanix.podSpec" . }}
      {{- . | nindent 6 }}
      {{- end }}

      securityContext:
        runAsNonRoot: {{ .Values.trafficExporter.securityContext.runAsNonRoot }}
        runAsUser: {{ .Values.trafficExporter.securityContext.runAsUser }}
        runAsGroup: {{ .Values.trafficExporter.securityContext.runAsGroup }}
        fsGroup: {{ .Values.trafficExporter.securityContext.fsGroup }}
        seccompProfile:
          type: RuntimeDefault
      
      containers:
      - name: exporter
        image: {{ .Values.trafficExporter.image }}
        imagePullPolicy: IfNotPresent
        
        securityContext:
          allowPrivilegeEscalation: false
          readOnlyRootFilesystem: true
          runAsNonRoot: true
          runAsUser: {{ .Values.trafficExporter.securityContext.runAsUser }}
          runAsGroup: {{ .Values.trafficExporter.securityContext.runAsGroup }}
          capabilities:
            drop:
              - ALL
        
        args:
          - -config
          - /app/config/config.yaml
        
        env:
        - name: HUBBLE_RELAY_ADDR
          value: {{ .Values.trafficExporter.hubbleRelayAddress | quote }}
        
        volumeMounts:
        - name: config
          mountPath: /app/config
          readOnly: true
        - name: cloudanix-secrets-volume
          mountPath: /etc/cdx/secrets
          readOnly: true
        - name: tmp
          mountPath: /tmp
        
        resources:
          {{- toYaml (.Values.trafficExporter.resources | default dict) | nindent 10 }}
      
      volumes:
      - name: config
        configMap:
          name: {{ .Values.trafficExporter.name }}-config
      - name: cloudanix-secrets-volume
        {{- include "cloudanix.authSecretVolume" . | nindent 8 }}
      - name: tmp
        emptyDir: {}
      
      terminationGracePeriodSeconds: 30

---
apiVersion: v1
kind: Service
metadata:
  name: {{ .Values.trafficExporter.name }}
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "cloudanix.mergeLabels" (list .Values.commonLabels $ownLabels) | nindent 4 }}
spec:
  type: ClusterIP
  ports:
  - name: metrics
    port: 9090
    targetPort: 9090
    protocol: TCP
  selector:
    app: {{ .Values.trafficExporter.name }}
{{- end }}
