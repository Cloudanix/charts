#!/usr/bin/env bash
# Render assertions for the two Cilium profiles (one Cilium chart, two aliases in Chart.yaml):
# `cilium` (EKS, AWS VPC CNI chaining) and `ciliumOke` (OKE, Flannel generic-veth chaining).
# The OKE profile is chart-owned so an OKE install needs no extra values file; exactly one
# profile may be on, and ciliumOke needs clusterDomain OCI.
# Requires helm and the subcharts (helm dependency build chart).
# Run: chart/tests/cilium_profile_render_test.sh
set -euo pipefail

cd "$(dirname "$0")/../.."
CHART=chart
COMMON=(--set accountId=a --set clusterIdentifier=c --set clusterName=n --set authToken=t --set capabilities=all -n cloudanix)
fail=0

render() { helm template cdx "$CHART" "${COMMON[@]}" "$@" 2>&1; }

check() { # <label> <command...>
  local label=$1; shift
  if "$@"; then echo "ok   - $label"; else echo "FAIL - $label"; fail=1; fi
}
has() { grep -qE -- "$1" <<<"$2"; }
lacks() { ! grep -qE -- "$1" <<<"$2"; }
doc() { # <kind> <name> <render>: the one object of that kind and metadata.name
  awk -v kind="kind: $1" -v name="  name: $2" '
    /^---/ { if (k && n) printf "%s", buf; buf = ""; k = n = 0; next }
    { buf = buf $0 "\n" } $0 == kind { k = 1 } $0 == name { n = 1 }
    END { if (k && n) printf "%s", buf }' <<<"$3"
}

oke=$(render --set clusterDomain=OCI --set ciliumOke.enabled=true)
check "OKE profile renders the Cilium agent DaemonSet" has '^  name: cilium$' "$oke"
check "OKE profile chains with generic-veth" has '^  cni-chaining-mode: generic-veth$' "$oke"
check "OKE profile mounts the chart's CNI config" has '^  custom-cni-conf: "true"$' "$oke"
check "OKE profile uses the Flannel pod CIDR" has '^  cluster-pool-ipv4-cidr: "10.244.0.0/16"$' "$oke"
check "OKE profile keeps the datapath passive (no L7 proxy)" has '^  enable-l7-proxy: "false"$' "$oke"
check "OKE profile disables identity marks" has '^  enable-identity-mark: "false"$' "$oke"
check "OKE profile renders the Flannel cni-configuration ConfigMap" has '"type": "flannel"' "$oke"
check "OKE profile renders the CNI cleanup hook" has '^  name: cilium-cni-cleanup$' "$oke"
# The datapath stays passive next to OKE's kube-proxy: no replacement, no socket LB, no
# endpoint routes, no policy enforcement.
check "OKE profile keeps kube-proxy" has '^  kube-proxy-replacement: "false"$' "$oke"
check "OKE profile disables socket load balancing" has '^  bpf-lb-sock: "false"$' "$oke"
check "OKE profile adds no endpoint routes" lacks '^  enable-endpoint-routes:' "$oke"
check "OKE profile never enforces policy" has '^  enable-policy: "never"$' "$oke"
check "OKE profile runs one Hubble relay" has '^  replicas: 1$' "$(doc Deployment hubble-relay "$oke")"

# Keys the README tells OKE users to set reach the Cilium agent.
custom=$(render --set clusterDomain=OCI --set ciliumOke.enabled=true --set ciliumOke.commonLabels.team=x \
  --set 'ciliumOke.imagePullSecrets[0].name=regcred' \
  --set 'ciliumOke.tolerations[0].key=dedicated' --set 'ciliumOke.tolerations[0].operator=Exists')
agent=$(doc DaemonSet cilium "$custom")
check "ciliumOke.commonLabels land on the Cilium agent" has '^    team: x$' "$agent"
check "ciliumOke.imagePullSecrets land on the Cilium agent" has '^        - name: regcred$' "$agent"
check "ciliumOke.tolerations land on the Cilium agent" has '^        - key: dedicated$' "$agent"

eks=$(render --set clusterDomain=AWS --set cilium.enabled=true)
check "EKS profile chains with aws-cni" has '^  cni-chaining-mode: aws-cni$' "$eks"
check "EKS profile renders no cni-configuration ConfigMap" lacks '^  name: cni-configuration$' "$eks"
check "EKS profile renders the CNI cleanup hook" has '^  name: cilium-cni-cleanup$' "$eks"

off=$(render --set clusterDomain=OCI)
check "no profile renders no Cilium agent" lacks '^  name: cilium$' "$off"
check "no profile renders no CNI cleanup hook" lacks 'cilium-cni-cleanup' "$off"

both=$(render --set clusterDomain=OCI --set cilium.enabled=true --set ciliumOke.enabled=true || true)
check "both profiles on fails the install" has 'enable one Cilium profile' "$both"

wrong=$(render --set clusterDomain=AWS --set ciliumOke.enabled=true || true)
check "OKE profile off OCI fails the install" has 'needs clusterDomain: OCI' "$wrong"

eks_on_oci=$(render --set clusterDomain=OCI --set cilium.enabled=true || true)
check "EKS profile on OCI fails the install" has 'on clusterDomain: OCI use ciliumOke.enabled' "$eks_on_oci"

overlay=$(render --set clusterDomain=OCI --set cilium.enabled=true -f "$CHART/tests/fixtures/values-oke-2.4.4.yaml")
check "the retired v2.4.4 OKE overlay with cilium.enabled still renders generic-veth" \
  has '^  cni-chaining-mode: generic-veth$' "$overlay"

# ciliumOke is the `cilium` defaults merged with the retired overlay. Lock that: the two renders
# may differ only in the per-render Hubble certificates and the alias in `# Source:` paths. A
# change to a key both blocks carry must go into both.
comparable() { grep -vE '^# Source: |^  (ca|tls)\.(crt|key): ' <<<"$1"; }
same() { [ "$(comparable "$1")" = "$(comparable "$2")" ]; }
check "ciliumOke renders the same objects as cilium + the retired v2.4.4 overlay" same "$oke" "$overlay"

exit $fail
