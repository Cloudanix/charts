#!/usr/bin/env bash
# Render assertions for vuln-scanner runtime socket selection.
# values.yaml leaves the socket empty, so the chart picks by clusterDomain (CRI-O on OCI, else
# containerd), the same rule config-manager applies on every sync. An explicit path always wins.
# Requires helm. Run: chart/tests/runtime_socket_render_test.sh
set -euo pipefail

cd "$(dirname "$0")/../.."
CHART=chart
COMMON=(--set accountId=a --set clusterIdentifier=c --set clusterName=n --set authToken=t --set capabilities=vulnerabilities)
# ConfigMap, plus annotation, env, mount and hostPath on the CronJob and the initial Job.
SURFACES=9
fail=0

render() { helm template cdx "$CHART" "${COMMON[@]}" "$@" -s templates/vuln-scanner.tpl 2>&1; }

assert_surfaces() { # <manifest> <socket> <label>
  # Count YAML values equal to the socket, so comments that mention it do not count.
  count=$(grep -cE -- "^ *[A-Za-z./-]+: \"?$2\"?\$" <<<"$1" || true)
  if (( count == SURFACES )); then echo "ok   - $3"; else echo "FAIL - $3 (got $count, want $SURFACES)"; fail=1; fi
}

oci=$(render --set clusterDomain=OCI)
assert_surfaces "$oci" "/run/crio/crio.sock" "default values give every scanner surface CRI-O on OCI"
annotations=$(grep -cF 'cloudanix.com/container-runtime-socket: "/run/crio/crio.sock"' <<<"$oci" || true)
if (( annotations == 2 )); then
  echo "ok   - CronJob and initial Job carry socket annotation"
else
  echo "FAIL - CronJob and initial Job carry socket annotation (got $annotations, want 2)"
  fail=1
fi

for domain in AWS GCP AZURE; do
  other=$(render --set clusterDomain=$domain)
  assert_surfaces "$other" "/run/containerd/containerd.sock" "default values pick containerd on $domain"
done

override=$(render --set clusterDomain=OCI --set vulnScanner.containerRuntimeSocket=/run/k3s/containerd/containerd.sock)
assert_surfaces "$override" "/run/k3s/containerd/containerd.sock" "explicit socket overrides OCI default"
if grep -qF "/run/crio/crio.sock" <<<"$override"; then
  echo "FAIL - explicit socket render retains OCI default"
  fail=1
else
  echo "ok   - explicit socket render contains no OCI default"
fi

exit $fail
