#!/usr/bin/env bash
# Render assertions for trustedImageRepositories (chart/README.md, "Keep the sensors on your
# registry"): config-manager gets CDX_TRUSTED_IMAGE_REPOSITORIES on every pod it runs as
# (CronJob and the post-upgrade Job), only when the value is set, and the README recipe
# moves every Cloudanix image to the private registry while Falco keeps its upstream image.
# Requires helm. Run: chart/tests/private_registry_render_test.sh
set -euo pipefail

cd "$(dirname "$0")/../.."
CHART=chart
COMMON=(-f chart/local-values.yaml --set accountId=a --set clusterIdentifier=c --set clusterDomain=AWS --set authToken=t)
REG=123456789012.dkr.ecr.us-east-1.amazonaws.com/docker-hub
fail=0

render() { helm template cdx "$CHART" "${COMMON[@]}" "$@" 2>&1; }

assert_count() { # <haystack> <needle> <want> <label>
  local got
  got=$(grep -cF -- "$2" <<<"$1" || true)
  if [[ "$got" == "$3" ]]; then echo "ok   - $4"; else echo "FAIL - $4 (got $got, want $3)"; fail=1; fi
}

# Unset: no env var, so config-manager trusts only its built-in repositories.
plain=$(render -s templates/config-manager.tpl)
assert_count "$plain" "CDX_TRUSTED_IMAGE_REPOSITORIES" 0 "no trusted-repository env by default"

# Upgrade renders the CronJob plus the one-off post-upgrade Job; both run config-manager.
trusted=$(render --is-upgrade -s templates/config-manager.tpl \
  --set-json "trustedImageRepositories=[\"$REG/cloudanix/\",\"registry.example.com/team/\"]")
assert_count "$trusted" "name: CDX_TRUSTED_IMAGE_REPOSITORIES" 2 "env on the CronJob and the post-upgrade Job"
assert_count "$trusted" "value: \"$REG/cloudanix/,registry.example.com/team/\"" 2 "entries joined with commas"

# The README recipe (customers host only Cloudanix images): every Cloudanix image comes from
# the private registry, Falco and falcoctl keep the chart's upstream images.
sensors=()
for sensor in configManager:config-manager threatMonitor:threat-monitor inventoryCollector:inventory-collector \
  trafficExporter:traffic-exporter vulnScanner:vuln-scanner misconfigScanner:misconfig-scanner; do
  sensors+=(--set "${sensor%%:*}.image=$REG/cloudanix/${sensor#*:}:v2.3.7")
done
recipe=$(render --set capabilities=all --set cilium.enabled=true \
  --set-json "trustedImageRepositories=[\"$REG/cloudanix/\"]" "${sensors[@]}")
assert_count "$recipe" "image: docker.io/cloudanix/" 0 "no Cloudanix image left on Docker Hub"
assert_count "$recipe" "image: $REG/falcosecurity/" 0 "Falco images untouched by the recipe"
assert_count "$recipe" "image: docker.io/falcosecurity/falco:" 1 "Falco keeps the chart's upstream image"

# Default install: every image from the chart's defaults, nothing from a private registry.
default=$(render --set capabilities=all --set cilium.enabled=true)
assert_count "$default" "image: $REG/" 0 "default install pulls nothing from a private registry"
assert_count "$default" "CDX_TRUSTED_IMAGE_REPOSITORIES" 0 "default install trusts only the built-ins"
assert_count "$default" "image: docker.io/falcosecurity/falco:" 1 "default install runs the upstream Falco image"
for repo in config-manager threat-monitor inventory-collector traffic-exporter vuln-scanner misconfig-scanner; do
  if grep -qF "image: docker.io/cloudanix/$repo:" <<<"$default"; then echo "ok   - default $repo from Docker Hub"; else echo "FAIL - default $repo from Docker Hub"; fail=1; fi
done

# The same recipe as a values file (what the README recommends: --set values are dropped on
# the next helm upgrade unless passed again) renders exactly like the --set flags.
work=$(mktemp -d "${TMPDIR:-/tmp}/cdx-registry.XXXXXX")
trap 'rm -rf "$work"' EXIT
{
  echo "trustedImageRepositories: [\"$REG/cloudanix/\"]"
  for sensor in configManager:config-manager threatMonitor:threat-monitor inventoryCollector:inventory-collector \
    trafficExporter:traffic-exporter vulnScanner:vuln-scanner misconfigScanner:misconfig-scanner; do
    printf '%s:\n  image: %s\n' "${sensor%%:*}" "$REG/cloudanix/${sensor#*:}:v2.3.7"
  done
} > "$work/registry-values.yaml"
from_file=$(render --set capabilities=all --set cilium.enabled=true -f "$work/registry-values.yaml")
# Images and the trust env only: the Cilium subchart generates fresh TLS certs on every render.
pulls() { grep -E "image: |CDX_TRUSTED_IMAGE_REPOSITORIES|value: \"$REG" <<<"$1" | sort; }
if [[ "$(pulls "$from_file")" == "$(pulls "$recipe")" ]]; then echo "ok   - values file sets the same images and trust as the --set flags"; else echo "FAIL - values file sets the same images and trust as the --set flags"; fail=1; fi

exit $fail
