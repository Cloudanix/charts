# Cloudanix Container Protection Helm Chart

This Helm chart installs Cloudanix services for container protection.

Always installed: `config-manager`, `inventory-collector`.

The rest are picked with the `capabilities` value: a comma-separated list
(default `threats,vulnerabilities,compliance`) or `all`. On the command line escape
the commas: `--set 'capabilities=threats\,compliance'`.

| Capability        | Services                                                                    |
| ----------------- | --------------------------------------------------------------------------- |
| `threats`         | threat-monitor + Falco (set `falco.enabled=false` when threats is not used) |
| `vulnerabilities` | vuln-scanner                                                                |
| `compliance`      | misconfig-scanner                                                           |
| `traffic`         | traffic-exporter + Cilium (`cilium.enabled=true`)                           |

## Falco and Cilium Charts

Falco and Cilium are community charts listed as dependencies in Chart.yaml. Helm installs them
based on `falco.enabled` / `cilium.enabled` only, so keep those in step with `capabilities`.

## Usage

Clone this repository and in `chart` folder, update the `yourValues.yaml` to override the values.
To install the chart, run

```bash
helm dependency update
helm install cloudanix -f yourValues.yaml .
```

To delete the chart, run

```bash
helm delete cloudanix
```
