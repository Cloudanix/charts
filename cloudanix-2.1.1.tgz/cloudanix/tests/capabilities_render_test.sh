#!/usr/bin/env bash
# Render assertions for the capabilities feature gate: which workloads each
# capability installs. Requires helm and the subcharts (helm dependency build chart).
# Run: chart/tests/capabilities_render_test.sh
set -euo pipefail

cd "$(dirname "$0")/../.."
CHART=chart
COMMON=(--set accountId=a --set clusterIdentifier=c --set clusterName=n --set clusterDomain=AWS --set authToken=t)
fail=0

# One "Kind/name" line per workload. Indentation under metadata differs between
# templates, so take the first name: line after each metadata:.
workloads() {
  helm template cdx "$CHART" "${COMMON[@]}" "$@" |
    awk '/^kind: /{k=$2} /^metadata:/{m=1; next} m && /^ +name: /{print k "/" $2; m=0}' |
    grep -E '^(Deployment|DaemonSet|CronJob)/'
}

assert_has() { # <haystack> <needle> <label>
  if grep -qxF -- "$2" <<<"$1"; then echo "ok   - $3"; else echo "FAIL - $3"; fail=1; fi
}
assert_missing() {
  if grep -qxF -- "$2" <<<"$1"; then echo "FAIL - $3"; fail=1; else echo "ok   - $3"; fi
}

defaults=$(workloads)
assert_has "$defaults" "CronJob/misconfig-scanner" "default installs compliance"
assert_has "$defaults" "CronJob/vuln-scanner" "default installs vulnerabilities"
assert_has "$defaults" "Deployment/threat-monitor" "default installs threats"
assert_missing "$defaults" "Deployment/traffic-exporter" "default leaves traffic off"

# Compliance used to ride on threats; each now stands alone.
threats=$(workloads --set capabilities=threats)
assert_has "$threats" "Deployment/threat-monitor" "threats installs threat-monitor"
assert_missing "$threats" "CronJob/misconfig-scanner" "threats alone skips compliance"

compliance=$(workloads --set capabilities=compliance)
assert_has "$compliance" "CronJob/misconfig-scanner" "compliance installs misconfig-scanner"
assert_missing "$compliance" "Deployment/threat-monitor" "compliance alone skips threats"
assert_missing "$compliance" "CronJob/vuln-scanner" "compliance alone skips vulnerabilities"

pair=$(workloads --set 'capabilities=vulnerabilities\,compliance')
assert_has "$pair" "CronJob/misconfig-scanner" "escaped list enables compliance"
assert_has "$pair" "CronJob/vuln-scanner" "escaped list enables vulnerabilities"

assert_has "$(workloads --set capabilities=all)" "CronJob/misconfig-scanner" "all includes compliance"

# Falco belongs to threats, but Helm installs subcharts from falco.enabled alone, so the
# install command sets falco.enabled=false whenever threats is off. Pin that toggle.
assert_has "$defaults" "DaemonSet/cdx-falco" "default installs falco"
assert_missing "$(workloads --set capabilities=vulnerabilities --set falco.enabled=false)" "DaemonSet/cdx-falco" "falco.enabled=false skips falco"

# Core services ship with every install, whatever the capabilities.
for caps in threats vulnerabilities compliance traffic all; do
  core=$(workloads --set capabilities=$caps)
  assert_has "$core" "CronJob/config-manager" "config-manager installed with capabilities=$caps"
  assert_has "$core" "Deployment/inventory-collector" "inventory-collector installed with capabilities=$caps"
done

exit $fail
