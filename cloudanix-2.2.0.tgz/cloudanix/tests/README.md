# chart/tests

| Script | Needs | What it protects |
|---|---|---|
| `misconfig_render_test.sh` | helm | the misconfig-scanner template renders the right benchmark per `clusterDomain`, and its ClusterRole grants the kinds the audits need but never `secrets` |
| `uninstall_notify_render_test.sh` | helm | the pre-delete uninstall notice renders as a sync-status report flagged `event: UNINSTALL`, always exits 0 (a failed pre-delete hook aborts `helm uninstall`), and is skipped without an auth token or with status reporting off |
| `initial_run_render_test.sh` | helm | the vuln/misconfig scanners' one-off initial-run Jobs render on install (with a token, capability on, `initialRun.enabled`), are plain Jobs (a hook would block `helm install` for the whole scan) kept with `resource-policy: keep`, and leave the CronJobs untouched |
| `runtime_socket_render_test.sh` | helm | every vuln-scanner socket surface is CRI-O on OCI and containerd on every other cloud, and an explicit socket override wins |
| `falco_rules_render_test.sh` | helm, yq | the Falco rules wiring (`docs/falco-rules.md`): falcoctl installs exactly the feeds in `rules/upstream.yaml` and no follow sidecar, the Falco image is that file's version, the `cloudanix-falco-rules` ConfigMap carries `rules/cloudanix.yaml` verbatim and is mounted at `/etc/falco/rules.d` last in `rules_files`, config-manager writes to that ConfigMap, and an upgrade (with a token) renders the one-off config-manager Job that restores exclusions |
| `falco_rules_validate_test.sh` | docker, curl, yq | Falco at the pinned version loads `rules/cloudanix.yaml` behind the pinned feeds, default set and all-feeds set. Skips with a warning without docker; CI has it. A rejected rules file would CrashLoop every Falco pod |
| `custom_labels_render_test.py` | helm, PyYAML | every object and pod the chart renders (hooks and the cilium-cleanup DaemonSet included) carries `commonLabels`, pods also their component's `podLabels`, with the chart's own labels winning on a shared key; selectors never change; values render as strings; no empty `labels:` without custom labels; the Falco/Cilium recipe in `chart/README.md` reaches the subcharts' pods |
| `rbac_coverage.py` | helm, PyYAML, sibling repos | three cross-repo contracts that otherwise fail **silently** |

```sh
chart/tests/misconfig_render_test.sh
chart/tests/initial_run_render_test.sh
chart/tests/falco_rules_render_test.sh
chart/tests/falco_rules_validate_test.sh
chart/tests/custom_labels_render_test.py
chart/tests/rbac_coverage.py
```

When `custom_labels_render_test.py` fails on a new object, wire it like the others:
`cloudanix.mergeLabels` with `.Values.commonLabels` first and the object's own labels last
(see `_helpers.tpl`), and add `<component>.podLabels` on pod templates. A new component
also needs its template file in `COMPONENTS` in the script.

## Why `rbac_coverage.py` exists

Each of these breaks with no error anywhere — you just get less data, and notice weeks later
from a gap in the console:

1. **misconfig ClusterRole ⊇ what the audits read.** A missing grant makes `kubectl` exit
   non-zero, so the check reports `WARN` carrying the API server's message instead of a
   finding. A whole benchmark can go quiet this way.
2. **inventory ClusterRole ⊇ what inventory-collector watches.** A watched-but-ungranted GVR
   fails at informer start and that kind is simply absent from inventory. This had actually
   happened with `endpointslices`.
3. **inventory-collector ⊇ the kinds kube-bench names.** The console joins `failed_resources`
   to inventory on `(cluster_identifier, uid)`; an unwatched kind renders half-populated.

Everything is derived from the sources — the benchmark YAML under `kube-bench/cfg`, the
rendered ClusterRoles, and `inventory-collector/kube/resources.go` — so it stays true as
checks are added rather than needing a list kept in step by hand.

## Sibling repos

Found via env vars, defaulting to the usual checkout paths. Missing repos are **skipped, not
failed**, so this still runs in a chart-only checkout:

```sh
KUBE_BENCH_DIR=~/src/kube-bench CSS_DIR=~/src/container-security-services \
    chart/tests/rbac_coverage.py
```

## When a check fires

- *misconfig ClusterRole is missing X* — an audit started reading a new resource. Add it to
  the rule for its apiGroup in `misconfig-scanner.tpl`. **Never add `secrets`**: RBAC has no
  metadata-only read, and `cloudanix-1.0` C4.2 stays manual precisely to avoid it.
- *inventory watches but ClusterRole does not grant X* — add it to
  `inventory-collector.tpl`.
- *kube-bench names X but inventory does not watch it* — add the GVR to `resources.go`, and
  its grant to `inventory-collector.tpl`. Weigh the informer cache first: it holds whole
  objects, which is why Secrets are excluded.
- *no catalog entry for X* — a new Kind appeared. Add it to `CATALOG` in the script so the
  join can be checked at all.
