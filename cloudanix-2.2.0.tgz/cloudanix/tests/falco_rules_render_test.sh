#!/usr/bin/env bash
# Render assertions for the Falco rules wiring (docs/falco-rules.md): rules/upstream.yaml is
# what the chart installs, rules/cloudanix.yaml is what Falco loads, config-manager writes to
# that same ConfigMap, and an upgrade re-runs config-manager once.
# Requires helm, yq and the subcharts (helm dependency build chart).
# Run: chart/tests/falco_rules_render_test.sh
set -euo pipefail

cd "$(dirname "$0")/../.."
CHART=chart
COMMON=(--set accountId=a --set clusterIdentifier=c --set clusterName=n --set clusterDomain=AWS --set authToken=t)
fail=0
command -v yq >/dev/null || { echo "FAIL - yq is required"; exit 1; }

ok() { echo "ok   - $1"; }
bad() { echo "FAIL - $1"; fail=1; }
assert_eq() { # <got> <want> <label>
  if [ "$1" = "$2" ]; then ok "$3"; else bad "$3 (got '$1', want '$2')"; fi
}

render() { helm template cdx "$CHART" "${COMMON[@]}" "$@"; }
# yq expression over the documents of one Kind/name.
pick() { # <rendered> <kind> <name> <expr>
  yq "select(.kind == \"$2\" and .metadata.name == \"$3\") | $4" <<<"$1"
}

all=$(render)

# --- rules/upstream.yaml is what the chart installs ---------------------------------------
want_falco=$(yq '.falco' chart/rules/upstream.yaml)
want_refs=$(yq '.rulesfiles | to_entries | map(.key + ":" + .value) | .[]' chart/rules/upstream.yaml | sort | tr '\n' ' ')
# The subchart appends the container plugin ref; keep the rulesfiles only.
got_refs=$(pick "$all" ConfigMap cdx-falco-falcoctl '.data["falcoctl.yaml"]' | yq '.artifact.install.refs[]' | grep -E '^falco-' | sort | tr '\n' ' ')
assert_eq "$got_refs" "$want_refs" "falcoctl installs exactly the rulesfiles in upstream.yaml"
got_image=$(pick "$all" DaemonSet cdx-falco '.spec.template.spec.containers[] | select(.name == "falco") | .image')
assert_eq "$got_image" "docker.io/falcosecurity/falco:$want_falco" "Falco image is upstream.yaml's version"
follow=$(pick "$all" DaemonSet cdx-falco '.spec.template.spec.containers[].name' | grep -c follow || true)
assert_eq "$follow" "0" "no falcoctl follow sidecar (a chart release is how rules change)"

# --- rules/cloudanix.yaml is what Falco loads -----------------------------------------------
# Byte-identical minus the trailing newline, the way the console serves it (so config-manager's
# first sync sees no change and does not restart Falco).
got_rules=$(pick "$all" ConfigMap cloudanix-falco-rules '.data["cloudanix.yaml"]')
want_rules=$(cat chart/rules/cloudanix.yaml)
if [ "$got_rules" = "$want_rules" ]; then ok "ConfigMap cloudanix-falco-rules carries rules/cloudanix.yaml verbatim"; else bad "ConfigMap cloudanix-falco-rules differs from rules/cloudanix.yaml"; fi
mount_cm=$(pick "$all" DaemonSet cdx-falco '.spec.template.spec.volumes[] | select(.name == "cloudanix-rules") | .configMap.name')
assert_eq "$mount_cm" "cloudanix-falco-rules" "Falco mounts the cloudanix-falco-rules ConfigMap"
mount_path=$(pick "$all" DaemonSet cdx-falco '.spec.template.spec.containers[] | select(.name == "falco") | .volumeMounts[] | select(.name == "cloudanix-rules") | .mountPath')
assert_eq "$mount_path" "/etc/falco/rules.d" "mounted at /etc/falco/rules.d"
last_rules_file=$(pick "$all" ConfigMap cdx-falco '.data["falco.yaml"]' | yq '.rules_files[-1]')
assert_eq "$last_rules_file" "/etc/falco/rules.d" "rules.d is the last rules_files entry (our file appends to upstream rules)"
subchart_cm=$(yq 'select(.kind == "ConfigMap" and .metadata.name == "cdx-falco-rules") | .metadata.name' <<<"$all")
assert_eq "$subchart_cm" "" "the subchart renders no rules ConfigMap of its own (customRules is empty)"

# --- config-manager writes to that ConfigMap -----------------------------------------------
cm_name=$(pick "$all" ConfigMap config-manager-cm '.data["config.yaml"]' | yq '.resources.falcoService.configMapName')
assert_eq "$cm_name" "cloudanix-falco-rules" "config-manager targets cloudanix-falco-rules"

# --- off with Falco ---------------------------------------------------------------------------
off=$(render --set falco.enabled=false | yq 'select(.kind == "ConfigMap" and .metadata.name == "cloudanix-falco-rules") | .metadata.name')
assert_eq "$off" "" "falco.enabled=false renders no rules ConfigMap"

# --- an upgrade re-runs config-manager once ------------------------------------------------
job=$(render --is-upgrade | yq 'select(.kind == "Job" and .metadata.name == "config-manager-upgrade-r1") | .metadata.name')
assert_eq "$job" "config-manager-upgrade-r1" "upgrade renders the one-off config-manager Job"
job_image=$(render --is-upgrade | yq 'select(.kind == "Job" and .metadata.name == "config-manager-upgrade-r1") | .spec.template.spec.containers[0].image')
cron_image=$(pick "$all" CronJob config-manager '.spec.jobTemplate.spec.template.spec.containers[0].image')
assert_eq "$job_image" "$cron_image" "the Job runs the CronJob's pod"
no_job=$(yq 'select(.kind == "Job" and .metadata.name == "config-manager-upgrade-r1") | .metadata.name' <<<"$all")
assert_eq "$no_job" "" "install renders no upgrade Job"
no_token=$(render --is-upgrade --set authToken=DEFAULT | yq 'select(.kind == "Job" and .metadata.name == "config-manager-upgrade-r1") | .metadata.name')
assert_eq "$no_token" "" "no upgrade Job without an auth token (config-manager would exit at once)"

exit $fail
