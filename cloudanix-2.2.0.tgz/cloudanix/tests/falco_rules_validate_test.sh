#!/usr/bin/env bash
# Loads rules/cloudanix.yaml with the Falco and the upstream feeds rules/upstream.yaml pins,
# the way a node does: once behind the default feed (falco-rules) and once behind all three
# (the incubating/sandbox opt-in in values.yaml). A rules file Falco rejects takes every Falco
# pod down (docs/falco-upgrade.md section 4), so this is the gate for any rules change.
# Requires docker, curl and yq; skips (exit 0, with a warning) without docker so a chart-only
# checkout still runs the other tests. CI has docker.
# Run: chart/tests/falco_rules_validate_test.sh
set -euo pipefail

cd "$(dirname "$0")/../.."
command -v yq >/dev/null || { echo "FAIL - yq is required"; exit 1; }
if ! docker info >/dev/null 2>&1; then
  echo "::warning title=falco --validate skipped::docker is not available, rules/cloudanix.yaml was not validated"
  exit 0
fi

falco=$(yq '.falco' chart/rules/upstream.yaml)
work=$(mktemp -d)
trap 'rm -rf "$work"' EXIT
cp chart/rules/cloudanix.yaml "$work/"

# Each rulesfile artifact is its upstream file at the tag of the same name.
declare -A files=([falco-rules]=falco_rules.yaml [falco-incubating-rules]=falco-incubating_rules.yaml [falco-sandbox-rules]=falco-sandbox_rules.yaml)
for name in "${!files[@]}"; do
  version=$(yq ".rulesfiles[\"$name\"]" chart/rules/upstream.yaml)
  curl -fsSL "https://raw.githubusercontent.com/falcosecurity/rules/$name-$version/rules/${files[$name]}" -o "$work/${files[$name]}"
done

validate() { # <label> <files...>
  local label=$1; shift
  local args=()
  for f in "$@"; do args+=(--validate "/rules/$f"); done
  if docker run --rm -v "$work:/rules:ro" "docker.io/falcosecurity/falco:$falco" falco "${args[@]}" >"$work/out" 2>&1; then
    echo "ok   - $label"
  else
    echo "FAIL - $label"; cat "$work/out"; return 1
  fi
}

validate "falco $falco loads falco-rules + cloudanix.yaml (default)" falco_rules.yaml cloudanix.yaml
validate "falco $falco loads all feeds + cloudanix.yaml (opt-in)" falco_rules.yaml falco-incubating_rules.yaml falco-sandbox_rules.yaml cloudanix.yaml
