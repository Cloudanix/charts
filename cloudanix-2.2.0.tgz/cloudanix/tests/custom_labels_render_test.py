#!/usr/bin/env python3
"""Render assertions for custom labels (commonLabels + <component>.podLabels).

Renders the chart twice with every template switched on, once plain and once with custom
labels, and compares object by object:
  1. every object's labels == commonLabels + the chart's own labels (chart wins);
  2. every pod template's labels == commonLabels + that component's podLabels + the
     chart's own pod labels (podLabels beat commonLabels, chart beats both);
  3. selectors (Deployment, DaemonSet, Service) are identical: custom labels never enter
     one, because a Deployment selector cannot change after install;
  4. label values are strings, even when given as YAML numbers or booleans;
  5. with no custom labels nothing renders an empty or null `labels:`.
It also checks the Falco/Cilium recipe from chart/README.md ("Custom labels") still lands
the labels on the subcharts' pods.

Usage (needs helm, PyYAML and the subchart archives from `helm dependency build chart`):
    chart/tests/custom_labels_render_test.py
"""
import os
import subprocess
import sys
import tempfile

try:
    import yaml
except ImportError:
    sys.exit("PyYAML required: pip install pyyaml")

CHART = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OWN_SOURCE = "cloudanix/templates/"

# Every template on: hooks need a token, cilium-cleanup needs cilium, the CNI ConfigMap
# needs generic-veth chaining on GCP, the PVC needs persistence.
COVERAGE = [
    "--set", "accountId=a", "--set", "clusterIdentifier=c", "--set", "clusterDomain=GCP",
    "--set", "authToken=t", "--set", "capabilities=all", "--set", "cilium.enabled=true",
    "--set", "cilium.cni.chainingMode=generic-veth",
    "--set", "vulnScanner.persistence.enabled=true", "--set", "dummyServer.enabled=true",
]

# Template file -> values key whose podLabels apply to its pods. Hooks, Namespace etc.
# only take commonLabels.
COMPONENTS = {
    "threat-monitor.tpl": "threatMonitor",
    "inventory-collector.tpl": "inventoryCollector",
    "traffic-exporter.tpl": "trafficExporter",
    "config-manager.tpl": "configManager",
    "misconfig-scanner.tpl": "misconfigScanner",
    "vuln-scanner.tpl": "vulnScanner",
}

# YAML int and bool on purpose (check 4); `app` and `name` collide with chart labels.
COMMON = {"team": "platform", "cost-center": 1234, "pci": True, "tier": "common",
          "app": "hijack", "name": "hijack"}
CUSTOM = {"commonLabels": COMMON}
for _key in COMPONENTS.values():
    CUSTOM[_key] = {"podLabels": {"tier": f"pod-{_key}", "app": "hijack"}}

# Keep in step with the Falco/Cilium example in chart/README.md.
SUBCHART_RECIPE = """
cdxLabels: &cdxLabels
  team: platform
  cost-center: "1234"
commonLabels:
  <<: *cdxLabels
  app.kubernetes.io/name: hijack
  app.kubernetes.io/instance: hijack
  k8s-app: hijack
falco:
  podLabels: *cdxLabels
cilium:
  commonLabels: *cdxLabels
"""

failures = []


def check(ok, label):
    print(("ok   - " if ok else "FAIL - ") + label)
    if not ok:
        failures.append(label)


def as_labels(mapping):
    return {k: str(v).lower() if isinstance(v, bool) else str(v) for k, v in mapping.items()}


def render(values_text=None):
    args = ["helm", "template", "cdx", CHART, *COVERAGE]
    with tempfile.NamedTemporaryFile("w", suffix=".yaml") as f:
        if values_text is not None:
            f.write(values_text)
            f.flush()
            args += ["-f", f.name]
        out = subprocess.run(args, capture_output=True, text=True)
    if out.returncode:
        sys.exit(f"helm template failed:\n{out.stderr}")
    return out.stdout


def documents(manifest):
    """(source file, object) for every rendered object, subcharts included."""
    for chunk in manifest.split("\n---\n"):
        source = next((l.split(": ", 1)[1] for l in chunk.splitlines()
                       if l.startswith("# Source: ")), "")
        obj = yaml.safe_load(chunk)
        if obj:
            yield source, obj


def inline_daemonset(job):
    """The cleanup DaemonSet cilium-cleanup-hook applies from a heredoc in its Job."""
    script = job["spec"]["template"]["spec"]["containers"][0]["command"][-1]
    body = script.split("kubectl apply -f -\n", 1)[1].split("\nDS\n", 1)[0]
    return yaml.safe_load(body)


def own_objects(manifest):
    """{(kind, name): (template file, object)} for objects this chart renders itself."""
    objs = {}
    for source, obj in documents(manifest):
        if not source.startswith(OWN_SOURCE):
            continue
        tpl = source[len(OWN_SOURCE):]
        objs[(obj["kind"], obj["metadata"]["name"])] = (tpl, obj)
        if tpl == "cilium-cleanup-hook.tpl" and obj["kind"] == "Job":
            ds = inline_daemonset(obj)
            objs[(ds["kind"], ds["metadata"]["name"])] = (tpl, ds)
    return objs


ABSENT = object()  # no `labels` key at all, as opposed to a rendered empty/null one


def labels_of(holder):
    return (holder.get("metadata") or {}).get("labels", ABSENT)


def label_sites(obj):
    """(where, labels or ABSENT, is_pod) for every labels map an object can carry."""
    yield "metadata", labels_of(obj), False
    spec = obj.get("spec") or {}
    if obj["kind"] == "CronJob":
        yield "jobTemplate", labels_of(spec["jobTemplate"]), False
        spec = spec["jobTemplate"]["spec"]
    if "template" in spec:
        yield "pod template", labels_of(spec["template"]), True


def selector(obj):
    spec = obj.get("spec") or {}
    if obj["kind"] == "Service":
        return spec.get("selector")
    return (spec.get("selector") or {}).get("matchLabels")


def check_custom_labels(plain, custom):
    common = as_labels(COMMON)
    for key, (tpl, obj) in sorted(custom.items()):
        name = f"{key[0]}/{key[1]}"
        base = {where: labels for where, labels, _ in label_sites(plain[key][1])}
        component = COMPONENTS.get(tpl)
        for where, labels, is_pod in label_sites(obj):
            own = {} if base.get(where) is ABSENT else base.get(where)
            pod = as_labels(CUSTOM[component]["podLabels"]) if is_pod and component else {}
            want = {**common, **pod, **own}
            check(labels == want, f"{name} {where} labels = custom + chart, chart wins")
        check(selector(obj) == selector(plain[key][1]), f"{name} selector unchanged")


def check_plain_render(plain):
    for key, (_, obj) in sorted(plain.items()):
        for where, labels, _ in label_sites(obj):
            clean = labels is ABSENT or (isinstance(labels, dict) and labels != {})
            check(clean, f"{key[0]}/{key[1]} {where} renders no empty labels without custom labels")


def check_subchart_recipe():
    want = {"team": "platform", "cost-center": "1234"}
    pods, selectors = {}, {}
    for source, obj in documents(render(SUBCHART_RECIPE)):
        parts = source.split("/")  # cloudanix/charts/<subchart>/templates/...
        if obj["kind"] == "DaemonSet" and parts[1:2] == ["charts"]:
            pods[parts[2]] = obj["spec"]["template"]["metadata"].get("labels", {})
            selectors[parts[2]] = obj["spec"]["selector"].get("matchLabels", {})
    for chart in ("falco", "cilium"):
        labels = pods.get(chart, {})
        check(want.items() <= labels.items(), f"README recipe labels the {chart} DaemonSet pods")
        # The README tells customers to keep chart-owned keys out of the shared map, even
        # when commonLabels carries them: the pod must still match its DaemonSet selector.
        check(bool(selectors.get(chart)) and selectors[chart].items() <= labels.items(),
              f"{chart} DaemonSet selector is a subset of its pod labels")


def main():
    plain = own_objects(render())
    custom = own_objects(render(yaml.safe_dump(CUSTOM)))
    check(plain.keys() == custom.keys(), "custom labels render the same set of objects")
    check(len(plain) > 50, f"coverage render includes every template ({len(plain)} objects)")
    check_custom_labels(plain, custom)
    check_plain_render(plain)
    check_subchart_recipe()
    print(f"\n{len(failures)} failure(s)")
    sys.exit(1 if failures else 0)


if __name__ == "__main__":
    main()
