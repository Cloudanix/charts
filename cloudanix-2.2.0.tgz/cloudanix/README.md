# Cloudanix Container Protection Helm Chart

This Helm chart installs Cloudanix services for container protection.

Always installed: `config-manager`, `inventory-collector`.

The rest are picked with the `capabilities` value: a comma-separated list
(default `threats,vulnerabilities,compliance`) or `all`. On the command line escape
the commas: `--set 'capabilities=threats\,compliance'`.

| Capability        | Services                                                                    |
| ----------------- | --------------------------------------------------------------------------- |
| `threats`         | threat-monitor + Falco (set `falco.enabled=false` when threats is not used) |
| `vulnerabilities` | vuln-scanner                                                                |
| `compliance`      | misconfig-scanner                                                           |
| `traffic`         | traffic-exporter + Cilium (`cilium.enabled=true`)                           |

## Custom labels

Add your own labels (cost allocation, ownership, admission policies) to everything this
chart installs:

```yaml
commonLabels:          # every object and every pod
  team: platform
  cost-center: "1234"

threatMonitor:
  podLabels:           # threat-monitor pods only; wins over commonLabels
    tier: runtime
```

`podLabels` exists on `configManager`, `inventoryCollector`, `threatMonitor`,
`misconfigScanner`, `vulnScanner` and `trafficExporter`.

- **Where they go.** `commonLabels` lands on every object the chart renders (Deployments,
  CronJobs and the Jobs they spawn, initial-run Jobs, ConfigMaps, Secrets, Services,
  ServiceAccounts, RBAC, the cache PVC) and on every pod, including the
  pre-delete hooks and the cleanup DaemonSet they start. The namespace itself is not
  labeled: the chart does not render a Namespace (`templates/namespace.tpl` is in
  `.helmignore`), so label a pre-created or `--create-namespace` namespace yourself
  (`kubectl label namespace cloudanix team=platform`).
- **Precedence.** Chart labels > `podLabels` > `commonLabels`. Where the chart sets a key
  itself (`app`, `component`, `app.kubernetes.io/*`), your value for
  that key is ignored on that object.
- **Safe to change on upgrade.** Custom labels never enter a selector, so you can add,
  change or remove them with any `helm upgrade`. A change to pod labels rolls the
  Deployments' pods, as any pod template change does.
- **Values are quoted for you**, so `cost-center: 1234` or `pci: true` work.
- **Don't add labels under `<component>.labels`.** Those are the chart's own labels and,
  for threat-monitor and inventory-collector, the Deployment selector. Changing them fails
  the upgrade with `field is immutable`.
- config-manager's hourly sync edits only resources, env and the runtime socket, so it
  leaves your labels in place.

### Falco and Cilium

Falco and Cilium are separate charts with their own keys, and Helm values cannot refer to
each other. Pass the same labels with a YAML anchor in your values file:

```yaml
cdxLabels: &cdxLabels         # unused key, only holds the anchor
  team: platform
  cost-center: "1234"
commonLabels: *cdxLabels
falco:
  podLabels: *cdxLabels       # Falco pods (the Falco chart has no all-objects key)
cilium:
  commonLabels: *cdxLabels    # every Cilium object and pod
```

Keep selector keys out of the shared map. Falco and Cilium print their own selector labels
and then yours, so a duplicate key wins and the pod no longer matches its DaemonSet
selector (the API rejects the upgrade). Never put `app.kubernetes.io/name`,
`app.kubernetes.io/instance` or `k8s-app` in `cdxLabels`. If you need one of them on this
chart's objects, add it to `commonLabels` only, via a merge key:

```yaml
commonLabels:
  <<: *cdxLabels
  k8s-app: my-value
```

Quote numbers and booleans here: these charts render values as given. Falco's chart only
offers pod labels, so its DaemonSet, ConfigMaps and RBAC objects don't carry them. With
`--set`, repeat each key:
`--set commonLabels.team=platform --set falco.podLabels.team=platform --set cilium.commonLabels.team=platform`.

## Falco and Cilium Charts

Falco and Cilium are community charts listed as dependencies in Chart.yaml. Helm installs them
based on `falco.enabled` / `cilium.enabled` only, so keep those in step with `capabilities`.

### Falco rules

What a release installs is written once, in `chart/rules/`:

- `upstream.yaml`: the Falco version and the upstream rules feeds (`falco-rules`,
  `falco-incubating-rules`, `falco-sandbox-rules`) pinned to exact versions. The follow sidecar
  is off, so rules change only with a chart upgrade.
- `cloudanix.yaml`: Cloudanix's own rules plus the exception that keeps our agents' expected
  Kubernetes API calls quiet. Rendered into the `cloudanix-falco-rules` ConfigMap and loaded
  from `/etc/falco/rules.d`. The Cloudanix console serves the same file, plus your threat
  exclusions, and config-manager writes it back into that ConfigMap every hour.

Only `falco-rules` (the stable feed) is loaded by default; the incubating and sandbox feeds are
installed and can be switched on with `falco.falco.rules_files` (see the note in
`values.yaml`).

**On upgrade**, Helm resets the ConfigMap to the chart's copy, which drops your exclusions until
config-manager runs again. `helm upgrade` therefore starts one config-manager run right away
(`Job/config-manager-upgrade-r<revision>`). GitOps tools render without that Job: run
`kubectl -n cloudanix create job --from=cronjob/config-manager sync-after-upgrade` after the
sync instead. The Falco DaemonSet rolls one node at a time; set
`falco.controller.daemonset.updateStrategy.rollingUpdate.maxUnavailable` for large clusters.

## Usage

Clone this repository and in `chart` folder, update the `yourValues.yaml` to override the values.
To install the chart, run

```bash
helm dependency update
helm install cloudanix -f yourValues.yaml .
```

To delete the chart, run

```bash
helm delete cloudanix
```
