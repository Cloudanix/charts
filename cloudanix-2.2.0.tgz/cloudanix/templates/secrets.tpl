apiVersion: v1
kind: Secret
metadata:
  name: cloudanix-secrets
  namespace: {{ .Release.Namespace }}
  {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
  labels:
    {{- . | nindent 4 }}
  {{- end }}
type: Opaque
data:
  auth-token: {{ .Values.authToken | default "DEFAULT" | b64enc }}
