{{/*
Expand the name of the chart.
*/}}
{{- define "cloudanix.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "cloudanix.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "cloudanix.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "cloudanix.labels" -}}
helm.sh/chart: {{ include "cloudanix.chart" . }}
{{ include "cloudanix.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "cloudanix.selectorLabels" -}}
app.kubernetes.io/name: {{ include "cloudanix.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Merge label maps into a YAML map body; on a shared key the later map wins.
Callers pass customer maps first and the chart's own labels last:
  object metadata: (list .Values.commonLabels <chart labels>)
  pod template:    (list .Values.commonLabels .Values.<component>.podLabels <chart labels>)
so podLabels beat commonLabels, and no customer key can change a label that a
selector or Service depends on. Values are stringified: the API rejects a
non-string label value, and `--set team=1234` or `enabled: true` arrive as a
number or bool. Renders nothing when every map is empty, so callers wrap it in
`with` and an install without custom labels renders exactly as before.
Never use it for spec.selector: selectors are immutable after install.
Usage:
  {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels .Values.threatMonitor.labels) }}
  labels:
    {{- . | nindent 4 }}
  {{- end }}
*/}}
{{- define "cloudanix.mergeLabels" -}}
{{- $merged := dict -}}
{{- range $labels := . -}}
{{- range $key, $value := $labels -}}
{{- $_ := set $merged $key (toString $value) -}}
{{- end -}}
{{- end -}}
{{- with $merged }}{{ toYaml . }}{{ end -}}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "cloudanix.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "cloudanix.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
========================================
CAPABILITIES LOGIC
========================================
Capabilities: comma-separated list of "threats", "vulnerabilities", "compliance", "traffic", or "all"
*/}}

{{/*
Check if a specific capability is enabled.
Usage: include "cloudanix.hasCapability" (dict "root" . "cap" "threats")
*/}}
{{- define "cloudanix.hasCapability" -}}
{{- $caps := .root.Values.capabilities | default "all" -}}
{{- if or (eq $caps "all") (has .cap (splitList "," ($caps | replace " " ""))) -}}
true
{{- else -}}
false
{{- end -}}
{{- end }}

{{/*
Check if runtime threat detection should be enabled
*/}}
{{- define "cloudanix.runtimeThreatEnabled" -}}
{{- include "cloudanix.hasCapability" (dict "root" . "cap" "threats") -}}
{{- end }}

{{/*
Check if network monitoring should be enabled
*/}}
{{- define "cloudanix.networkMonitoringEnabled" -}}
{{- include "cloudanix.hasCapability" (dict "root" . "cap" "traffic") -}}
{{- end }}

{{/*
Check if vulnerability scanning should be enabled
*/}}
{{- define "cloudanix.vulnScanningEnabled" -}}
{{- include "cloudanix.hasCapability" (dict "root" . "cap" "vulnerabilities") -}}
{{- end }}

{{/*
Resolve the vuln-scanner socket once for every resource. An explicit value
covers k3s, microk8s, and OpenShift. Otherwise OCI mounts CRI-O and every
other cloud mounts containerd.
*/}}
{{- define "cloudanix.vulnScannerRuntimeSocket" -}}
{{- $configured := .Values.vulnScanner.containerRuntimeSocket | default "" -}}
{{- if $configured -}}
{{- $configured -}}
{{- else if eq (upper (.Values.clusterDomain | default "")) "OCI" -}}
/run/crio/crio.sock
{{- else -}}
/run/containerd/containerd.sock
{{- end -}}
{{- end }}

{{/*
Check if compliance assessment (misconfig-scanner) should be enabled
*/}}
{{- define "cloudanix.complianceEnabled" -}}
{{- include "cloudanix.hasCapability" (dict "root" . "cap" "compliance") -}}
{{- end }}

{{/*
Check if Falco should be deployed (falco.enabled is a Helm dependency condition)
*/}}
{{- define "cloudanix.falcoEnabled" -}}
{{- if and .Values.falco.enabled (eq (include "cloudanix.runtimeThreatEnabled" .) "true") -}}
true
{{- else -}}
false
{{- end -}}
{{- end }}

{{/*
Check if Cilium should be deployed (cilium.enabled is a Helm dependency condition)
*/}}
{{- define "cloudanix.ciliumEnabled" -}}
{{- if and .Values.cilium.enabled (eq (include "cloudanix.networkMonitoringEnabled" .) "true") -}}
true
{{- else -}}
false
{{- end -}}
{{- end }}

{{/*
Check if Traffic Exporter should be deployed
*/}}
{{- define "cloudanix.trafficExporterEnabled" -}}
{{- include "cloudanix.hasCapability" (dict "root" . "cap" "traffic") -}}
{{- end }}

{{/*
Should a scanner's one-off initial-run Job be rendered? True only when
<scanner>.initialRun.enabled, an auth token is set (the scanner exits at once without
one) and the scanner's CronJob does not exist yet - i.e. a fresh install, or the
capability being switched on in an upgrade. Ordinary upgrades skip it.
lookup is empty under `helm template` / ArgoCD, so there the Job renders on every
sync: set <scanner>.initialRun.enabled=false for GitOps installs.
Usage: include "cloudanix.initialRunNeeded" (dict "root" . "scanner" .Values.vulnScanner)
*/}}
{{- define "cloudanix.initialRunNeeded" -}}
{{- $run := .scanner.initialRun | default dict -}}
{{- $token := .root.Values.authToken -}}
{{- if and $run.enabled $token (ne $token "DEFAULT") (not (lookup "batch/v1" "CronJob" "cloudanix" .scanner.name)) -}}
true
{{- else -}}
false
{{- end -}}
{{- end }}