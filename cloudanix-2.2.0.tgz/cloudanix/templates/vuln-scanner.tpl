{{- /* Pod template shared by the CronJob and the one-off initial-run Job below.
Takes (dict "root" $ "initialRun" bool). */}}
{{- define "cloudanix.vulnScanner.podTemplate" -}}
{{- $initialRun := .initialRun }}
{{- with .root -}}
{{- $runtimeSocket := include "cloudanix.vulnScannerRuntimeSocket" . }}
metadata:
    {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels .Values.vulnScanner.podLabels) }}
    labels:
        {{- . | nindent 8 }}
    {{- end }}
    annotations:
        cloudanix.com/container-runtime-socket: {{ $runtimeSocket | quote }}
spec:
    serviceAccountName: {{ .Values.vulnScanner.serviceAccount }}
    securityContext:
        runAsUser: 1001
        runAsGroup: 1001
        runAsNonRoot: true
        fsGroup: 1001
        supplementalGroups: [0]        # grants access to root:root 0660 socket
        seccompProfile:
            type: RuntimeDefault
    containers:
        - name: {{ .Values.vulnScanner.name }}
          image: {{ .Values.vulnScanner.image }}
          imagePullPolicy: IfNotPresent
          securityContext:
              allowPrivilegeEscalation: false
              readOnlyRootFilesystem: true
              capabilities:
                  drop: ["ALL"]
          resources:
              {{- toYaml (.Values.vulnScanner.resources | default dict) | nindent 14 }}
          env:
              # image-scanner defaults to /run/containerd/containerd.sock;
              # follow the mounted socket for k3s/microk8s/etc. paths.
              - name: CONTAINERD_ADDRESS
                value: {{ $runtimeSocket | quote }}
          volumeMounts:
              - name: config-volume
                mountPath: /etc/cdx/config
              - name: secret-volume
                mountPath: /etc/cdx/secrets
                readOnly: true
              - name: containerd-socket
                mountPath: {{ $runtimeSocket }}
                readOnly: true
              - name: tmp-dir
                mountPath: /tmp
              - name: cache-dir
                mountPath: /var/cache/vuln-scanner
    volumes:
        - name: config-volume
          configMap:
            name: {{ .Values.vulnScanner.configMapName }}
        - name: secret-volume
          secret:
              secretName: cloudanix-secrets
        - name: containerd-socket
          hostPath:
              path: {{ $runtimeSocket }}
              type: Socket
        - name: tmp-dir
          emptyDir: {}
        - name: cache-dir
          {{- /* The initial Job runs outside the CronJob's concurrencyPolicy Forbid, so it
          must not share the ReadWriteOnce PVC; that PVC is brand new and empty anyway. */}}
          {{- if and (.Values.vulnScanner.persistence | default dict).enabled (not $initialRun) }}
          persistentVolumeClaim:
              claimName: {{ .Values.vulnScanner.name }}-cache
          {{- else }}
          # Each run is a fresh pod, so the scan cache and vuln DB are rebuilt every run.
          emptyDir: {}
          {{- end }}
    restartPolicy: Never
{{- end }}
{{- end }}

{{- if eq (include "cloudanix.vulnScanningEnabled" .) "true" }}
{{- $cachePersistence := .Values.vulnScanner.persistence | default dict }}
{{- if .Capabilities.APIVersions.Has "batch/v1" }}
apiVersion: batch/v1
{{- else }}
apiVersion: batch/v1beta1
{{- end }}
kind: CronJob
metadata:
    name: {{ .Values.vulnScanner.name }}
    namespace: cloudanix
    {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels .Values.vulnScanner.labels) }}
    labels:
        {{- . | nindent 8 }}
    {{- end }}
spec:
    schedule: {{ .Values.vulnScanner.schedule | quote }}
    concurrencyPolicy: Forbid
    jobTemplate:
        {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
        metadata:
            labels:
                {{- . | nindent 16 }}
        {{- end }}
        spec:
            activeDeadlineSeconds: {{ .Values.vulnScanner.activeDeadlineSeconds | default 14400 }}
            template:
                {{- include "cloudanix.vulnScanner.podTemplate" (dict "root" . "initialRun" false) | nindent 16 }}

{{- if eq (include "cloudanix.initialRunNeeded" (dict "root" . "scanner" .Values.vulnScanner)) "true" }}
---
# One scan right after install so the first results don't wait for the weekly schedule.
# A plain Job, not a post-install hook: helm waits for hook Jobs to finish and a scan can
# take up to an hour. keep: the next upgrade drops this Job from the manifest (the CronJob
# now exists) and must not delete it mid-scan; ttlSecondsAfterFinished cleans it up.
apiVersion: batch/v1
kind: Job
metadata:
    name: {{ .Values.vulnScanner.name }}-initial-r{{ .Release.Revision }}
    namespace: cloudanix
    {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
    labels:
        {{- . | nindent 8 }}
    {{- end }}
    annotations:
        "helm.sh/resource-policy": keep
spec:
    backoffLimit: 0
    activeDeadlineSeconds: {{ .Values.vulnScanner.activeDeadlineSeconds | default 14400 }}
    ttlSecondsAfterFinished: {{ .Values.vulnScanner.initialRun.ttlSecondsAfterFinished | default 3600 }}
    template:
        {{- include "cloudanix.vulnScanner.podTemplate" (dict "root" . "initialRun" true) | nindent 8 }}
{{- end }}

{{- if $cachePersistence.enabled }}
---
# Keeps the scan cache and vuln DB across runs. ReadWriteOnce is enough:
# concurrencyPolicy Forbid means at most one CronJob pod mounts it, and the
# initial-run Job uses an emptyDir instead.
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
    name: {{ .Values.vulnScanner.name }}-cache
    namespace: cloudanix
    {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
    labels:
        {{- . | nindent 8 }}
    {{- end }}
spec:
    accessModes: ["ReadWriteOnce"]
    {{- with $cachePersistence.storageClass }}
    storageClassName: {{ . | quote }}
    {{- end }}
    resources:
        requests:
            storage: {{ $cachePersistence.size | default "5Gi" }}
{{- end }}

---
apiVersion: v1
kind: ConfigMap
metadata:
    name: {{ .Values.vulnScanner.configMapName }}
    namespace: cloudanix
    {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
    labels:
        {{- . | nindent 8 }}
    {{- end }}
data:
    config.yaml: |
        chartVersion:  {{ .Chart.Version }}
        releaseName: {{ .Release.Name }}
        common:
          listenerUrl: {{ required "A valid URL is required!" .Values.vulnScanner.listenerUrl }}
          requestTimeout: {{ .Values.requestTimeout | default 30 }}
          httpMaxRetries: {{ .Values.httpMaxRetries | default 3 }}
          logLevel: {{ .Values.logLevel | default "warn" }}
          accountId: {{ required "Account ID is required!" .Values.accountId }}
          clusterIdentifier: {{ required "Cluster Identifier is required!" .Values.clusterIdentifier }}
          {{- if and (.Values.clusterName) (ne .Values.clusterName "DEFAULT") }}
          clusterName:  {{ .Values.clusterName }}
          {{- else if (.Values.clusterIdentifier) }}
          clusterName: {{ required "Cluster Name is required!" (splitList "/" .Values.clusterIdentifier) | last }}
          {{- end }}
          clusterDomain: {{ required "Cluster Domain is required!" .Values.clusterDomain }}
        vulnScanner:
          templateType: {{ required "vulnScanner.templateType is required!" .Values.vulnScanner.templateType }}
          containerRuntimeSocket: {{ include "cloudanix.vulnScannerRuntimeSocket" . }}
          {{- if and (.Values.authToken) (ne .Values.authToken "DEFAULT" ) }}
          enabled: true
          {{- end }}
          scanTimeout: {{ required "Scan Timeout is required!" .Values.vulnScanner.scanTimeout }}
          concurrency: {{ required "Concurrency is required!" .Values.vulnScanner.concurrency }}
          ignoreUnfixed: {{ required "Ignore Unfixed is required!" .Values.vulnScanner.ignoreUnfixed }}
          cacheDir: /var/cache/vuln-scanner
          cacheTTLInHours: {{ .Values.vulnScanner.cacheTTLInHours | default 720 }}

---
apiVersion: v1
kind: ServiceAccount
metadata:
    name: {{ .Values.vulnScanner.serviceAccount }}
    namespace: cloudanix
    {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
    labels:
        {{- . | nindent 8 }}
    {{- end }}

---
kind: ClusterRole
apiVersion: rbac.authorization.k8s.io/v1
metadata:
    name: {{ .Values.vulnScanner.clusterRole }}
    {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
    labels:
        {{- . | nindent 8 }}
    {{- end }}
rules:
    - apiGroups: [""]
      resources: ["pods"]
      verbs: ["get", "list"]
    - apiGroups: ["batch"]
      resources: ["cronjobs", "jobs"]
      verbs: ["list"]
    - apiGroups: ["apps"]
      resources: ["deployments", "statefulsets", "daemonsets", "replicasets"]
      verbs: ["list"]

---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
    name: {{ .Values.vulnScanner.serviceAccount }}
    {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
    labels:
        {{- . | nindent 8 }}
    {{- end }}
subjects:
    - kind: ServiceAccount
      name: {{ .Values.vulnScanner.serviceAccount }}
      namespace: cloudanix
roleRef:
    kind: ClusterRole
    name: {{ .Values.vulnScanner.clusterRole }}
    apiGroup: rbac.authorization.k8s.io

{{- end }}
