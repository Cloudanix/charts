{{- if .Values.falco.enabled }}
# Falco loads this after the upstream feed (falco.falco.rules_files ends with /etc/falco/rules.d,
# which falco.mounts in values.yaml takes from this ConfigMap). Source: rules/cloudanix.yaml, one
# file for chart, console and clusters (docs/falco-rules.md). Fixed name: the subchart mounts it
# from values, which Helm cannot template.
#
# The chart only seeds the key. config-manager rewrites it every hour with the console's copy of
# the same file plus the workspace's threat exclusions, and `helm upgrade` resets it to the seed,
# so an upgrade loses the exclusions until config-manager runs again: config-manager.tpl renders
# a one-off Job on upgrade for that. Falco picks up every rewrite itself (watch_config_files).
apiVersion: v1
kind: ConfigMap
metadata:
  name: cloudanix-falco-rules
  namespace: {{ .Release.Namespace }}
  {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
  labels:
    {{- . | nindent 4 }}
  {{- end }}
data:
  cloudanix.yaml: |-
{{ .Files.Get "rules/cloudanix.yaml" | indent 4 }}
{{- end }}
