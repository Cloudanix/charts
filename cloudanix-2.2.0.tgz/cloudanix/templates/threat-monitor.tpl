{{- if eq (include "cloudanix.runtimeThreatEnabled" .) "true" }}
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ .Values.threatMonitor.name }}
  namespace: cloudanix
  {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels .Values.threatMonitor.labels) }}
  labels:
    {{- . | nindent 4 }}
  {{- end }}
spec:
  replicas: {{ .Values.threatMonitor.replicaCount }}
  selector:
    matchLabels:
      {{- with .Values.threatMonitor.labels }}
      {{ toYaml . }}
      {{- end }}
  template:
    metadata:
      {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels .Values.threatMonitor.podLabels .Values.threatMonitor.labels) }}
      labels:
        {{- . | nindent 8 }}
      {{- end }}
    spec:
      {{- if hasKey .Values "dnsPolicy" }}
      dnsPolicy: {{ .Values.dnsPolicy }}
      {{- end }}
      {{- with .Values.dnsConfig }}
      dnsConfig:
        {{- toYaml . }}
      {{- end }}
      serviceAccountName: {{ .Values.threatMonitor.serviceAccount }}
      automountServiceAccountToken: true
      # uid/gid 1001 = the image's `cdx` user.
      securityContext:
        runAsUser: 1001
        runAsGroup: 1001
        runAsNonRoot: true
        seccompProfile:
          type: RuntimeDefault
      containers:
      - name: {{ .Values.threatMonitor.name }}
        image: {{ .Values.threatMonitor.image }}
        imagePullPolicy: IfNotPresent
        securityContext:
          allowPrivilegeEscalation: false
          readOnlyRootFilesystem: true
          capabilities:
            drop: ["ALL"]
        ports:
        - containerPort: 8080
        volumeMounts:
        - name: config-volume
          mountPath: /etc/cdx/config
          readOnly: true
        - name: cloudanix-secrets-volume
          mountPath: /etc/cdx/secrets
          readOnly: true
        resources:
          {{- toYaml (.Values.threatMonitor.resources | default dict) | nindent 10 }}
      volumes:
        - name: config-volume
          configMap:
            name: {{ .Values.threatMonitor.configMapName }}
        - name: cloudanix-secrets-volume
          secret:
            secretName: cloudanix-secrets

---

apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ .Values.threatMonitor.configMapName }}
  namespace: cloudanix
  {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
  labels:
    {{- . | nindent 4 }}
  {{- end }}
data:
  config.yaml: |
    chartVersion:  {{ .Chart.Version }}
    releaseName: {{ .Release.Name }}
    common:
      listenerUrl: {{ required "A valid URL is required!" .Values.threatMonitor.listenerUrl }}
      requestTimeout: {{ .Values.requestTimeout | default 30 }}
      httpMaxRetries: {{ .Values.httpMaxRetries | default 3 }}
      bufferSize:  {{ .Values.threatMonitor.bufferSize }}
      bufferDuration:  {{ .Values.threatMonitor.bufferDuration }}
      ignoreDuplicates:  {{ .Values.threatMonitor.ignoreDuplicates }}
      logLevel: {{ .Values.logLevel | default "warn" }}
      accountId: {{ required "Account Id is required!" .Values.accountId }}
      clusterIdentifier: {{ required "Cluster Identifier is required!" .Values.clusterIdentifier }}
      {{- if and (.Values.clusterName) (ne .Values.clusterName "DEFAULT") }}
      clusterName:  {{ .Values.clusterName }}
      {{- else if (.Values.clusterIdentifier) }}
      clusterName: {{ required "Cluster Name is required!" (splitList "/" .Values.clusterIdentifier) | last }}
      {{- end }}
      clusterDomain: {{ required "Cluster Domain is required!" .Values.clusterDomain }}
    threatMonitor:
      templateType: {{ required "threatMonitor.templateType is required!" .Values.threatMonitor.templateType }}
      {{- if and (.Values.authToken) (ne .Values.authToken "DEFAULT") }}
      enabled: true
      {{- end }}

---

apiVersion: v1
kind: ServiceAccount
metadata:
  name: {{ .Values.threatMonitor.serviceAccount }}
  namespace: cloudanix
  {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
  labels:
    {{- . | nindent 4 }}
  {{- end }}

---

apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: {{ .Values.threatMonitor.clusterRole }}
  namespace: cloudanix
  {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
  labels:
    {{- . | nindent 4 }}
  {{- end }}
rules:
  - apiGroups: [""]
    resources: ["pods"]
    verbs: ["get", "list", "watch"]

---

apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: {{ .Values.threatMonitor.name }}
  namespace: cloudanix
  {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
  labels:
    {{- . | nindent 4 }}
  {{- end }}
subjects:
  - kind: ServiceAccount
    name: {{ .Values.threatMonitor.serviceAccount }}
    namespace: cloudanix
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: {{ .Values.threatMonitor.clusterRole }}

---

apiVersion: v1
kind: Service
metadata:
  name: {{ .Values.threatMonitor.name }}
  namespace: cloudanix
  {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels .Values.threatMonitor.labels) }}
  labels:
    {{- . | nindent 4 }}
  {{- end }}
spec:
  ports:
  - port: 8080
    protocol: TCP
  selector:
    app: threat-monitor
{{- end }}
