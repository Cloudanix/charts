{{- /*
Tells the platform the chart is being removed, so the console can show the cluster as
uninstalled instead of waiting for it to go silent. Rides config-manager's sync-status
report (same URL, auth and cdx-template-type), flagged with "event": "UNINSTALL";
the backend passes it through untouched and cloudanix-web's install_health acts on it.

Best effort by design: a failed pre-delete hook aborts `helm uninstall`, so the script
always exits 0. Missed notices (--no-hooks, bare namespace delete, blocked egress) fall
back to the console's read-time DISCONNECTED status once agents stop reporting.
exit 0 only covers a failed POST: if the pod never runs (image pull fails, unschedulable,
activeDeadlineSeconds hit) the Job fails and Helm aborts the uninstall, with no
continue-on-failure option. Retry with `helm uninstall --no-hooks`.

Reuses the config-manager image (alpine, busybox wget) so customers mirroring images
have nothing new to pull. Gated on the same statusReporting toggle as the hourly report.
*/}}
{{- if and .Values.configManager.statusReporting.enabled .Values.authToken (ne .Values.authToken "DEFAULT") }}
{{- $clusterName := .Values.clusterName }}
{{- if or (not $clusterName) (eq $clusterName "DEFAULT") }}
{{- $clusterName = splitList "/" .Values.clusterIdentifier | last }}
{{- end }}
apiVersion: batch/v1
kind: Job
metadata:
  name: cloudanix-uninstall-notify
  namespace: {{ .Release.Namespace }}
  annotations:
    "helm.sh/hook": pre-delete
    # Before any other pre-delete hook, while cloudanix-secrets still exists.
    "helm.sh/hook-weight": "-20"
    "helm.sh/hook-delete-policy": before-hook-creation,hook-succeeded,hook-failed
spec:
  backoffLimit: 0
  activeDeadlineSeconds: 120
  ttlSecondsAfterFinished: 60
  template:
    spec:
      restartPolicy: Never
      automountServiceAccountToken: false
      securityContext:
        runAsUser: 1001
        runAsGroup: 1001
        runAsNonRoot: true
        seccompProfile:
          type: RuntimeDefault
      containers:
        - name: notify
          image: {{ .Values.configManager.image }}
          imagePullPolicy: IfNotPresent
          securityContext:
            allowPrivilegeEscalation: false
            readOnlyRootFilesystem: true
            capabilities:
              drop: ["ALL"]
          env:
            - name: AUTH_TOKEN
              valueFrom:
                secretKeyRef:
                  name: cloudanix-secrets
                  key: auth-token
            - name: URL
              value: {{ required "A valid URL is required!" .Values.configManager.configURL | quote }}
            - name: ACCOUNT_ID
              value: {{ .Values.accountId | quote }}
            - name: CLUSTER_IDENTIFIER
              value: {{ .Values.clusterIdentifier | quote }}
            - name: CLUSTER_NAME
              value: {{ $clusterName | quote }}
            - name: CLUSTER_DOMAIN
              value: {{ .Values.clusterDomain | quote }}
            - name: CHART_VERSION
              value: {{ .Chart.Version | quote }}
            # services: [] keeps consoles that predate the event field from erroring on the report.
            - name: BODY
              value: {{ dict "event" "UNINSTALL" "status" "SUCCESS" "accountId" .Values.accountId "clusterIdentifier" .Values.clusterIdentifier "chartVersion" .Chart.Version "services" list | toJson | quote }}
          command: ["sh", "-c"]
          args:
            - |
              wget -q -O- -T 10 \
                --header "Content-Type: application/json" \
                --header "Authorization: Bearer $AUTH_TOKEN" \
                --header "cdx-session-id: uninstall-$HOSTNAME" \
                --header "cdx-chart-version: $CHART_VERSION" \
                --header "cdx-account-id: $ACCOUNT_ID" \
                --header "cdx-cluster-identifier: $CLUSTER_IDENTIFIER" \
                --header "cdx-cluster-name: $CLUSTER_NAME" \
                --header "cdx-cluster-domain: $CLUSTER_DOMAIN" \
                --header "cdx-template-type: KUBERNETESCONFIGSYNCSTATUS" \
                --post-data "$BODY" "$URL" \
                && echo "uninstall notice sent" \
                || echo "uninstall notice not sent; continuing uninstall"
              exit 0
          resources:
            requests:
              memory: "16Mi"
              cpu: "10m"
            limits:
              memory: "64Mi"
              cpu: "100m"
{{- end }}
