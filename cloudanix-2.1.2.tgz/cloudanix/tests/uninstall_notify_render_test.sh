#!/usr/bin/env bash
# Render assertions for the pre-delete uninstall notice (templates/uninstall-notify-hook.tpl).
# Requires helm and the subcharts (helm dependency build chart).
# Run: chart/tests/uninstall_notify_render_test.sh
set -euo pipefail

cd "$(dirname "$0")/../.."
CHART=chart
COMMON=(--set accountId=a --set clusterIdentifier=arn:aws:eks:us-east-1:1:cluster/prod --set clusterDomain=AWS)
fail=0

hook() {
  helm template cdx "$CHART" -n cloudanix "${COMMON[@]}" "$@" --show-only templates/uninstall-notify-hook.tpl 2>/dev/null || true
}

check() { # <label> <command...>
  local label=$1; shift
  if "$@"; then echo "ok   - $label"; else echo "FAIL - $label"; fail=1; fi
}

on=$(hook --set authToken=t)
check "renders a pre-delete hook" grep -q '"helm.sh/hook": pre-delete' <<<"$on"
check "tags the report as an uninstall" grep -qF '\"event\":\"UNINSTALL\"' <<<"$on"
check "rides the sync-status template" grep -q 'cdx-template-type: KUBERNETESCONFIGSYNCSTATUS' <<<"$on"
name=$(grep -A1 'name: CLUSTER_NAME' <<<"$on" | tail -1)
check "falls back to the identifier's last segment for the cluster name" grep -q '"prod"' <<<"$name"
# A failed pre-delete hook aborts helm uninstall, so the script must never exit non-zero.
check "never fails the uninstall" grep -q 'exit 0' <<<"$on"

check "skipped without a real authToken" test -z "$(hook)"
check "skipped when status reporting is off" test -z "$(hook --set authToken=t --set configManager.statusReporting.enabled=false)"

exit $fail
