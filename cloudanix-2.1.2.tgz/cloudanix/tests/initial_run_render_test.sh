#!/usr/bin/env bash
# Render assertions for the scanners' one-off initial-run Jobs (cloudanix.initialRunNeeded).
# Requires helm. Run: chart/tests/initial_run_render_test.sh
# Note: helm template has no cluster, so lookup() finds no CronJob and the Job always
# renders here; the "CronJob already exists" branch only exists on a live install/upgrade.
set -euo pipefail

cd "$(dirname "$0")/../.."
CHART=chart
COMMON=(-f chart/local-values.yaml --set accountId=a --set clusterIdentifier=c --set clusterDomain=OCI)
fail=0

render() { helm template cdx "$CHART" "${COMMON[@]}" "$@" 2>&1; }
# "Kind/name" for every Job and CronJob in the render.
batch() { render "$@" | awk '/^kind: /{k=$2} /^metadata:/{m=1; next} m && /^ +name: /{print k "/" $2; m=0}' | grep -E '^(Job|CronJob)/' || true; }

assert_has() { # <haystack> <needle> <label>
  if grep -qxF -- "$2" <<<"$1"; then echo "ok   - $3"; else echo "FAIL - $3"; fail=1; fi
}
assert_missing() {
  if grep -qxF -- "$2" <<<"$1"; then echo "FAIL - $3"; fail=1; else echo "ok   - $3"; fi
}
assert_contains() { # substring match on a rendered manifest
  if grep -qF -- "$2" <<<"$1"; then echo "ok   - $3"; else echo "FAIL - $3"; fail=1; fi
}

on=$(batch --set authToken=t)
assert_has "$on" "Job/vuln-scanner-initial-r1" "vuln-scanner initial Job rendered on install"
assert_has "$on" "Job/misconfig-scanner-initial-r1" "misconfig-scanner initial Job rendered on install"
assert_has "$on" "CronJob/vuln-scanner" "vuln-scanner CronJob still rendered"
assert_has "$on" "CronJob/misconfig-scanner" "misconfig-scanner CronJob still rendered"

# Without a token the scanner exits immediately (config has no enabled: true), so a Job is noise.
notoken=$(batch)
assert_missing "$notoken" "Job/vuln-scanner-initial-r1" "no vuln initial Job without authToken"
assert_missing "$notoken" "Job/misconfig-scanner-initial-r1" "no misconfig initial Job without authToken"

off=$(batch --set authToken=t --set vulnScanner.initialRun.enabled=false --set misconfigScanner.initialRun.enabled=false)
assert_missing "$off" "Job/vuln-scanner-initial-r1" "initialRun.enabled=false skips vuln Job"
assert_missing "$off" "Job/misconfig-scanner-initial-r1" "initialRun.enabled=false skips misconfig Job"

# The capability gate still wins: no scanner, no Job.
compliance_only=$(batch --set authToken=t --set capabilities=compliance)
assert_missing "$compliance_only" "Job/vuln-scanner-initial-r1" "no vuln Job when vulnerabilities is off"
assert_has "$compliance_only" "Job/misconfig-scanner-initial-r1" "misconfig Job with compliance only"

# Not a hook (a hook blocks helm install for the whole scan) and kept across the upgrade
# that drops it from the manifest.
job=$(render --set authToken=t -s templates/vuln-scanner.tpl)
assert_contains "$job" '"helm.sh/resource-policy": keep' "initial Job is resource-policy keep"
if grep -qF 'helm.sh/hook' <<<"$job"; then echo "FAIL - initial Job must not be a helm hook"; fail=1; else echo "ok   - initial Job is not a helm hook"; fi
assert_contains "$job" "ttlSecondsAfterFinished: 3600" "initial Job self-cleans"

# The initial Job runs outside the CronJob's concurrencyPolicy Forbid, so it must not
# mount the ReadWriteOnce cache PVC; the CronJob still does.
persist=$(render --set authToken=t --set vulnScanner.persistence.enabled=true -s templates/vuln-scanner.tpl)
claims=$(awk '/^kind: /{k=$2} /claimName: /{print k "/" $2}' <<<"$persist")
assert_has "$claims" "CronJob/vuln-scanner-cache" "CronJob mounts the cache PVC"
assert_missing "$claims" "Job/vuln-scanner-cache" "initial Job does not mount the cache PVC"

exit $fail
