{{/*
Expand the name of the chart.
*/}}
{{- define "cloudanix.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "cloudanix.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "cloudanix.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "cloudanix.labels" -}}
helm.sh/chart: {{ include "cloudanix.chart" . }}
{{ include "cloudanix.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "cloudanix.selectorLabels" -}}
app.kubernetes.io/name: {{ include "cloudanix.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "cloudanix.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "cloudanix.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
========================================
CAPABILITIES LOGIC
========================================
Capabilities: comma-separated list of "threats", "vulnerabilities", "traffic", or "all"
*/}}

{{/*
Check if a specific capability is enabled.
Usage: include "cloudanix.hasCapability" (dict "root" . "cap" "threats")
*/}}
{{- define "cloudanix.hasCapability" -}}
{{- $caps := .root.Values.capabilities | default "all" -}}
{{- if or (eq $caps "all") (has .cap (splitList "," ($caps | replace " " ""))) -}}
true
{{- else -}}
false
{{- end -}}
{{- end }}

{{/*
Check if runtime threat detection should be enabled
*/}}
{{- define "cloudanix.runtimeThreatEnabled" -}}
{{- include "cloudanix.hasCapability" (dict "root" . "cap" "threats") -}}
{{- end }}

{{/*
Check if network monitoring should be enabled
*/}}
{{- define "cloudanix.networkMonitoringEnabled" -}}
{{- include "cloudanix.hasCapability" (dict "root" . "cap" "traffic") -}}
{{- end }}

{{/*
Check if vulnerability scanning should be enabled
*/}}
{{- define "cloudanix.vulnScanningEnabled" -}}
{{- include "cloudanix.hasCapability" (dict "root" . "cap" "vulnerabilities") -}}
{{- end }}

{{/*
Check if Falco should be deployed (falco.enabled is a Helm dependency condition)
*/}}
{{- define "cloudanix.falcoEnabled" -}}
{{- if and .Values.falco.enabled (eq (include "cloudanix.runtimeThreatEnabled" .) "true") -}}
true
{{- else -}}
false
{{- end -}}
{{- end }}

{{/*
Check if Cilium should be deployed (cilium.enabled is a Helm dependency condition)
*/}}
{{- define "cloudanix.ciliumEnabled" -}}
{{- if and .Values.cilium.enabled (eq (include "cloudanix.networkMonitoringEnabled" .) "true") -}}
true
{{- else -}}
false
{{- end -}}
{{- end }}

{{/*
Check if Traffic Exporter should be deployed
*/}}
{{- define "cloudanix.trafficExporterEnabled" -}}
{{- include "cloudanix.hasCapability" (dict "root" . "cap" "traffic") -}}
{{- end }}