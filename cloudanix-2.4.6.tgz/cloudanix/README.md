# Cloudanix Container Protection Helm Chart

This Helm chart installs Cloudanix services for container protection.

Always installed: `config-manager`, `inventory-collector`.

The rest are picked with the `capabilities` value: a comma-separated list
(default `threats,vulnerabilities,compliance`) or `all`. On the command line escape
the commas: `--set 'capabilities=threats\,compliance'`.

| Capability        | Services                                                                    |
| ----------------- | --------------------------------------------------------------------------- |
| `threats`         | threat-monitor + Falco (set `falco.enabled=false` when threats is not used) |
| `vulnerabilities` | vuln-scanner                                                                |
| `compliance`      | misconfig-scanner                                                           |
| `traffic`         | traffic-exporter + Cilium (`cilium.enabled=true`; OKE: `ciliumOke.enabled=true`) |

## Your values file

The Cloudanix console generates one values file per cluster (`cloudanix-values-<cluster>.yaml`)
and an install command that passes only that file. It is the same on every cloud, OKE included:

```sh
helm repo add cloudanix https://cloudanix.github.io/charts/
helm repo update
helm upgrade --install cloudanix cloudanix/cloudanix \
  --namespace cloudanix --create-namespace --version <v> \
  -f cloudanix-values-<cluster>.yaml
```

The file has two parts:

- **Set by Cloudanix**: the auth token, account and cluster ids, `clusterDomain`, the
  capabilities picked in the console, sensor sizing and, for a private registry, the trusted
  repository and sensor images. Change these in the console, not in the file: config-manager
  keeps images, resources, schedules and log level in step with the console on every sync.
- **Your settings**: commented examples for `authTokenSecret`, `commonLabels`, `scheduling` and
  `trustedImageRepositories`. Uncomment what you need. For any other key, copy it from the full
  `values.yaml` of your chart version (linked in the file's header, or
  `helm show values cloudanix/cloudanix --version <v>`).

Keep the file: pass it again on every upgrade. Outside the console, keep your settings in a
file that holds **only what you change**, starting from
[`cloudanix-values.yaml`](cloudanix-values.yaml): every example in it is commented out, so it
changes nothing until you uncomment a line. Pass it last, so it wins over any file Cloudanix
gives you:

```sh
helm upgrade --install cloudanix ... -f cloudanix-values.yaml cloudanix/cloudanix --version <v>
```

OKE needs no extra file from chart 2.4.6: the vuln-scanner socket follows `clusterDomain: OCI`
(CRI-O), and traffic monitoring uses the chart's OKE Cilium profile, `ciliumOke.enabled: true`
(Flannel chaining). Charts up to 2.4.4 shipped `values-oke.yaml` for this; passing it to a
newer chart still installs, it just has no effect.

- Do not copy the chart's full `values.yaml`. A copy freezes that version's defaults, image
  tags included, and overrides the next version's. `helm show values cloudanix/cloudanix
  --version <v>` lists every default with its comment.
- Avoid `--reuse-values` on upgrade: it carries the old release's values, defaults included,
  into the new chart. Pass your file again instead.
- Lists (`scheduling.tolerations`, `imagePullSecrets`, ...) replace the chart's list; they are
  not appended to it.

The chart checks the merged values against [`values.schema.json`](values.schema.json) before it
renders anything. A misspelled or misplaced key (`tolerations` at the top level instead of
under `scheduling`, `threatMonitor.podAnotations`), a value of the wrong type or an unknown
capability fails the install with its path instead of being silently ignored. Keys an older
chart had and this one dropped are still accepted and ignored, so a file kept from an earlier
release keeps working. Falco and Cilium are separate charts: only their top-level `falco:`,
`cilium:` and `ciliumOke:` blocks are checked here.

## Custom labels

Add your own labels (cost allocation, ownership, admission policies) to everything this
chart installs:

```yaml
commonLabels:          # every object and every pod
  team: platform
  cost-center: "1234"

threatMonitor:
  podLabels:           # threat-monitor pods only; wins over commonLabels
    tier: runtime
```

`podLabels` exists on `configManager`, `inventoryCollector`, `threatMonitor`,
`misconfigScanner`, `vulnScanner` and `trafficExporter`.

- **Where they go.** `commonLabels` lands on every object the chart renders (Deployments,
  CronJobs and the Jobs they spawn, initial-run Jobs, ConfigMaps, Secrets, Services,
  ServiceAccounts, RBAC, the cache PVC) and on every pod, including the
  pre-delete hooks and the cleanup DaemonSet they start. The namespace itself is not
  labeled: the chart does not render a Namespace (`templates/namespace.tpl` is in
  `.helmignore`), so label a pre-created or `--create-namespace` namespace yourself
  (`kubectl label namespace cloudanix team=platform`).
- **Precedence.** Chart labels > `podLabels` > `commonLabels`. Where the chart sets a key
  itself (`app`, `component`, `app.kubernetes.io/*`), your value for
  that key is ignored on that object.
- **Safe to change on upgrade.** Custom labels never enter a selector, so you can add,
  change or remove them with any `helm upgrade`. A change to pod labels rolls the
  Deployments' pods, as any pod template change does.
- **Values are quoted for you**, so `cost-center: 1234` or `pci: true` work.
- **Don't add labels under `<component>.labels`.** Those are the chart's own labels and,
  for threat-monitor and inventory-collector, the Deployment selector. Changing them fails
  the upgrade with `field is immutable`.
- config-manager's hourly sync edits only resources, env and the runtime socket, so it
  leaves your labels in place.

### Falco and Cilium

Falco and Cilium are separate charts with their own keys, and Helm values cannot refer to
each other. Pass the same labels with a YAML anchor in your values file:

```yaml
cdxLabels: &cdxLabels         # unused key, only holds the anchor
  team: platform
  cost-center: "1234"
commonLabels: *cdxLabels
falco:
  podLabels: *cdxLabels       # Falco pods (the Falco chart has no all-objects key)
cilium:
  commonLabels: *cdxLabels    # every Cilium object and pod (OKE: put it under ciliumOke)
```

Keep selector keys out of the shared map. Falco and Cilium print their own selector labels
and then yours, so a duplicate key wins and the pod no longer matches its DaemonSet
selector (the API rejects the upgrade). Never put `app.kubernetes.io/name`,
`app.kubernetes.io/instance` or `k8s-app` in `cdxLabels`. If you need one of them on this
chart's objects, add it to `commonLabels` only, via a merge key:

```yaml
commonLabels:
  <<: *cdxLabels
  k8s-app: my-value
```

Quote numbers and booleans here: these charts render values as given. Falco's chart only
offers pod labels, so its DaemonSet, ConfigMaps and RBAC objects don't carry them. With
`--set`, repeat each key:
`--set commonLabels.team=platform --set falco.podLabels.team=platform --set cilium.commonLabels.team=platform`.

## Placement and pod annotations

One `scheduling` block places every Cloudanix pod: config-manager, inventory-collector,
threat-monitor, misconfig-scanner, vuln-scanner, traffic-exporter, the scanners' one-off Jobs,
and the hook pods (auth precheck, uninstall notice, Cilium cleanup). Empty values render
nothing.

```yaml
scheduling:
  nodeSelector:
    karpenter.sh/nodepool: agents
  tolerations:
    - {key: dedicated, operator: Equal, value: cloudanix, effect: NoSchedule}
  affinity: {}                          # any pod affinity / node affinity
  priorityClassName: cloudanix-agents   # the PriorityClass must already exist
  podAnnotations:                       # every Cloudanix pod
    sidecar.istio.io/inject: "false"

vulnScanner:
  podAnnotations:                       # vuln-scanner pods only; wins over scheduling.podAnnotations
    karpenter.sh/do-not-disrupt: "true"
```

`podAnnotations` exists on `configManager`, `inventoryCollector`, `threatMonitor`,
`misconfigScanner`, `vulnScanner` and `trafficExporter`.

- **Precedence.** `<component>.podAnnotations` > `scheduling.podAnnotations` > annotations the
  chart sets (vuln-scanner's `cloudanix.com/container-runtime-socket`).
- **Job-only annotations go per component.** `karpenter.sh/do-not-disrupt` keeps a scan from
  being interrupted; on threat-monitor or inventory-collector it would stop the node they run
  on from ever being consolidated. Put it on `configManager`, `misconfigScanner` and
  `vulnScanner`.
- **Service meshes.** A sidecar that never exits keeps a Job from completing, and a hook that
  never completes blocks `helm install` / `helm uninstall`. If your mesh injects into the
  `cloudanix` namespace, set `scheduling.podAnnotations` to opt the pods out
  (`sidecar.istio.io/inject: "false"`, `linkerd.io/inject: disabled`).
- **Cilium cleanup hook** (`cilium.enabled` or `ciliumOke.enabled` only): its Job takes `nodeSelector`, `affinity`
  and `priorityClassName` but keeps its own tolerate-every-taint toleration; the DaemonSet it
  starts has no placement, because it must remove Cilium's CNI config from every node.
- **DNS.** `dnsPolicy` and `dnsConfig` apply to every Cloudanix pod except the hostNetwork
  Cilium cleanup pods.
- A change to pod annotations rolls the Deployments' pods, as a pod label change does.
  config-manager's hourly sync leaves placement and annotations in place.

### Falco and Cilium placement

Falco and Cilium are separate charts and do not read `scheduling`. Falco tolerates only the
control-plane taints by default, so **Falco does not run on a node with any other taint, and
that node has no runtime threat detection**. That is your call to make: to cover tainted
nodes, set Falco's own keys.

```yaml
falco:
  tolerations:                  # replaces the Falco chart's default list; keep control-plane if you need it
    - {key: dedicated, operator: Equal, value: cloudanix, effect: NoSchedule}
    - {key: node-role.kubernetes.io/control-plane, effect: NoSchedule}
  podPriorityClassName: cloudanix-agents   # note the key name
  podAnnotations:
    sidecar.istio.io/inject: "false"
  # nodeSelector / affinity exist too; Falco only protects the nodes it runs on.
```

To run Falco on every node whatever its taints: `tolerations: [{operator: Exists}]`. Cilium's
agent tolerates every taint by default; see the Cilium chart for `cilium.tolerations`,
`cilium.nodeSelector` and `cilium.priorityClassName` (on OKE the same keys under `ciliumOke`).

## Private registry and pull secrets

All images are public: Cloudanix images on Docker Hub (`docker.io/cloudanix/*`), Falco on
Docker Hub, Cilium on quay.io. You need pull secrets when you mirror images into a private
registry, or to make authenticated Docker Hub pulls (anonymous pulls are rate-limited per
source IP, which a large cluster behind one NAT address can hit).

```yaml
imagePullSecrets:               # every Cloudanix pod and hook; Secret must exist in the release namespace
  - name: regcred
configManager:
  image: registry.example.com/cloudanix/config-manager:v2.3.7   # the hooks use this image too
# ...the same for inventoryCollector, threatMonitor, misconfigScanner, vulnScanner, trafficExporter
ciliumCleanup:                  # cilium.enabled or ciliumOke.enabled only
  kubectlImage: registry.example.com/bitnami/kubectl:latest
  busyboxImage: registry.example.com/library/busybox:latest
falco:
  imagePullSecrets: [{name: regcred}]
cilium:
  imagePullSecrets: [{name: regcred}]
```

Mirror Falco's `falcoctl` image as well, and set the Falco and Cilium image repositories in
their own chart values.

### Keep the sensors on your registry

config-manager keeps the sensor images in line with the Cloudanix console, and only rolls to
`docker.io/cloudanix/` unless you trust more. Without the two steps below, sensors installed
from a private registry are moved back to Docker Hub on the next hourly sync.

Host only the Cloudanix images, under one path that keeps our repository names:
`config-manager`, `threat-monitor`, `inventory-collector`, `traffic-exporter`, `vuln-scanner`
and `misconfig-scanner` (e.g. `<registry>/cloudanix/vuln-scanner`). Falco, falcoctl and Cilium
are upstream images the chart pins; they keep their defaults.

1. Trust your registry path and install the sensors from it. Prefer your values file: the
   console's install command passes the same values as `--set` flags, which a later
   `helm upgrade` drops unless you pass them again. The list adds to the built-in
   `docker.io/cloudanix/` and `docker.io/falcosecurity/`, it never replaces them
   (config-manager reads it from its own pod, never from the platform). Each entry is `<registry host>/<path>/`, lowercase, with no scheme, tag or
   digest; `values.schema.json` refuses anything else:

   ```yaml
   trustedImageRepositories:
     - 123456789012.dkr.ecr.us-east-1.amazonaws.com/docker-hub/cloudanix/
   configManager:
     image: 123456789012.dkr.ecr.us-east-1.amazonaws.com/docker-hub/cloudanix/config-manager:v2.3.7
   # ...the same for threatMonitor, inventoryCollector, trafficExporter, vulnScanner, misconfigScanner
   ```

2. Ask Cloudanix support to set the registry for your workspace or cloud account
   (`123456789012.dkr.ecr.us-east-1.amazonaws.com/docker-hub`). The console then publishes
   `<registry>/cloudanix/<sensor>:<version>`, and the install command it shows carries the
   values above as flags. Do this after the `helm upgrade`: an image config-manager does not
   trust fails that sensor's sync (`CDX-CM-2002`) and leaves it on its old image.

Every new sensor version must exist in your registry before it reaches your clusters (an ECR
pull-through cache fetches it on first pull).

## Auth token from your own Secret or CSI

By default the chart creates the Secret `cloudanix-secrets` from `authToken`. Every pod reads
the token as the file `/etc/cdx/secrets/auth-token`.

### Your own Secret (External Secrets, Sealed Secrets, ...)

```yaml
authTokenSecret:
  create: false              # the chart does not create or own the Secret
  name: cloudanix-secrets    # Secret in the release namespace
  key: auth-token            # key holding the token
```

Create the Secret before `helm install`. A pre-install/pre-upgrade hook
(`cloudanix-auth-secret-check`) fails the release with a clear message when the Secret or key
is missing, empty or `DEFAULT`. `authToken` is not needed in values in this mode.

### Secrets Store CSI driver

The token comes straight from your secret manager, with no Kubernetes Secret. Install the
Secrets Store CSI driver and your provider first, and create a `SecretProviderClass` in the
release namespace that writes a file named `auth-token`.

```yaml
authTokenSecret:
  create: false              # required with CSI
  csi:
    enabled: true
    secretProviderClass: cloudanix-auth
    driver: secrets-store.csi.k8s.io
    roleArn: arn:aws:iam::123456789012:role/cloudanix-secrets   # EKS (IRSA)
    serviceAccountAnnotations: {}                               # any other provider
```

Every Cloudanix service account that mounts the volume gets the identity annotations:

| Cluster | Values |
|---|---|
| EKS (IRSA) | `csi.roleArn: arn:aws:iam::<account>:role/<role>` |
| GKE (Workload Identity with a Google service account) | `csi.serviceAccountAnnotations: {iam.gke.io/gcp-service-account: <gsa>@<project>.iam.gserviceaccount.com}` |
| AKS (Workload Identity) | `csi.serviceAccountAnnotations: {azure.workload.identity/client-id: <client-id>}`, plus `commonLabels: {azure.workload.identity/use: "true"}` if your setup requires the pod label |

`serviceAccountAnnotations` wins over `roleArn` on a shared key. The service accounts are
`config-manager-sa`, `inventory-collector-sa`, `threat-monitor-sa`, `misconfig-scanner-sa`,
`vuln-scanner-sa`, `traffic-exporter` and `cloudanix-auth-secret-check`; grant each one (or
the namespace) read access to the secret in your cloud IAM. The same pre-install check runs
in CSI mode.

## Falco and Cilium Charts

Falco and Cilium are community charts listed as dependencies in Chart.yaml. Helm installs them
based on `falco.enabled` / `cilium.enabled` / `ciliumOke.enabled` only, so keep those in step
with `capabilities`.

Cilium is listed twice, as `cilium` (EKS: AWS VPC CNI chaining) and `ciliumOke` (OKE: Flannel
generic-veth chaining with the chart's `cni-configuration`). Helm cannot pick a subchart's values
from `clusterDomain`, so each CNI profile is its own alias with its own defaults in `values.yaml`.
Turn on exactly one: both on, `ciliumOke` without `clusterDomain: OCI`, or `cilium` on
`clusterDomain: OCI` without `cilium.cni.chainingMode: generic-veth` (the AWS profile cannot
chain on Flannel) fails the install.

### Falco rules

What a release installs is written once, in `chart/rules/`:

- `upstream.yaml`: the Falco version and the upstream rules feeds (`falco-rules`,
  `falco-incubating-rules`, `falco-sandbox-rules`) pinned to exact versions. The follow sidecar
  is off, so rules change only with a chart upgrade.
- `cloudanix.yaml`: Cloudanix's own rules plus the exception that keeps our agents' expected
  Kubernetes API calls quiet. Rendered into the `cloudanix-falco-rules` ConfigMap and loaded
  from `/etc/falco/rules.d`. The Cloudanix console serves the same file, plus your threat
  exclusions, and config-manager writes it back into that ConfigMap every hour.

Only `falco-rules` (the stable feed) is loaded by default; the incubating and sandbox feeds are
installed and can be switched on with `falco.falco.rules_files` (see the note in
`values.yaml`).

**On upgrade**, Helm resets the ConfigMap to the chart's copy, which drops your exclusions until
config-manager runs again. `helm upgrade` therefore starts one config-manager run right away
(`Job/config-manager-upgrade-r<revision>`). GitOps tools render without that Job: run
`kubectl -n cloudanix create job --from=cronjob/config-manager sync-after-upgrade` after the
sync instead. The Falco DaemonSet rolls one node at a time; set
`falco.controller.daemonset.updateStrategy.rollingUpdate.maxUnavailable` for large clusters.

## Usage

Clone this repository and in `chart` folder, update the `yourValues.yaml` to override the values.
To install the chart, run

```bash
helm dependency update
helm install cloudanix -f yourValues.yaml .
```

To delete the chart, run

```bash
helm delete cloudanix
```

## Verifying the chart

Each chart version is published with a SHA256 checksum, as a GitHub release of
[Cloudanix/charts](https://github.com/Cloudanix/charts/releases) named `cloudanix-<version>`.
Check the file you install against it:

```bash
VERSION=2.4.6
helm pull cloudanix/cloudanix --version "$VERSION"
curl -fsSLO "https://github.com/Cloudanix/charts/releases/download/cloudanix-$VERSION/cloudanix-$VERSION.tgz.sha256"
sha256sum -c cloudanix-"$VERSION".tgz.sha256   # macOS: shasum -a 256 -c ...
# cloudanix-2.4.6.tgz: OK
helm install cloudanix ./cloudanix-"$VERSION".tgz -f yourValues.yaml
```

Releases up to 2.4.1 name the release file `SHA256SUMS` instead; same content.

The same line is also served next to the chart, as
`https://cloudanix.github.io/charts/cloudanix-<version>.tgz.sha256` (`sha256sum -c` reads it
too), and the same hash is the `digest` of that version in
`https://cloudanix.github.io/charts/index.yaml`. Those two sit on the same host as the chart;
the release is the copy from a second place. Mirror the `.tgz` and its `.sha256` together into
an air-gapped registry and verify after the copy.
A published version is never rebuilt: if the check fails, do not install, and contact Cloudanix.
