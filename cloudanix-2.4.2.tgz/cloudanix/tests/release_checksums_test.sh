#!/usr/bin/env bash
# Checks for the chart checksum scripts (docs/chart-checksums.md).
# Requires helm and the subcharts in chart/charts (helm dependency build chart).
# Run: chart/tests/release_checksums_test.sh
set -euo pipefail

cd "$(dirname "$0")/../.."
fail=0
work=$(mktemp -d "${TMPDIR:-/tmp}/cdx-checksums.XXXXXX")
trap 'rm -rf "$work"' EXIT

ok() { echo "ok   - $1"; }
bad() { echo "FAIL - $1"; fail=1; }
check() { # <label> <command...>: passes when the command succeeds
  local label=$1; shift
  if "$@" >/dev/null 2>&1; then ok "$label"; else bad "$label"; fi
}
check_not() { # <label> <command...>: passes when the command fails
  local label=$1; shift
  if "$@" >/dev/null 2>&1; then bad "$label"; else ok "$label"; fi
}

version=$(awk '$1 == "version:" { print $2; exit }' chart/Chart.yaml)
tgz="cloudanix-$version.tgz"

# --- package-chart.sh -------------------------------------------------------------------------

out="$work/dist"
printed=$(scripts/package-chart.sh "$out")
check "prints the path of $tgz (got $printed)" test "$printed" = "$out/$tgz"
check "$tgz.sha256 verifies the packaged chart" bash -c "cd '$out' && shasum -a 256 -c $tgz.sha256"
# Exactly one line, '<sha256>  <tgz>': the format sha256sum -c and shasum -c both read.
check "$tgz.sha256 is one '<sha256>  $tgz' line" grep -qxE "[0-9a-f]{64}  $tgz" "$out/$tgz.sha256"
check "$tgz.sha256 has one line" test "$(wc -l < "$out/$tgz.sha256" | tr -d ' ')" = 1
# Named for publishing as-is: no SHA256SUMS to rename later.
check "writes only $tgz and $tgz.sha256" test "$(cd "$out" && echo *)" = "$tgz $tgz.sha256"
# release.yml attaches its ASSETS globs from the directory holding dist/: they must name exactly
# these two files, or the release misses the checksum publish-chart.sh downloads.
globs=$(sed -n 's/^ *ASSETS=(\(dist\/.*\))$/\1/p' .github/workflows/release.yml)
# shellcheck disable=SC2086 # expand the workflow's globs as its shell does
attached=$(cd "$work" && echo $globs)
check "release.yml attaches dist/$tgz and its .sha256 (got $attached)" \
  test "$attached" = "dist/$tgz dist/$tgz.sha256"
meta=$(helm show chart "$out/$tgz")
check "tgz is chart $version" grep -qx "version: $version" <<<"$meta"

# --- publish-chart.sh, against a stub gh --------------------------------------------------------
# The stub serves `release download` from $RELEASE_DIR (this repo) or $GH_LOG.uploads (the
# public release), logs `release create` to $GH_LOG and keeps each uploaded file under
# $GH_LOG.uploads. Like real gh, `release view` finds the public release once it exists and a
# second `release create` for it fails.

mkdir -p "$work/bin"
cat > "$work/bin/gh" <<'STUB'
#!/usr/bin/env bash
set -euo pipefail
case "$1 $2" in
  "release view")
    [ -d "$GH_LOG.uploads" ] || { echo "release not found" >&2; exit 1; } ;;
  "release download")
    dest="" repo="" patterns=()
    shift 2
    while [ $# -gt 0 ]; do
      case "$1" in
        -p) patterns+=("$2"); shift 2 ;;
        -D) dest=$2; shift 2 ;;
        -R) repo=$2; shift 2 ;;
        *) shift ;;
      esac
    done
    src=$RELEASE_DIR
    [ "$repo" = Cloudanix/charts ] && src=$GH_LOG.uploads
    for p in "${patterns[@]}"; do cp "$src/$p" "$dest/" || exit 1; done ;;
  "release create")
    [ -d "$GH_LOG.uploads" ] && { echo "a release with the same tag name already exists" >&2; exit 1; }
    echo "$*" >> "$GH_LOG"
    mkdir -p "$GH_LOG.uploads"
    for a in "$@"; do [ -f "$a" ] && cp "$a" "$GH_LOG.uploads/"; done
    exit 0 ;;
  *) echo "stub gh: unexpected $*" >&2; exit 2 ;;
esac
STUB
chmod +x "$work/bin/gh"

new_charts() { # fresh Cloudanix/charts-like checkout with an empty index
  local d="$work/charts-$1"
  mkdir -p "$d" && helm repo index "$d" && echo "$d"
}
# shellcheck disable=SC2329 # called through check/check_not
publish() { # <release-dir> <charts-dir> <gh-log>
  PATH="$work/bin:$PATH" RELEASE_DIR=$1 GH_LOG=$3 scripts/publish-chart.sh "$version" "$2"
}
sha=$(cut -d' ' -f1 "$out/$tgz.sha256")

# Good release: copied byte for byte, indexed with the same digest, public release cut.
charts=$(new_charts good)
log="$work/gh-good.log"
check "publishes a verified release" publish "$out" "$charts" "$log"
check "tgz in the charts checkout is the CI build" cmp "$out/$tgz" "$charts/$tgz"
check "index.yaml digest equals $tgz.sha256" grep -q "digest: $sha" "$charts/index.yaml"
check "$tgz.sha256 next to the chart is the CI one" cmp "$out/$tgz.sha256" "$charts/$tgz.sha256"
check "$tgz.sha256 verifies the chart in the checkout" \
  bash -c "cd '$charts' && shasum -a 256 -c '$tgz.sha256'"
check "index.yaml lists only charts, not the .sha256" test "$(grep -c '\.sha256' "$charts/index.yaml")" = 0
check "public release cloudanix-$version created on Cloudanix/charts" \
  grep -q "release create cloudanix-$version -R Cloudanix/charts" "$log"
check "release notes carry the sha256" grep -q "sha256: $sha" "$log"
check "release notes point customers at $tgz.sha256" \
  grep -q "releases/download/cloudanix-$version/$tgz.sha256" "$log"
check "uploaded tgz is the CI build" cmp "$out/$tgz" "$log.uploads/$tgz"
check "uploaded $tgz.sha256 is the CI one" cmp "$out/$tgz.sha256" "$log.uploads/$tgz.sha256"

# Same bytes again, after the public release was cut but the charts push failed: allowed,
# and the existing public release is kept.
check "re-publishing identical bytes succeeds" publish "$out" "$charts" "$log"
check "re-publish cuts no second release" test "$(grep -c 'release create' "$log")" = 1

# Public release already cut with other bytes, or missing an asset: refused before the
# checkout is touched.
for case in other-bytes no-sums; do
  charts=$(new_charts "$case")
  log="$work/gh-$case.log"
  mkdir -p "$log.uploads" && cp "$out/$tgz" "$out/$tgz.sha256" "$log.uploads/"
  [ "$case" = other-bytes ] && printf 'x' >> "$log.uploads/$tgz"
  [ "$case" = no-sums ] && rm "$log.uploads/$tgz.sha256"
  check_not "public release with $case is refused" publish "$out" "$charts" "$log"
  check_not "public release with $case: tgz not copied" test -e "$charts/$tgz"
done

# Corrupt download: refused before anything is written or released.
corrupt="$work/corrupt"
mkdir -p "$corrupt" && cp "$out/$tgz.sha256" "$corrupt/" && cp "$out/$tgz" "$corrupt/"
printf 'x' >> "$corrupt/$tgz"
charts=$(new_charts corrupt)
log="$work/gh-corrupt.log"
check_not "corrupt tgz is refused" publish "$corrupt" "$charts" "$log"
check_not "corrupt tgz not copied" test -e "$charts/$tgz"
check_not "no .sha256 written for a corrupt tgz" test -e "$charts/$tgz.sha256"
check_not "no release for a corrupt tgz" test -e "$log"

# Release without the chart (tag did not match Chart.yaml): nothing to publish.
empty="$work/empty" && mkdir -p "$empty"
log="$work/gh-empty.log"
check_not "release without the chart is refused" publish "$empty" "$(new_charts empty)" "$log"
check_not "no release without the chart" test -e "$log"

# Version already published with other bytes: never overwritten.
charts=$(new_charts taken)
echo "older build" > "$charts/$tgz"
log="$work/gh-taken.log"
check_not "different bytes for a published version are refused" publish "$out" "$charts" "$log"
check "published tgz left untouched" grep -qx "older build" "$charts/$tgz"
check_not "no .sha256 written when the version is taken" test -e "$charts/$tgz.sha256"
check_not "no release when the version is taken" test -e "$log"

exit "$fail"
