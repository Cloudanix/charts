#!/usr/bin/env bash
# authTokenSecret.create defaults to true (chart creates the Secret).
# create=false skips that Secret, mounts the named key as auth-token, and
# renders a pre-install check. Workloads, the first scanner run, and the
# uninstall notice do not need authToken in values in that mode.
# Requires helm. Run: chart/tests/auth_secret_render_test.sh
set -euo pipefail

cd "$(dirname "$0")/../.."
CHART=chart
COMMON=(--set accountId=a --set clusterIdentifier=c --set clusterName=n --set clusterDomain=AWS --set capabilities=all)
fail=0

check() {
  local label=$1
  shift
  if "$@"; then echo "ok   - $label"; else echo "FAIL - $label"; fail=1; fi
}

render() { helm template cdx "$CHART" -n cloudanix "${COMMON[@]}" "$@"; }

default=$(render --set authToken=t)
check "default chart creates cloudanix-secrets" grep -q 'name: cloudanix-secrets' <<<"$default"
check "default secret data key is auth-token" grep -q '^  auth-token:' <<<"$default"
check "default install has no auth precheck" bash -c 'grep -q "name: cloudanix-auth-secret-check" <<<"$1"; test $? -ne 0' _ "$default"

external=$(render --set authTokenSecret.create=false --set authTokenSecret.name=platform-auth --set authTokenSecret.key=token)
check "external mode renders no Secret" bash -c 'grep -q "^kind: Secret$" <<<"$1"; test $? -ne 0' _ "$external"
check "external mode mounts the named secret" grep -q 'secretName: platform-auth' <<<"$external"
check "external mode projects the key to auth-token" grep -q 'key: token' <<<"$external"
check "external mode file path is auth-token" grep -q 'path: auth-token' <<<"$external"
check "external mode renders the precheck hook" grep -q 'name: cloudanix-auth-secret-check' <<<"$external"
check "precheck secret volume is optional" bash -c 'test "$(grep -c "optional: true" <<<"$1")" -eq 1' _ "$external"
check "precheck is pre-install and pre-upgrade" grep -q 'pre-install,pre-upgrade' <<<"$external"
check "external mode still renders the uninstall notice" grep -q 'name: cloudanix-uninstall-notify' <<<"$external"
check "uninstall notice reads the external key" grep -q 'key: token' <<<"$external"
check "external mode renders the vuln initial run without authToken" grep -q 'name: vuln-scanner-initial-r1' <<<"$external"

csi=$(render --set authTokenSecret.create=false --set authTokenSecret.csi.enabled=true --set authTokenSecret.csi.secretProviderClass=cloudanix-auth --set authTokenSecret.csi.roleArn=arn:aws:iam::123:role/cloudanix-secrets)
check "csi mode renders no Secret" bash -c 'grep -q "^kind: Secret$" <<<"$1"; test $? -ne 0' _ "$csi"
check "csi mode mounts the driver" grep -q 'driver: secrets-store.csi.k8s.io' <<<"$csi"
check "csi mode names the SecretProviderClass" grep -q 'secretProviderClass: cloudanix-auth' <<<"$csi"
check "csi mode annotates the service account" grep -q 'eks.amazonaws.com/role-arn: "arn:aws:iam::123:role/cloudanix-secrets"' <<<"$csi"
check "csi mode uninstall reads the mounted file" grep -q 'cat /etc/cdx/secrets/auth-token' <<<"$csi"
precheck=$(awk '/^kind: Job$/{job=1} job && /name: cloudanix-auth-secret-check/{p=1} p && /^---/{exit} p' <<<"$external")
check "precheck sets requests and limits" bash -c 'grep -q "cpu: \"10m\"" <<<"$1" && grep -q "memory: \"64Mi\"" <<<"$1"' _ "$precheck"

# Every service account that mounts the CSI volume (7 with capabilities=all, the precheck's
# included) gets the provider's identity annotation; it wins over roleArn on a shared key.
gke=$(render --set authTokenSecret.create=false --set authTokenSecret.csi.enabled=true --set authTokenSecret.csi.secretProviderClass=cloudanix-auth \
  --set 'authTokenSecret.csi.serviceAccountAnnotations.iam\.gke\.io/gcp-service-account=cdx@p.iam.gserviceaccount.com' \
  --set authTokenSecret.csi.roleArn=arn:aws:iam::123:role/a --set 'authTokenSecret.csi.serviceAccountAnnotations.eks\.amazonaws\.com/role-arn=arn:aws:iam::123:role/b')
check "csi serviceAccountAnnotations on every CSI service account" bash -c 'test "$(grep -c "iam.gke.io/gcp-service-account: \"cdx@p.iam.gserviceaccount.com\"" <<<"$1")" -eq 7' _ "$gke"
check "csi serviceAccountAnnotations win over roleArn" bash -c 'grep -q "role/b" <<<"$1" && ! grep -q "role/a" <<<"$1"' _ "$gke"
check "no identity annotations without csi" bash -c '! grep -q "iam.gke.io" <<<"$1"' _ "$(render --set authToken=t --set 'authTokenSecret.csi.serviceAccountAnnotations.iam\.gke\.io/gcp-service-account=x')"

# The token reaches every workload only as the mounted file. The old trafficExporter.apiToken
# path (a values-held token in its own Secret and env var, read by nothing) must not return.
legacy=$(render --set authToken=t --set trafficExporter.apiToken=leaked)
check "legacy trafficExporter.apiToken renders no Secret or env" bash -c '! grep -q -e leaked -e BACKEND_API_TOKEN -e traffic-exporter-secret <<<"$1"' _ "$legacy"
if helm template cdx "$CHART" -n cloudanix "${COMMON[@]}" --set authTokenSecret.csi.enabled=true --set authTokenSecret.csi.secretProviderClass=cloudanix-auth >/dev/null 2>&1; then
  echo "FAIL - csi without create=false is rejected"
  fail=1
else
  echo "ok   - csi without create=false is rejected"
fi

echo
if (( fail )); then echo "$fail check(s) failed"; else echo "0 failure(s)"; fi
exit $fail
