#!/usr/bin/env bash
# Render assertions for vuln-scanner runtime socket selection.
# values.yaml pins containerd on every cloud; OKE installs add values-oke.yaml (CRI-O), as the
# console's install command does. An empty value picks by clusterDomain (CRI-O on OCI, else
# containerd), and an explicit path always wins.
# Requires helm. Run: chart/tests/runtime_socket_render_test.sh
set -euo pipefail

cd "$(dirname "$0")/../.."
CHART=chart
COMMON=(--set accountId=a --set clusterIdentifier=c --set clusterName=n --set authToken=t --set capabilities=vulnerabilities)
# ConfigMap, plus annotation, env, mount and hostPath on the CronJob and the initial Job.
SURFACES=9
fail=0

render() { helm template cdx "$CHART" "${COMMON[@]}" "$@" -s templates/vuln-scanner.tpl 2>&1; }

assert_surfaces() { # <manifest> <socket> <label>
  # Count YAML values equal to the socket, so comments that mention it do not count.
  count=$(grep -cE -- "^ *[A-Za-z./-]+: \"?$2\"?\$" <<<"$1" || true)
  if (( count == SURFACES )); then echo "ok   - $3"; else echo "FAIL - $3 (got $count, want $SURFACES)"; fail=1; fi
}

pinned=$(render --set clusterDomain=OCI)
assert_surfaces "$pinned" "/run/containerd/containerd.sock" "default values pin containerd, even on OCI"

oke=$(render -f "$CHART/values-oke.yaml" --set clusterDomain=OCI)
assert_surfaces "$oke" "/run/crio/crio.sock" "values-oke.yaml gives every scanner surface CRI-O"
annotations=$(grep -cF 'cloudanix.com/container-runtime-socket: "/run/crio/crio.sock"' <<<"$oke" || true)
if (( annotations == 2 )); then
  echo "ok   - CronJob and initial Job carry socket annotation"
else
  echo "FAIL - CronJob and initial Job carry socket annotation (got $annotations, want 2)"
  fail=1
fi

oci=$(render --set clusterDomain=OCI --set vulnScanner.containerRuntimeSocket=)
assert_surfaces "$oci" "/run/crio/crio.sock" "empty value on OCI falls back to CRI-O"

aws=$(render --set clusterDomain=AWS --set vulnScanner.containerRuntimeSocket=)
assert_surfaces "$aws" "/run/containerd/containerd.sock" "empty value elsewhere falls back to containerd"

override=$(render --set clusterDomain=OCI --set vulnScanner.containerRuntimeSocket=/run/k3s/containerd/containerd.sock)
assert_surfaces "$override" "/run/k3s/containerd/containerd.sock" "explicit socket overrides OCI default"
if grep -qF "/run/crio/crio.sock" <<<"$override"; then
  echo "FAIL - explicit socket render retains OCI default"
  fail=1
else
  echo "ok   - explicit socket render contains no OCI default"
fi

exit $fail
