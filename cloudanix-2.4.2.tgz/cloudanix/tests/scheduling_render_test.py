#!/usr/bin/env python3
"""Pod settings every Cloudanix pod shares.

`scheduling` (nodeSelector, affinity, tolerations, priorityClassName, podAnnotations),
`imagePullSecrets`, `dnsPolicy` and `dnsConfig` land on every Cloudanix pod: the
workloads, their one-off Jobs and the hooks. `<component>.podAnnotations` land on that
component's pods only and win over the shared annotations, which win over the chart's
own (vuln-scanner's runtime socket). The cilium cleanup Job keeps its tolerate-everything
toleration and skips DNS (hostNetwork); its DaemonSet takes annotations and pull secrets
but no placement. Falco is a subchart and is left alone. Empty defaults render nothing.

Usage: chart/tests/scheduling_render_test.py
"""
import os
import subprocess
import sys
import tempfile

try:
    import yaml
except ImportError:
    sys.exit("PyYAML required: pip install pyyaml")

CHART = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
BASE = [
    "--set", "accountId=a", "--set", "clusterIdentifier=c", "--set", "clusterDomain=AWS",
    "--set", "capabilities=all", "--set", "cilium.enabled=true", "--is-upgrade",
]
TOKEN = ["--set", "authToken=t"]
EXTERNAL = ["--set", "authTokenSecret.create=false"]
# Pod name -> the values key whose podAnnotations it takes (None: shared values only).
PODS = {
    "config-manager": "configManager",
    "config-manager-upgrade-r1": "configManager",
    "misconfig-scanner": "misconfigScanner",
    "misconfig-scanner-initial-r1": "misconfigScanner",
    "vuln-scanner": "vulnScanner",
    "vuln-scanner-initial-r1": "vulnScanner",
    "inventory-collector": "inventoryCollector",
    "threat-monitor": "threatMonitor",
    "traffic-exporter": "trafficExporter",
    "cloudanix-uninstall-notify": None,
    "cloudanix-auth-secret-check": None,
}
CLEANUP = "cilium-cni-cleanup"
SOCKET = "cloudanix.com/container-runtime-socket"
PLACEMENT = {
    "nodeSelector": {"karpenter.sh/nodepool": "agents"},
    "tolerations": [{"key": "dedicated", "operator": "Equal", "value": "cloudanix", "effect": "NoSchedule"}],
    "affinity": {"nodeAffinity": {"requiredDuringSchedulingIgnoredDuringExecution": {
        "nodeSelectorTerms": [{"matchExpressions": [
            {"key": "kubernetes.io/os", "operator": "In", "values": ["linux"]}]}]}}},
    "priorityClassName": "cloudanix-agents",
}
# Two keys: the old template rendered dnsConfig without indentation, which broke on more than one.
DNS_CONFIG = {"nameservers": ["10.0.0.10"], "options": [{"name": "ndots", "value": "2"}]}
PULL = [{"name": "regcred"}]
JOB_ONLY = "karpenter.sh/do-not-disrupt"
CUSTOM = {
    "scheduling": {**PLACEMENT, "podAnnotations": {"sidecar.istio.io/inject": "false", SOCKET: "shared", "tier": "shared"}},
    "imagePullSecrets": PULL,
    "dnsPolicy": "ClusterFirst",
    "dnsConfig": DNS_CONFIG,
    "ciliumCleanup": {"kubectlImage": "mirror.example/kubectl:1", "busyboxImage": "mirror.example/busybox:1"},
    "threatMonitor": {"podAnnotations": {"tier": "component"}},
    "configManager": {"podAnnotations": {JOB_ONLY: "true"}},
    "misconfigScanner": {"podAnnotations": {JOB_ONLY: "true"}},
    "vulnScanner": {"podAnnotations": {JOB_ONLY: "true", SOCKET: "component"}},
}

failures = []


def check(ok, label):
    print(("ok   - " if ok else "FAIL - ") + label)
    if not ok:
        failures.append(label)


def render(args, values=None):
    cmd = ["helm", "template", "cdx", CHART, *BASE, *args]
    extra = None
    if values:
        extra = tempfile.NamedTemporaryFile("w", suffix=".yaml", delete=False)
        extra.write(yaml.safe_dump(values))
        extra.close()
        cmd += ["-f", extra.name]
    out = subprocess.run(cmd, capture_output=True, text=True)
    if extra:
        os.unlink(extra.name)
    if out.returncode:
        sys.exit("helm template failed:\n" + out.stderr)
    return out.stdout


def pods(manifest):
    found = {}
    for chunk in manifest.split("\n---\n"):
        obj = yaml.safe_load(chunk)
        if not obj or obj.get("kind") not in ("Deployment", "CronJob", "Job", "DaemonSet"):
            continue
        name = obj["metadata"]["name"]
        if name not in PODS and name != CLEANUP and not name.endswith("-falco"):
            continue
        spec = obj["spec"]
        if obj["kind"] == "CronJob":
            spec = spec["jobTemplate"]["spec"]
        found[name] = spec["template"]
    return found


def render_pods(values=None):
    # The auth precheck renders only with an external Secret, the rest with a token.
    found = pods(render(TOKEN, values))
    found.update(pods(render(EXTERNAL, values)))
    return found


def annotations(pod):
    return (pod.get("metadata") or {}).get("annotations") or {}


def has_limits(pod):
    res = pod["spec"]["containers"][0].get("resources") or {}
    return bool(res.get("requests")) and bool(res.get("limits"))


def cleanup_daemonset(job_pod):
    """The cleanup Job applies its DaemonSet from a heredoc in its shell script."""
    script = job_pod["spec"]["containers"][0]["command"][2]
    body = script.split("<<'DS' | kubectl apply -f -\n", 1)[1].split("\nDS\n", 1)[0]
    return yaml.safe_load(body)["spec"]["template"]


def check_defaults(found):
    check(set(PODS).issubset(found), "every Cloudanix pod renders")
    for name in PODS:
        spec = found[name]["spec"]
        for field in (*PLACEMENT, "imagePullSecrets", "dnsPolicy", "dnsConfig"):
            check(field not in spec, f"{name} default pod has no {field}")
        ann = annotations(found[name])
        check(set(ann) <= {SOCKET}, f"{name} default pod has no customer annotation")
    check(SOCKET in annotations(found["vuln-scanner"]), "vuln-scanner keeps its socket annotation")
    cleanup = found[CLEANUP]["spec"]
    check(cleanup["tolerations"] == [{"operator": "Exists"}], "cleanup Job tolerates every taint by default")
    check("nodeSelector" not in cleanup and "imagePullSecrets" not in cleanup, "cleanup Job default has no placement")
    # A pre-delete hook rejected by a "require limits" admission policy blocks helm uninstall.
    check(has_limits(found[CLEANUP]), "cleanup Job sets requests and limits")
    check(has_limits(cleanup_daemonset(found[CLEANUP])), "cleanup DaemonSet sets requests and limits")


def check_custom_pods(found):
    for name, component in PODS.items():
        spec = found[name]["spec"]
        for field, value in PLACEMENT.items():
            check(spec.get(field) == value, f"{name} {field}")
        check(spec.get("imagePullSecrets") == PULL, f"{name} imagePullSecrets")
        check(spec.get("dnsPolicy") == "ClusterFirst" and spec.get("dnsConfig") == DNS_CONFIG, f"{name} dns")
        ann = annotations(found[name])
        check(ann.get("sidecar.istio.io/inject") == "false", f"{name} shared annotation")
        job_only = component in ("configManager", "misconfigScanner", "vulnScanner")
        check((JOB_ONLY in ann) == job_only, f"{name} component annotation only on its own pods")
    check(annotations(found["threat-monitor"]).get("tier") == "component", "component annotation wins over shared")
    check(annotations(found["inventory-collector"]).get("tier") == "shared", "other components keep the shared value")
    for name in ("vuln-scanner", "vuln-scanner-initial-r1"):
        check(annotations(found[name]).get(SOCKET) == "component", f"{name} component annotation wins over chart socket")


def check_custom_cleanup(found):
    job = found[CLEANUP]
    spec = job["spec"]
    check(spec.get("nodeSelector") == PLACEMENT["nodeSelector"], "cleanup Job nodeSelector")
    check(spec.get("affinity") == PLACEMENT["affinity"], "cleanup Job affinity")
    check(spec.get("priorityClassName") == "cloudanix-agents", "cleanup Job priorityClassName")
    check(spec.get("tolerations") == [{"operator": "Exists"}], "cleanup Job keeps its own toleration only")
    check(spec.get("imagePullSecrets") == PULL, "cleanup Job imagePullSecrets")
    check("dnsPolicy" not in spec, "cleanup Job (hostNetwork) gets no dnsPolicy")
    check(annotations(job).get("sidecar.istio.io/inject") == "false", "cleanup Job shared annotation")
    ds = cleanup_daemonset(job)
    check(annotations(ds).get("sidecar.istio.io/inject") == "false", "cleanup DaemonSet shared annotation")
    check(ds["spec"].get("imagePullSecrets") == PULL, "cleanup DaemonSet imagePullSecrets")
    check("nodeSelector" not in ds["spec"] and "affinity" not in ds["spec"], "cleanup DaemonSet has no placement")
    check(ds["spec"]["containers"][0]["image"] == "mirror.example/busybox:1", "cleanup DaemonSet image override")
    check(spec["containers"][0]["image"] == "mirror.example/kubectl:1", "cleanup Job image override")


def main():
    check_defaults(render_pods())
    custom = render_pods(CUSTOM)
    check_custom_pods(custom)
    check_custom_cleanup(custom)
    falco = next(pod for name, pod in custom.items() if name.endswith("-falco"))
    check(falco["spec"].get("nodeSelector") != PLACEMENT["nodeSelector"], "falco is not given the shared nodeSelector")

    print(f"\n{len(failures)} failure(s)")
    sys.exit(1 if failures else 0)


if __name__ == "__main__":
    main()
