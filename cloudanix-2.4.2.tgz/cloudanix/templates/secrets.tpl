{{- if ne (include "cloudanix.authFromExternal" .) "true" }}
apiVersion: v1
kind: Secret
metadata:
  name: {{ include "cloudanix.authSecretName" . }}
  namespace: {{ .Release.Namespace }}
  {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
  labels:
    {{- . | nindent 4 }}
  {{- end }}
type: Opaque
data:
  {{ include "cloudanix.authSecretKey" . }}: {{ .Values.authToken | default "DEFAULT" | b64enc }}
{{- end }}
