{{/*
Runs only when authTokenSecret.create is false. Fails the install or upgrade
unless the external Secret is mounted and its key is a non-empty token.
The volume is optional: a required Secret leaves the pod Pending, the Job's
failed-pod count stays 0, and Helm waits out its own timeout. The deadline
is only the backstop. Helm deletes the Job via hook-delete-policy; a short
ttl would remove it before Helm records the failure.
*/}}
{{- if eq (include "cloudanix.authFromExternal" .) "true" }}
{{- if eq (include "cloudanix.authFromCSI" .) "true" }}
apiVersion: v1
kind: ServiceAccount
metadata:
  name: cloudanix-auth-secret-check
  namespace: {{ .Release.Namespace }}
  {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
  labels:
    {{- . | nindent 4 }}
  {{- end }}
  annotations:
    "helm.sh/hook": pre-install,pre-upgrade
    "helm.sh/hook-weight": "-10"
    "helm.sh/hook-delete-policy": before-hook-creation,hook-succeeded,hook-failed
    {{- with include "cloudanix.authTokenSAAnnotations" . }}
    {{- . | nindent 4 }}
    {{- end }}
---
{{- end }}
apiVersion: batch/v1
kind: Job
metadata:
  name: cloudanix-auth-secret-check
  namespace: {{ .Release.Namespace }}
  {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
  labels:
    {{- . | nindent 4 }}
  {{- end }}
  annotations:
    "helm.sh/hook": pre-install,pre-upgrade
    "helm.sh/hook-weight": "-5"
    "helm.sh/hook-delete-policy": before-hook-creation,hook-succeeded,hook-failed
spec:
  backoffLimit: 0
  activeDeadlineSeconds: 60
  template:
    {{- with include "cloudanix.podMetadata" (dict "labels" (include "cloudanix.mergeLabels" (list .Values.commonLabels)) "annotations" (include "cloudanix.podAnnotations" (dict "root" .))) }}
    {{- . | nindent 4 }}
    {{- end }}
    spec:
      restartPolicy: Never
      {{- if eq (include "cloudanix.authFromCSI" .) "true" }}
      serviceAccountName: cloudanix-auth-secret-check
      automountServiceAccountToken: true
      {{- else }}
      automountServiceAccountToken: false
      {{- end }}
      {{- with include "cloudanix.podSpec" . }}
      {{- . | nindent 6 }}
      {{- end }}
      securityContext:
        runAsUser: 1001
        runAsGroup: 1001
        runAsNonRoot: true
        seccompProfile:
          type: RuntimeDefault
      containers:
        - name: check
          image: {{ .Values.configManager.image }}
          imagePullPolicy: IfNotPresent
          securityContext:
            allowPrivilegeEscalation: false
            readOnlyRootFilesystem: true
            capabilities:
              drop: ["ALL"]
          resources:
            requests:
              memory: "16Mi"
              cpu: "10m"
            limits:
              memory: "64Mi"
              cpu: "100m"
          command: ["sh", "-c"]
          args:
            - |
              token=$(cat /etc/cdx/secrets/auth-token)
              if [ -z "$token" ] || [ "$token" = "DEFAULT" ]; then
                echo "Secret {{ include "cloudanix.authSecretName" . }} key {{ include "cloudanix.authSecretKey" . }} is empty"
                exit 1
              fi
              echo "auth token secret is present"
          volumeMounts:
            - name: cloudanix-secrets-volume
              mountPath: /etc/cdx/secrets
              readOnly: true
      volumes:
        - name: cloudanix-secrets-volume
          {{- if eq (include "cloudanix.authFromCSI" .) "true" }}
          {{- include "cloudanix.authSecretVolume" . | nindent 10 }}
          {{- else }}
          secret:
            secretName: {{ include "cloudanix.authSecretName" . }}
            optional: true
            items:
              - key: {{ include "cloudanix.authSecretKey" . }}
                path: auth-token
          {{- end }}
{{- end }}
