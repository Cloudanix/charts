{{- if .Values.cilium.enabled }}
---
apiVersion: v1
kind: ServiceAccount
metadata:
  name: cilium-cni-cleanup
  namespace: {{ .Release.Namespace }}
  {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
  labels:
    {{- . | nindent 4 }}
  {{- end }}
  annotations:
    "helm.sh/hook": pre-delete
    "helm.sh/hook-weight": "-10"
    "helm.sh/hook-delete-policy": hook-succeeded,hook-failed

---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: cilium-cni-cleanup
  {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
  labels:
    {{- . | nindent 4 }}
  {{- end }}
  annotations:
    "helm.sh/hook": pre-delete
    "helm.sh/hook-weight": "-10"
    "helm.sh/hook-delete-policy": hook-succeeded,hook-failed
rules:
  - apiGroups: ["apps"]
    resources: ["daemonsets"]
    verbs: ["create", "delete", "get"]
  - apiGroups: [""]
    resources: ["pods"]
    verbs: ["list", "get"]

---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: cilium-cni-cleanup
  {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
  labels:
    {{- . | nindent 4 }}
  {{- end }}
  annotations:
    "helm.sh/hook": pre-delete
    "helm.sh/hook-weight": "-10"
    "helm.sh/hook-delete-policy": hook-succeeded,hook-failed
subjects:
  - kind: ServiceAccount
    name: cilium-cni-cleanup
    namespace: {{ .Release.Namespace }}
roleRef:
  kind: ClusterRole
  name: cilium-cni-cleanup
  apiGroup: rbac.authorization.k8s.io

---
apiVersion: batch/v1
kind: Job
metadata:
  name: cilium-cni-cleanup
  namespace: {{ .Release.Namespace }}
  {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
  labels:
    {{- . | nindent 4 }}
  {{- end }}
  annotations:
    "helm.sh/hook": pre-delete
    "helm.sh/hook-weight": "0"
    "helm.sh/hook-delete-policy": hook-succeeded,hook-failed
spec:
  ttlSecondsAfterFinished: 60
  template:
    {{- with include "cloudanix.podMetadata" (dict "labels" (include "cloudanix.mergeLabels" (list .Values.commonLabels)) "annotations" (include "cloudanix.podAnnotations" (dict "root" .))) }}
    {{- . | nindent 4 }}
    {{- end }}
    spec:
      hostNetwork: true
      serviceAccountName: cilium-cni-cleanup
      restartPolicy: Never
      # Tolerates every taint, so customer tolerations add nothing; the rest of the shared
      # placement applies. No dnsPolicy/dnsConfig: hostNetwork pods use the node's DNS.
      tolerations:
        - operator: Exists
      {{- with include "cloudanix.scheduling" (omit (.Values.scheduling | default dict) "tolerations") }}
      {{- . | nindent 6 }}
      {{- end }}
      {{- with .Values.imagePullSecrets }}
      imagePullSecrets:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      containers:
        - name: cleanup
          image: {{ .Values.ciliumCleanup.kubectlImage }}
          imagePullPolicy: IfNotPresent
          # Headroom on purpose: an OOM kill in a pre-delete hook blocks helm uninstall.
          resources:
            requests:
              memory: "64Mi"
              cpu: "10m"
            limits:
              memory: "256Mi"
              cpu: "200m"
          command:
            - sh
            - -c
            - |
              echo "Removing Cilium CNI conflist from all nodes..."
              # Create a DaemonSet that removes the conflist on every node
              cat <<'DS' | kubectl apply -f -
              apiVersion: apps/v1
              kind: DaemonSet
              metadata:
                name: cilium-cni-cleanup-ds
                namespace: {{ .Release.Namespace }}
                {{- with include "cloudanix.mergeLabels" (list .Values.commonLabels) }}
                labels:
                  {{- . | nindent 18 }}
                {{- end }}
              spec:
                selector:
                  matchLabels:
                    app: cilium-cni-cleanup
                template:
                  metadata:
                    labels:
                      {{- include "cloudanix.mergeLabels" (list .Values.commonLabels (dict "app" "cilium-cni-cleanup")) | nindent 22 }}
                    {{- with include "cloudanix.podAnnotations" (dict "root" .) }}
                    annotations:
                      {{- . | nindent 22 }}
                    {{- end }}
                  spec:
                    hostNetwork: true
                    # No placement: the conflist must go from every node Cilium ran on.
                    tolerations:
                      - operator: Exists
                    {{- with .Values.imagePullSecrets }}
                    imagePullSecrets:
                      {{- toYaml . | nindent 22 }}
                    {{- end }}
                    containers:
                      - name: cleanup
                        image: {{ .Values.ciliumCleanup.busyboxImage }}
                        imagePullPolicy: IfNotPresent
                        command: ["sh", "-c", "rm -f /host/etc/cni/net.d/05-cilium.conflist && echo done"]
                        resources:
                          requests:
                            memory: "8Mi"
                            cpu: "5m"
                          limits:
                            memory: "32Mi"
                            cpu: "50m"
                        volumeMounts:
                          - name: cni-conf
                            mountPath: /host/etc/cni/net.d
                    volumes:
                      - name: cni-conf
                        hostPath:
                          path: /etc/cni/net.d
                    terminationGracePeriodSeconds: 1
              DS
              # Wait for cleanup to run on all nodes
              echo "Waiting for cleanup DaemonSet to complete..."
              sleep 15
              # Delete the cleanup DaemonSet
              kubectl delete ds cilium-cni-cleanup-ds -n {{ .Release.Namespace }} --ignore-not-found
              echo "Cilium CNI conflist removed from all nodes."
{{- end }}
