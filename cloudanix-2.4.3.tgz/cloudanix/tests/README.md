# chart/tests

| Script | Needs | What it protects |
|---|---|---|
| `misconfig_render_test.sh` | helm | the misconfig-scanner template renders the right benchmark per `clusterDomain`, and its ClusterRole grants the kinds the audits need but never `secrets` |
| `uninstall_notify_render_test.sh` | helm | the pre-delete uninstall notice renders as a sync-status report flagged `event: UNINSTALL`, always exits 0 (a failed pre-delete hook aborts `helm uninstall`), and is skipped without an auth token or with status reporting off |
| `initial_run_render_test.sh` | helm | the vuln/misconfig scanners' one-off initial-run Jobs render on install (with a token, capability on, `initialRun.enabled`), are plain Jobs (a hook would block `helm install` for the whole scan) kept with `resource-policy: keep`, and leave the CronJobs untouched |
| `runtime_socket_render_test.sh` | helm | `values.yaml` pins containerd on every cloud, `values-oke.yaml` (the console's OKE install) gives every vuln-scanner socket surface CRI-O, an emptied value picks CRI-O on OCI and containerd elsewhere, and an explicit socket override wins |
| `falco_rules_render_test.sh` | helm, yq | the Falco rules wiring (`docs/falco-rules.md`): falcoctl installs exactly the feeds in `rules/upstream.yaml` and no follow sidecar, the Falco image is that file's version, the `cloudanix-falco-rules` ConfigMap carries `rules/cloudanix.yaml` verbatim and is mounted at `/etc/falco/rules.d` last in `rules_files`, config-manager writes to that ConfigMap, and an upgrade (with a token) renders the one-off config-manager Job that restores exclusions |
| `falco_baseline_exceptions_test.sh` | yq | the platform exceptions in `rules/cloudanix.yaml` (`docs/falco-rules.md` section 4a): names reserved as `cdx_baseline_*` and unique, one comp and one value per field, every image listed by equality also listed as `<repo>@sha256`, and an image-keyed operator row never also covers a shell or a dropped tool (nor a private registry, nor our own images), and the CloudNativePG wal-archive row matches the real archive_command but not other shells. `RULES=<file>` checks a candidate file |
| `falco_rules_validate_test.sh` | docker, curl, yq | Falco at the pinned version loads `rules/cloudanix.yaml` behind the pinned feeds, default set and all-feeds set. Skips with a warning without docker; CI has it. A rejected rules file would CrashLoop every Falco pod |
| `custom_labels_render_test.py` | helm, PyYAML | every object and pod the chart renders (hooks and the cilium-cleanup DaemonSet included) carries `commonLabels`, pods also their component's `podLabels`, with the chart's own labels winning on a shared key; selectors never change; values render as strings; no empty `labels:` without custom labels; the Falco/Cilium recipe in `chart/README.md` reaches the subcharts' pods |
| `auth_secret_render_test.sh` | helm | `authTokenSecret.create` defaults to creating `cloudanix-secrets`; `create=false` mounts that Secret; `csi.enabled` mounts a Secrets Store CSI volume instead and is rejected while `create` is still true; `csi.serviceAccountAnnotations` (GKE/AKS identity) land on every service account that mounts the CSI volume and win over `roleArn`; the precheck hook sets requests and limits; the removed `trafficExporter.apiToken` renders no Secret or env var |
| `scheduling_render_test.py` | helm, PyYAML | every Cloudanix pod (workloads, one-off Jobs, auth precheck, uninstall-notify, cilium cleanup Job and its DaemonSet) takes `scheduling` placement and `podAnnotations`, `imagePullSecrets`, `dnsPolicy`/`dnsConfig`, and nothing when they are empty; `<component>.podAnnotations` land on that component only and win over the shared value, which wins over the vuln-scanner socket annotation; the cilium cleanup Job keeps its tolerate-everything toleration and no DNS, its DaemonSet gets no placement; both set requests and limits and take the `ciliumCleanup` image overrides; a multi-key `dnsConfig` renders; Falco is left alone |
| `release_checksums_test.sh` | helm | the chart checksum flow (`docs/chart-checksums.md`): `scripts/package-chart.sh` writes a `cloudanix-<version>.tgz.sha256` that verifies the Chart.yaml version's tgz; `scripts/publish-chart.sh` (stub `gh`) publishes the CI chart and `.sha256` unchanged with a matching `index.yaml` digest, and a public `cloudanix-<version>` release, and refuses a corrupt download, a release without the chart, and a published version with other bytes |
| `rbac_coverage.py` | helm, PyYAML, sibling repos | three cross-repo contracts that otherwise fail **silently** |

```sh
chart/tests/misconfig_render_test.sh
chart/tests/initial_run_render_test.sh
chart/tests/falco_rules_render_test.sh
chart/tests/falco_baseline_exceptions_test.sh
chart/tests/falco_rules_validate_test.sh
chart/tests/release_checksums_test.sh
chart/tests/custom_labels_render_test.py
chart/tests/rbac_coverage.py
```

Falco rules beyond these (fire tests, quiet tests, cost bench, CI labels, manual runs):
`docs/falco-rules-testing.md`.

When `custom_labels_render_test.py` fails on a new object, wire it like the others:
`cloudanix.mergeLabels` with `.Values.commonLabels` first and the object's own labels last
(see `_helpers.tpl`), and add `<component>.podLabels` on pod templates. A new component
also needs its template file in `COMPONENTS` in the script.

## Why `rbac_coverage.py` exists

Each of these breaks with no error anywhere — you just get less data, and notice weeks later
from a gap in the console:

1. **misconfig ClusterRole ⊇ what the audits read.** A missing grant makes `kubectl` exit
   non-zero, so the check reports `WARN` carrying the API server's message instead of a
   finding. A whole benchmark can go quiet this way.
2. **inventory ClusterRole ⊇ what inventory-collector watches.** A watched-but-ungranted GVR
   fails at informer start and that kind is simply absent from inventory. This had actually
   happened with `endpointslices`.
3. **inventory-collector ⊇ the kinds kube-bench names.** The console joins `failed_resources`
   to inventory on `(cluster_identifier, uid)`; an unwatched kind renders half-populated.

Everything is derived from the sources — the benchmark YAML under `kube-bench/cfg`, the
rendered ClusterRoles, and `inventory-collector/kube/resources.go` — so it stays true as
checks are added rather than needing a list kept in step by hand.

## Sibling repos

Found via env vars, defaulting to the usual checkout paths. Missing repos are **skipped, not
failed**, so this still runs in a chart-only checkout:

```sh
KUBE_BENCH_DIR=~/src/kube-bench CSS_DIR=~/src/container-security-services \
    chart/tests/rbac_coverage.py
```

## When a check fires

- *misconfig ClusterRole is missing X* — an audit started reading a new resource. Add it to
  the rule for its apiGroup in `misconfig-scanner.tpl`. **Never add `secrets`**: RBAC has no
  metadata-only read, and `cloudanix-1.0` C4.2 stays manual precisely to avoid it.
- *inventory watches but ClusterRole does not grant X* — add it to
  `inventory-collector.tpl`.
- *kube-bench names X but inventory does not watch it* — add the GVR to `resources.go`, and
  its grant to `inventory-collector.tpl`. Weigh the informer cache first: it holds whole
  objects, which is why Secrets are excluded.
- *no catalog entry for X* — a new Kind appeared. Add it to `CATALOG` in the script so the
  join can be checked at all.
