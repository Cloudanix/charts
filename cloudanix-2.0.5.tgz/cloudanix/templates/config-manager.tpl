{{- if eq (include "cloudanix.runtimeThreatEnabled" .) "true" }}
{{- if .Capabilities.APIVersions.Has "batch/v1" }}
apiVersion: batch/v1
{{- else }}
apiVersion: batch/v1beta1
{{- end }}
kind: CronJob
metadata:
  name: {{ .Values.configManager.name }}
  namespace: cloudanix
  labels:
    {{- with .Values.configManager.labels }}
    {{ toYaml . }}
    {{- end }}
spec:
  {{- if and (.Values.authToken) (ne .Values.authToken "DEFAULT") }}
  schedule: {{ .Values.configManager.schedule | quote }}
  {{- else }}
  schedule: "*/5 * * * *"
  {{- end }}
  concurrencyPolicy: Forbid
  jobTemplate:
    spec:
      activeDeadlineSeconds: {{ .Values.configManager.activeDeadlineSeconds | default 14400 }}
      template:
        spec:
          serviceAccountName: config-manager-sa
          containers:
          - name: config-manager
            image: {{ .Values.configManager.image }}
            imagePullPolicy: IfNotPresent
            volumeMounts:
            - name: config-volume
              mountPath: /etc/cdx/config
              readOnly: true
            - name: cloudanix-secrets-volume
              mountPath: /etc/cdx/secrets
              readOnly: true
            resources:
              {{- toYaml (.Values.configManager.resources | default dict) | nindent 14 }}
          volumes:
            - name: config-volume
              configMap:
                name: config-manager-cm
            - name: cloudanix-secrets-volume
              secret:
                secretName: cloudanix-secrets
          restartPolicy: Never

---

apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ .Values.configManager.configMapName }}
  namespace: cloudanix
data:
  config.yaml: |
    chartVersion:  {{ .Chart.Version }}
    releaseName: {{ .Release.Name }}
    common:
      logLevel: {{ .Values.logLevel | default "warn" }}
      requestTimeout: {{ .Values.requestTimeout | default 30 }}
      httpMaxRetries: {{ .Values.httpMaxRetries | default 3 }}
      accountId: {{ required "Account Id is required!" .Values.accountId }}
      clusterIdentifier: {{ required "Cluster Identifier is required!" .Values.clusterIdentifier }}
      {{- if and (.Values.clusterName) (ne .Values.clusterName "DEFAULT") }}
      clusterName:  {{ .Values.clusterName }}
      {{- else if (.Values.clusterIdentifier) }}
      clusterName: {{ required "Cluster Name is required!" (splitList "/" .Values.clusterIdentifier) | last }}
      {{- end }}
      clusterDomain: {{ required "Cluster Domain is required!" .Values.clusterDomain }}
    configManager:
      configUrl: {{ required "A valid URL is required!" .Values.configManager.configURL }}
      templateType: {{ required "configManager.templateType is required!" .Values.configManager.templateType }}
      {{- if and (.Values.authToken) (ne .Values.authToken "DEFAULT") }}
      installSource: DIRECT
      {{- end }}
      {{- with .Values.configManager.statusReporting }}
      statusReporting:
        enabled: {{ .enabled }}
        timeoutSeconds: {{ .timeoutSeconds }}
        maxRetries: {{ .maxRetries }}
      {{- end }}
    resources:
      falcoService:
        daemonName: {{ .Release.Name }}-falco
        configMapName: {{ .Release.Name }}-falco-rules
        namespace: cloudanix
      configManager:
        cronJobName: {{ .Values.configManager.name }}
        configMapName: {{ .Values.configManager.configMapName }}
        namespace: cloudanix
      threatMonitor:
        deployName: {{ .Values.threatMonitor.name }}
        configMapName: {{ .Values.threatMonitor.configMapName }}
        namespace: cloudanix
      inventoryCollector:
        deployName: {{ .Values.inventoryCollector.name }}
        configMapName: {{ .Values.inventoryCollector.configMapName }}
        namespace: cloudanix
      misconfigScanner:
        cronJobName: {{ .Values.misconfigScanner.name }}
        configMapName: {{ .Values.misconfigScanner.configMapName }}
        namespace: {{ .Release.Namespace }}
      {{- if eq (include "cloudanix.trafficExporterEnabled" .) "true" }}
      trafficExporter:
        deployName: {{ .Values.trafficExporter.name }}
        configMapName: {{ .Values.trafficExporter.name }}-config
        namespace: {{ .Release.Namespace }}
      {{- end }}
      {{- if eq (include "cloudanix.vulnScanningEnabled" .) "true" }}
      vulnScanner:
        cronJobName: {{ .Values.vulnScanner.name }}
        configMapName: {{ .Values.vulnScanner.configMapName }}
        namespace: {{ .Release.Namespace }}
      {{- end }}

---

apiVersion: v1
kind: ServiceAccount
metadata:
  name: config-manager-sa
  namespace: cloudanix

---

kind: ClusterRole
apiVersion: rbac.authorization.k8s.io/v1
metadata:
  name: config-manager-role
  namespace: cloudanix
rules:
- apiGroups: ["","apps","batch"]
  resources: ["deployments","daemonsets","configmaps","cronjobs"]
  verbs: ["get", "watch", "list", "update", "patch"]

---

apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: config-manager
  namespace: cloudanix
subjects:
- kind: ServiceAccount
  name: config-manager-sa
  namespace: cloudanix
roleRef:
  kind: ClusterRole
  name: config-manager-role
  apiGroup: rbac.authorization.k8s.io

---

kind: ClusterRole
apiVersion: rbac.authorization.k8s.io/v1
metadata:
  name: config-manager-role-secrets
  namespace: cloudanix
rules:
- apiGroups: ["","apps","batch"]
  resources: ["secrets"]
  verbs: ["get", "watch", "list", "update", "patch"]

---

apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: config-manager
  namespace: cloudanix
subjects:
- kind: ServiceAccount
  name: config-manager-sa
  namespace: cloudanix
roleRef:
  kind: ClusterRole
  name: config-manager-role-secrets
  apiGroup: rbac.authorization.k8s.io

---

# Read-only pod/log access for the on-demand diagnostic-bundle collector
# (docs/config-sync-status/standard.md §3.1 in container-security-services).
# Staff-triggered, capped at 5MiB per run (see config-manager/diagnostics) -
# unlike the (not yet built) always-on scheduled log shipping in plan.md §5,
# this is small and rare enough to ship always-on rather than opt-in, but it
# is still namespace-scoped via RoleBinding (same binding pattern as
# config-manager-role-secrets) and read-only.
kind: ClusterRole
apiVersion: rbac.authorization.k8s.io/v1
metadata:
  name: config-manager-role-diagnostics
  namespace: cloudanix
rules:
- apiGroups: [""]
  resources: ["pods"]
  verbs: ["get", "list"]
- apiGroups: [""]
  resources: ["pods/log"]
  verbs: ["get"]

---

apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: config-manager-diagnostics
  namespace: cloudanix
subjects:
- kind: ServiceAccount
  name: config-manager-sa
  namespace: cloudanix
roleRef:
  kind: ClusterRole
  name: config-manager-role-diagnostics
  apiGroup: rbac.authorization.k8s.io
---
{{- end }}
